/**
 * Module: CenterDisplayTextWidget - Responsive center-position renderer for the nav cluster
 * Documentation: documentation/widgets/center-display.md
 * Depends: componentContext.theme.tokens, TextLayoutEngine, CanvasTextLayout, TextTileLayout, TextLayoutScaleHelpers, CenterDisplayLayout, CenterDisplayMath, CenterDisplayStateAdapter, CenterDisplayRenderModel
 */
(function (root, factory) {
  if (typeof define === "function" && define.amd) define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
  else {
    (root.DyniComponents = root.DyniComponents || {}).DyniCenterDisplayTextWidget = factory();
  }
}(this, function () {
  "use strict";
  const hasOwn = Object.prototype.hasOwnProperty;
  function measureCachedTextWidth(ctx, textApi, text, family, weight, px, frameWidthCache) {
    textApi.setFont(ctx, Math.max(1, Math.floor(Number(px) || 0)), weight, family);
    const content = String(text || "");
    const cacheKey = String(ctx.font || "") + "\n" + content;
    if (frameWidthCache && hasOwn.call(frameWidthCache, cacheKey)) {
      return frameWidthCache[cacheKey];
    }
    const width = textApi.measureTextWidth(ctx, content);
    if (frameWidthCache) {
      frameWidthCache[cacheKey] = width;
    }
    return width;
  }
  function computeResponsiveLineMaxPx(rect, ratio, fillScale) {
    return Math.max(1, Math.floor(rect.h * ratio * fillScale));
  }
  function computeRelationValueMaxPx(layout, textFillScale) {
    const rowRects = layout.rowRects;
    let maxPx = 0;
    for (let i = 0; i < rowRects.length; i++) {
      const rect = rowRects[i];
      if (!rect || !(rect.h > 0)) {
        continue;
      }
      maxPx = Math.max(maxPx, computeResponsiveLineMaxPx(rect, 0.66, textFillScale));
    }
    return maxPx;
  }
  function clampShare(value, minShare, maxShare) {
    const n = Number(value);
    if (!Number.isFinite(n)) {
      return undefined;
    }
    return Math.max(minShare, Math.min(maxShare, n));
  }
  function drawCenterPanel(layout, state, displayState, labelFamily, valueFamily, valueWeight, labelWeight, color) {
    const textFillScale = layout.responsive.textFillScale;
    const relationValueMaxPx = computeRelationValueMaxPx(layout, textFillScale);
    const latFit = state.tileLayout.measureFittedLine({
      textApi: state.radialText,
      ctx: state.ctx,
      text: displayState.latText,
      maxW: layout.center.latRect.w,
      maxH: layout.center.latRect.h,
      maxPx: relationValueMaxPx,
      textFillScale: textFillScale,
      family: valueFamily,
      weight: valueWeight
    });
    const lonFit = state.tileLayout.measureFittedLine({
      textApi: state.radialText,
      ctx: state.ctx,
      text: displayState.lonText,
      maxW: layout.center.lonRect.w,
      maxH: layout.center.lonRect.h,
      maxPx: relationValueMaxPx,
      textFillScale: textFillScale,
      family: valueFamily,
      weight: valueWeight
    });
    const coupledPx = Math.min(latFit.px, lonFit.px);
    const coupledLatFit = latFit.px === coupledPx ? latFit : { px: coupledPx, text: latFit.text };
    const coupledLonFit = lonFit.px === coupledPx ? lonFit : { px: coupledPx, text: lonFit.text };
    state.ctx.fillStyle = color;
    state.tileLayout.drawFittedLine({
      textApi: state.radialText,
      ctx: state.ctx,
      text: displayState.positionCaption,
      rect: layout.center.captionRect,
      align: layout.center.captionAlign,
      family: labelFamily,
      weight: labelWeight,
      maxPx: computeResponsiveLineMaxPx(layout.center.captionRect, 0.76, textFillScale),
      padX: state.layoutApi.computeTextPadPx(layout.center.captionRect, layout.responsive),
      color: color,
      alpha: state.captionOpacity
    });
    state.tileLayout.drawFittedLine({
      textApi: state.radialText,
      ctx: state.ctx,
      text: displayState.latText,
      rect: layout.center.latRect,
      align: layout.center.coordAlign,
      family: valueFamily,
      weight: valueWeight,
      fit: coupledLatFit,
      padX: state.layoutApi.computeTextPadPx(layout.center.latRect, layout.responsive),
      color: color
    });
    state.tileLayout.drawFittedLine({
      textApi: state.radialText,
      ctx: state.ctx,
      text: displayState.lonText,
      rect: layout.center.lonRect,
      align: layout.center.coordAlign,
      family: valueFamily,
      weight: valueWeight,
      fit: coupledLonFit,
      padX: state.layoutApi.computeTextPadPx(layout.center.lonRect, layout.responsive),
      color: color
    });
  }
  function computeRowLayout(row, rect, state, labelFamily, valueFamily, valueWeight, labelWeight) {
    const gap = state.layoutApi.computeRowValueGapPx(rect, state.responsive);
    const textFillScale = state.textFillScale;
    const labelMaxPx = computeResponsiveLineMaxPx(rect, 0.58, textFillScale);
    const valueMaxPx = computeResponsiveLineMaxPx(rect, 0.66, textFillScale);
    const desiredLabelWidth = row.caption
      ? measureCachedTextWidth(
        state.ctx,
        state.radialText,
        row.caption,
        labelFamily,
        labelWeight,
        labelMaxPx,
        state.frameWidthCache
      )
      : 0;
    const fullValueWidth = measureCachedTextWidth(
      state.ctx,
      state.radialText,
      row.fullValueText,
      valueFamily,
      valueWeight,
      valueMaxPx,
      state.frameWidthCache
    );
    const compactValueWidth = measureCachedTextWidth(
      state.ctx,
      state.radialText,
      row.compactValueText,
      valueFamily,
      valueWeight,
      valueMaxPx,
      state.frameWidthCache
    );
    const maxLabelWidth = Math.floor(rect.w * 0.40);
    const minValueWidth = Math.floor(rect.w * 0.42);
    const availableLabelWidth = Math.max(0, rect.w - minValueWidth - (row.caption ? gap : 0));
    const labelWidth = row.caption
      ? Math.max(0, Math.min(maxLabelWidth, availableLabelWidth, Math.floor(desiredLabelWidth)))
      : 0;
    const availableValueWidth = Math.max(1, rect.w - labelWidth - (row.caption ? gap : 0));
    const valueText = fullValueWidth <= availableValueWidth + 0.01
      ? row.fullValueText
      : row.compactValueText;
    const valueWidth = valueText === row.fullValueText ? fullValueWidth : compactValueWidth;
    const pairWidth = labelWidth + (row.caption ? gap : 0) + valueWidth;
    const pairX = rect.x + Math.max(0, Math.floor((rect.w - pairWidth) / 2));
    const valueOffset = row.caption ? (pairX - rect.x + labelWidth + gap) : (pairX - rect.x);
    return {
      labelRect: { x: pairX, y: rect.y, w: labelWidth, h: rect.h },
      valueRect: {
        x: rect.x + valueOffset,
        y: rect.y,
        w: Math.max(1, rect.x + rect.w - (rect.x + valueOffset)),
        h: rect.h
      },
      valueText: valueText,
      labelMaxPx: labelMaxPx,
      valueMaxPx: valueMaxPx
    };
  }
  function drawRelationRows(layout, rows, state, labelFamily, valueFamily, valueWeight, labelWeight, color) {
    state.ctx.fillStyle = color;
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const rect = layout.rowRects[i];
      if (!rect || !(rect.w > 0) || !(rect.h > 0)) {
        continue;
      }
      const rowLayout = computeRowLayout(row, rect, state, labelFamily, valueFamily, valueWeight, labelWeight);
      if (row.caption && rowLayout.labelRect.w > 0) {
        state.tileLayout.drawFittedLine({
          textApi: state.radialText,
          ctx: state.ctx,
          text: row.caption,
          rect: rowLayout.labelRect,
          align: "left",
          family: labelFamily,
          weight: labelWeight,
          maxPx: rowLayout.labelMaxPx,
          padX: state.layoutApi.computeTextPadPx(rowLayout.labelRect, layout.responsive),
          color: color,
          alpha: state.captionOpacity
        });
      }
      state.tileLayout.drawFittedLine({
        textApi: state.radialText,
        ctx: state.ctx,
        text: rowLayout.valueText,
        rect: rowLayout.valueRect,
        align: "left",
        family: valueFamily,
        weight: valueWeight,
        maxPx: rowLayout.valueMaxPx,
        padX: state.layoutApi.computeTextPadPx(rowLayout.valueRect, layout.responsive),
        color: color
      });
    }
  }
  function create(def, componentContext) {
    const theme = componentContext.theme.tokens;
    const text = componentContext.components.require("TextLayoutEngine");
    const radialText = componentContext.components.require("CanvasTextLayout");
    const tileLayout = componentContext.components.require("TextTileLayout");
    const resolveOpacity = componentContext.components.require("TextLayoutScaleHelpers").resolveOpacity;
    const layoutApi = componentContext.components.require("CenterDisplayLayout");
    const math = componentContext.components.require("CenterDisplayMath");
    const centerDisplayStateAdapter = componentContext.components.require("CenterDisplayStateAdapter");
    const centerDisplayRenderModel = componentContext.components.require("CenterDisplayRenderModel");
    function renderCanvas(canvas, props) {
      const p = props || {};
      const setup = componentContext.canvas.setupCanvas(canvas);
      const ctx = setup && setup.ctx;
      const W = setup && setup.W;
      const H = setup && setup.H;
      if (!ctx || !W || !H) {
        return;
      }
      ctx.clearRect(0, 0, W, H);
      ctx.textBaseline = "middle";
      const rootEl = componentContext.dom.requirePluginRoot(canvas);
      const tokens = theme.resolveForRoot(rootEl);
      const family = tokens.font.family;
      const monoFamily = tokens.font.familyMono || family;
      const coordinatesTabular = p.coordinatesTabular !== false;
      const stableDigitsEnabled = p.stableDigits === true;
      const centerValueFamily = coordinatesTabular ? monoFamily : family;
      const relationValueFamily = stableDigitsEnabled ? monoFamily : family;
      const color = tokens.surface.fg;
      const valueWeight = tokens.font.weight;
      const labelWeight = tokens.font.labelWeight;
      const captionOpacity = resolveOpacity(tokens.opacity && tokens.opacity.caption);
      if (centerDisplayStateAdapter.renderStateScreenIfNeeded({
        ctx: ctx,
        W: W,
        H: H,
        props: p,
        family: family,
        color: color,
        labelWeight: labelWeight
      })) {
        return;
      }
      const defaultText = String(p.default);
      const modeData = text.computeModeLayout({
        W: W,
        H: H,
        ratioThresholdNormal: p.ratioThresholdNormal,
        ratioThresholdFlat: p.ratioThresholdFlat,
        captionText: "",
        unitText: ""
      });
      const insets = layoutApi.computeInsets(W, H);
      const contentRect = layoutApi.createContentRect(W, H, insets);
      const displayState = centerDisplayRenderModel.buildDisplayState(p, math, defaultText);
      const frameWidthCache = Object.create(null);
      const hints = centerDisplayRenderModel.computeMeasurementHints({
        ctx: ctx,
        textApi: radialText,
        rows: displayState.rows,
        positionCaption: displayState.positionCaption,
        latText: displayState.latText,
        lonText: displayState.lonText,
        contentRect: contentRect,
        gap: insets.gap,
        labelFamily: family,
        coordFamily: centerValueFamily,
        relationValueFamily: relationValueFamily,
        valueWeight: valueWeight,
        labelWeight: labelWeight,
        frameWidthCache: frameWidthCache,
        measureTextWidth: measureCachedTextWidth,
        computeResponsiveLineMaxPx: computeResponsiveLineMaxPx,
        clampShare: clampShare
      });
      const layout = layoutApi.computeLayout({
        contentRect: contentRect,
        mode: modeData.mode,
        relationCount: displayState.rows.length,
        gap: insets.gap,
        responsive: insets.responsive,
        normalCaptionShare: hints.normalCaptionShare,
        flatCenterShare: hints.flatCenterShare,
        highCaptionRatio: hints.highCaptionRatio,
        flatCaptionRatio: hints.flatCaptionRatio,
        coordAlign: coordinatesTabular ? "right" : "center"
      });
      const renderState = {
        ctx: ctx,
        radialText: radialText,
        tileLayout: tileLayout,
        textFillScale: layout.responsive.textFillScale,
        captionOpacity: captionOpacity,
        layoutApi: layoutApi,
        responsive: layout.responsive,
        frameWidthCache: frameWidthCache
      };
      drawCenterPanel(layout, renderState, displayState, family, centerValueFamily, valueWeight, labelWeight, color);
      drawRelationRows(
        layout,
        displayState.rows,
        renderState,
        family,
        relationValueFamily,
        valueWeight,
        labelWeight,
        color
      );
    }
    function translateFunction() { return {}; }
    return {
      id: "CenterDisplayTextWidget",
      wantsHideNativeHead: true,
      renderCanvas: renderCanvas,
      translateFunction: translateFunction
    };
  }
  return { id: "CenterDisplayTextWidget", create: create };
}));

/**
 * @file TemperatureRadialWidget - Semicircle temperature gauge with high-end sectors
 * Documentation: documentation/widgets/semicircle-gauges.md
 */
(function (root, factory) {
  if (typeof define === "function" && define.amd) define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
  else {
    (root.DyniComponents = root.DyniComponents || {}).DyniTemperatureRadialWidget = factory();
  }
})(this, function () {
  "use strict";

  /** @param {unknown} def @param {DyniComponentContext} componentContext */
  function create(def, componentContext) {
    const renderer = componentContext.components.require("SemicircleRadialEngine");
    const valueMath = componentContext.components.require("ValueMath");
    const placeholderNormalize = componentContext.components.require("PlaceholderNormalize");

    const renderCanvas = renderer.createRenderer({
      rawValueKey: "temp",
      unitDefault: "°C",
      rangeProps: {
        min: "tempRadialMinValue",
        max: "tempRadialMaxValue"
      },
      tickProps: {
        major: "tempRadialTickMajor",
        minor: "tempRadialTickMinor",
        showEndLabels: "tempRadialShowEndLabels"
      },
      ratioProps: {
        normal: "tempRadialRatioThresholdNormal",
        flat: "tempRadialRatioThresholdFlat"
      },
      hideTextualMetricsProp: "tempRadialHideTextualMetrics",
      tickSteps: valueMath.resolveTemperatureTickSteps,
      formatDisplay: function (raw, props) {
        const formatted = valueMath.formatGaugeDisplay(
          raw,
          props,
          componentContext.format.applyFormatter,
          placeholderNormalize.normalize,
          "formatTemperature",
          ["celsius"]
        );
        return Number.isFinite(formatted.num)
          ? { num: formatted.num, text: formatted.num.toFixed(1) }
          : { num: formatted.num, text: placeholderNormalize.normalize(formatted.text, undefined) };
      },
      buildSectors: function (props, minV, maxV, arc, valueUtils, theme) {
        const p = props || {};
        const radialProps = {
          warningFrom: p.tempRadialWarningFrom,
          alarmFrom: p.tempRadialAlarmFrom
        };
        return valueUtils.buildHighEndSectors(radialProps, minV, maxV, arc, {
          warningColor: theme.colors.warning,
          alarmColor: theme.colors.alarm
        });
      }
    });

    function translateFunction() {
      return {};
    }

    return {
      id: "TemperatureRadialWidget",
      wantsHideNativeHead: true,
      renderCanvas,
      translateFunction
    };
  }

  return { id: "TemperatureRadialWidget", create };
});

/**
 * @file DyniPlugin Widgets Registry Vessel - Vessel, alarm, and text widget component definitions
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const config = ns.config;
  const shared = (config.shared = config.shared || {});
  const BASE = ns.baseUrl;

  if (typeof BASE !== "string" || !BASE) {
    throw new Error("dyninstruments: baseUrl missing before config/components/registry-widgets-vessel.js load");
  }

  const SHARED_HTML_SHADOW_CSS = BASE + "shared/html/HtmlShadowCommon.css";

  const groups = (shared.componentRegistryGroups = shared.componentRegistryGroups || {});
  var w = (groups.widgets = groups.widgets || {});

  w.AlarmRenderModel = {
    js: BASE + "shared/widget-kits/vessel/AlarmRenderModel.js",
    globalKey: "DyniAlarmRenderModel",
    deps: ["HtmlWidgetUtils", "ValueMath"]
  };

  w.AlarmTextHtmlWidget = {
    js: BASE + "widgets/text/AlarmTextHtmlWidget/AlarmTextHtmlWidget.js",
    shadowCss: [SHARED_HTML_SHADOW_CSS, BASE + "widgets/text/AlarmTextHtmlWidget/AlarmTextHtmlWidget.css"],
    globalKey: "DyniAlarmTextHtmlWidget",
    deps: ["AlarmHtmlFit", "HtmlWidgetUtils", "AlarmRenderModel", "AlarmMarkup", "ValueMath"]
  };

  w.AlarmMarkup = {
    js: BASE + "shared/widget-kits/vessel/AlarmMarkup.js",
    globalKey: "DyniAlarmMarkup",
    deps: ["HtmlWidgetUtils", "ValueMath"]
  };

  w.RegattaTimerModel = {
    js: BASE + "shared/widget-kits/vessel/RegattaTimerModel.js",
    globalKey: "DyniRegattaTimerModel",
    deps: ["ValueMath"]
  };

  w.RegattaTimerAudio = {
    js: BASE + "shared/widget-kits/vessel/RegattaTimerAudio.js",
    globalKey: "DyniRegattaTimerAudio",
    deps: []
  };

  w.RegattaTimerSessionStore = {
    js: BASE + "shared/widget-kits/vessel/RegattaTimerSessionStore.js",
    globalKey: "DyniRegattaTimerSessionStore",
    deps: ["ValueMath"]
  };

  w.RegattaTimerMarkup = {
    js: BASE + "shared/widget-kits/vessel/RegattaTimerMarkup.js",
    globalKey: "DyniRegattaTimerMarkup",
    deps: ["HtmlWidgetUtils", "RegattaTimerPhase"]
  };

  w.RegattaTimerTextHtmlWidget = {
    js: BASE + "widgets/text/RegattaTimerTextHtmlWidget/RegattaTimerTextHtmlWidget.js",
    shadowCss: [
      SHARED_HTML_SHADOW_CSS,
      BASE + "widgets/text/RegattaTimerTextHtmlWidget/RegattaTimerTextHtmlWidget.css"
    ],
    globalKey: "DyniRegattaTimerTextHtmlWidget",
    deps: [
      "RegattaTimerModel",
      "RegattaTimerAudio",
      "RegattaTimerSessionStore",
      "RegattaTimerMarkup",
      "RegattaTimerHtmlFit",
      "HtmlWidgetUtils",
      "ValueMath"
    ]
  };

  w.PositionCoordinateWidget = {
    js: BASE + "widgets/text/PositionCoordinateWidget/PositionCoordinateWidget.js",
    globalKey: "DyniPositionCoordinateWidget",
    deps: [
      "TextLayoutEngine",
      "ValueMath",
      "PlaceholderNormalize",
      "StateScreenLabels",
      "StateScreenPrecedence",
      "StateScreenCanvasOverlay",
      "PositionCoordinateFormatting"
    ]
  };

  w.ThreeValueTextWidget = {
    js: BASE + "widgets/text/ThreeValueTextWidget/ThreeValueTextWidget.js",
    globalKey: "DyniThreeValueTextWidget",
    deps: [
      "TextLayoutEngine",
      "PlaceholderNormalize",
      "StableDigits",
      "StateScreenLabels",
      "StateScreenPrecedence",
      "StateScreenCanvasOverlay"
    ]
  };

  w.XteDisplayWidget = {
    js: BASE + "widgets/text/XteDisplayWidget/XteDisplayWidget.js",
    globalKey: "DyniXteDisplayWidget",
    deps: [
      "GaugeToolkit",
      "CanvasLayerCache",
      "XteHighwayPrimitives",
      "XteDisplayPropsNormalize",
      "XteDisplayRenderSetup",
      "XteHighwayLayout",
      "TextTileLayout",
      "SpringEasing",
      "XteDisplayMetrics",
      "StateScreenLabels",
      "StateScreenPrecedence",
      "StateScreenCanvasOverlay"
    ]
  };

  w.XteDisplayLinearWidget = {
    js: BASE + "widgets/text/XteDisplayLinearWidget/XteDisplayLinearWidget.js",
    globalKey: "DyniXteDisplayLinearWidget",
    deps: [
      "GaugeToolkit",
      "CanvasLayerCache",
      "LinearGaugeMath",
      "XteLinearPrimitives",
      "XteDisplayPropsNormalize",
      "XteDisplayRenderSetup",
      "XteLinearLayout",
      "TextTileLayout",
      "XteLinearDynamicMetrics",
      "StateScreenLabels",
      "StateScreenPrecedence",
      "StateScreenCanvasOverlay"
    ]
  };
})(this);

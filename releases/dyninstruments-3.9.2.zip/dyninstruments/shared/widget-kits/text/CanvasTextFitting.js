/**
 * @file CanvasTextFitting - Generic canvas text measurement and fitting
 * Documentation: documentation/conventions/shared-helpers.md
 */
(function (root, factory) {
  if (typeof define === "function" && define.amd) define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
  else {
    (root.DyniComponents = root.DyniComponents || {}).DyniCanvasTextFitting = factory();
  }
})(this, function () {
  "use strict";

  const hasOwn = Object.prototype.hasOwnProperty;
  const MIN_FONT_PX = 0.5;
  const WIDTH_EPSILON = 0.01;
  const FONT_STATE_KEY = "__dyniRadialTextFontState";
  const WIDTH_CACHE_KEY = "__dyniRadialTextWidthCache";
  const WIDTH_CACHE_SIZE_KEY = "__dyniRadialTextWidthCacheSize";
  const MAX_WIDTH_CACHE_ENTRIES = 2048;

  /**
   * @param {unknown} def
   * @param {DyniComponentContext} componentContext
   * @returns {DyniCanvasTextFittingApi}
   */
  function create(def, componentContext) {
    const valueMath = componentContext.components.require("ValueMath");
    const clampPositive = valueMath.clampPositive;

    /** @param {unknown} ctx @returns {Record<string, number> | null} */
    function resolveWidthCache(ctx) {
      if (!ctx || (typeof ctx !== "object" && typeof ctx !== "function")) {
        return null;
      }
      const store = /** @type {DyniAugmentedCanvas} */ (ctx);
      if (!store[WIDTH_CACHE_KEY] || typeof store[WIDTH_CACHE_KEY] !== "object") {
        store[WIDTH_CACHE_KEY] = Object.create(null);
      }
      return /** @type {Record<string, number>} */ (store[WIDTH_CACHE_KEY]);
    }

    /**
     * Stores a measured width; a full cache is cleared first, so it never exceeds MAX_WIDTH_CACHE_ENTRIES.
     * @param {DyniAugmentedCanvas} store
     * @param {string} cacheKey
     * @param {number} width
     */
    function rememberWidth(store, cacheKey, width) {
      let size = Number(store[WIDTH_CACHE_SIZE_KEY]) || 0;
      if (size >= MAX_WIDTH_CACHE_ENTRIES) {
        store[WIDTH_CACHE_KEY] = Object.create(null);
        size = 0;
      }
      /** @type {Record<string, number>} */ (store[WIDTH_CACHE_KEY])[cacheKey] = width;
      store[WIDTH_CACHE_SIZE_KEY] = size + 1;
    }

    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {unknown} px
     * @param {unknown} weight
     * @param {unknown} family
     * @returns {number}
     */
    function setFont(ctx, px, weight, family) {
      const size = Math.max(MIN_FONT_PX, Number(px) || 0);
      const fontWeight = Number.isFinite(Number(weight)) ? Math.floor(Number(weight)) : 700;
      const fontValue = fontWeight + " " + size + "px " + /** @type {string} */ (family || "sans-serif");
      const state = /** @type {DyniAugmentedCanvas} */ (/** @type {unknown} */ (ctx));
      if (state[FONT_STATE_KEY] !== fontValue || ctx.font !== fontValue) {
        ctx.font = fontValue;
        state[FONT_STATE_KEY] = fontValue;
      }
      return size;
    }

    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {unknown} text
     * @returns {number}
     */
    function measureTextWidth(ctx, text) {
      const content = String(text || "");
      const widthCache = resolveWidthCache(ctx);
      const cacheKey = String(ctx.font || "") + "\n" + content;
      if (widthCache && hasOwn.call(widthCache, cacheKey)) {
        return widthCache[cacheKey];
      }
      const width = ctx.measureText(content).width;
      if (widthCache) {
        rememberWidth(/** @type {DyniAugmentedCanvas} */ (/** @type {unknown} */ (ctx)), cacheKey, width);
      }
      return width;
    }

    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {unknown} text
     * @param {unknown} maxW
     * @param {unknown} maxH
     * @param {unknown} family
     * @param {unknown} weight
     * @returns {number}
     */
    function fitTextPx(ctx, text, maxW, maxH, family, weight) {
      const ceilingPx = clampPositive(maxH, MIN_FONT_PX);
      const widthLimit = Math.max(0, Number(maxW) || 0);
      if (!text) {
        return ceilingPx;
      }
      if (widthLimit <= 0) {
        return MIN_FONT_PX;
      }

      const content = String(text);
      setFont(ctx, ceilingPx, weight, family);
      const width = measureTextWidth(ctx, content);
      if (width <= widthLimit + WIDTH_EPSILON) {
        return ceilingPx;
      }

      const ratio = Math.max(0.01, widthLimit / Math.max(WIDTH_EPSILON, width));
      return Math.min(ceilingPx, Math.max(MIN_FONT_PX, ceilingPx * ratio));
    }

    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {unknown} text
     * @param {unknown} basePx
     * @param {unknown} maxW
     * @param {unknown} maxH
     * @param {unknown} family
     * @param {unknown} weight
     * @returns {number}
     */
    function fitSingleTextPx(ctx, text, basePx, maxW, maxH, family, weight) {
      const ceilingPx = Math.min(clampPositive(basePx, MIN_FONT_PX), clampPositive(maxH, MIN_FONT_PX));
      return fitTextPx(ctx, text, maxW, ceilingPx, family, weight);
    }

    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {unknown} family
     * @param {unknown} value
     * @param {unknown} unit
     * @param {unknown} w
     * @param {unknown} h
     * @param {unknown} secScale
     * @param {unknown} valueWeight
     * @param {unknown} labelWeight
     * @param {unknown} [textOptions]
     * @returns {DyniValueUnitFitResult}
     */
    function measureValueUnitFit(ctx, family, value, unit, w, h, secScale, valueWeight, labelWeight, textOptions) {
      if (!value) {
        return { vPx: 0, uPx: 0, gap: 0, total: 0 };
      }

      const maxH = clampPositive(h, MIN_FONT_PX);
      const rawMaxW = Math.max(0, Number(w) || 0);
      const maxW = Math.max(0, rawMaxW * 0.97);
      const hasUnit = !!unit;
      const ratio = Number(secScale);
      const scale = Number.isFinite(ratio) ? ratio : 0.8;
      const opts =
        textOptions && typeof textOptions === "object"
          ? /** @type {{ useMono?: unknown, monoFamily?: unknown }} */ (textOptions)
          : null;
      const valueFamily = opts && opts.useMono === true ? opts.monoFamily || family : family;

      if (maxW <= 0) {
        return { vPx: MIN_FONT_PX, uPx: hasUnit ? MIN_FONT_PX : 0, gap: 0, total: 0 };
      }

      /** @param {number} vPx @param {number} uPx @param {number} gap @returns {number} */
      function totalWidth(vPx, uPx, gap) {
        setFont(ctx, vPx, valueWeight, valueFamily);
        const valueW = measureTextWidth(ctx, value);
        if (!hasUnit) {
          return valueW;
        }
        setFont(ctx, uPx, labelWeight, family);
        return valueW + gap + measureTextWidth(ctx, unit);
      }

      let vPx = maxH;
      let uPx = hasUnit ? Math.max(MIN_FONT_PX, Math.min(maxH, vPx * scale)) : 0;
      let gap = hasUnit ? Math.max(MIN_FONT_PX, vPx * 0.25) : 0;
      let total = totalWidth(vPx, uPx, gap);

      if (total > maxW + WIDTH_EPSILON) {
        const ratio1 = Math.max(0.01, maxW / Math.max(WIDTH_EPSILON, total));
        vPx = Math.max(MIN_FONT_PX, vPx * ratio1);
        uPx = hasUnit ? Math.max(MIN_FONT_PX, Math.min(maxH, vPx * scale)) : 0;
        gap = hasUnit ? Math.max(MIN_FONT_PX, vPx * 0.25) : 0;
        total = totalWidth(vPx, uPx, gap);
      }

      if (total > maxW + WIDTH_EPSILON) {
        const ratio2 = Math.max(0.01, maxW / Math.max(WIDTH_EPSILON, total));
        vPx = Math.max(MIN_FONT_PX, vPx * ratio2);
        uPx = hasUnit ? Math.max(MIN_FONT_PX, Math.min(maxH, uPx * ratio2)) : 0;
        gap = hasUnit ? Math.max(MIN_FONT_PX, gap * ratio2) : 0;
        total = totalWidth(vPx, uPx, gap);
      }

      return { vPx: vPx, uPx: uPx, gap: gap, total: total };
    }

    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {unknown} family
     * @param {unknown} caption
     * @param {unknown} value
     * @param {unknown} unit
     * @param {unknown} maxW
     * @param {unknown} maxH
     * @param {unknown} secScale
     * @param {unknown} valueWeight
     * @param {unknown} labelWeight
     * @returns {DyniInlineCapValUnitFitResult}
     */
    function fitInlineCapValUnit(ctx, family, caption, value, unit, maxW, maxH, secScale, valueWeight, labelWeight) {
      if (!value) {
        return { cPx: 0, vPx: 0, uPx: 0, g1: 0, g2: 0, total: 0 };
      }

      const heightLimit = clampPositive(maxH, MIN_FONT_PX);
      const widthLimit = Math.max(0, Number(maxW) || 0);
      const hasCaption = !!caption;
      const hasUnit = !!unit;
      const ratio = Number(secScale);
      const scale = Number.isFinite(ratio) ? ratio : 0.8;

      if (widthLimit <= 0) {
        return {
          cPx: hasCaption ? MIN_FONT_PX : 0,
          vPx: MIN_FONT_PX,
          uPx: hasUnit ? MIN_FONT_PX : 0,
          g1: 0,
          g2: 0,
          total: 0
        };
      }

      /**
       * @param {number} cPx @param {number} vPx @param {number} uPx
       * @param {number} g1 @param {number} g2 @returns {number}
       */
      function totalWidth(cPx, vPx, uPx, g1, g2) {
        let total = 0;
        if (hasCaption) {
          setFont(ctx, cPx, labelWeight, family);
          total += measureTextWidth(ctx, caption) + g1;
        }
        setFont(ctx, vPx, valueWeight, family);
        total += measureTextWidth(ctx, value);
        if (hasUnit) {
          setFont(ctx, uPx, labelWeight, family);
          total += g2 + measureTextWidth(ctx, unit);
        }
        return total;
      }

      let vPx = heightLimit;
      let cPx = hasCaption ? Math.max(MIN_FONT_PX, Math.min(heightLimit, vPx * scale)) : 0;
      let uPx = hasUnit ? Math.max(MIN_FONT_PX, Math.min(heightLimit, vPx * scale)) : 0;
      let g1 = hasCaption ? Math.max(MIN_FONT_PX, vPx * 0.25) : 0;
      let g2 = hasUnit ? Math.max(MIN_FONT_PX, vPx * 0.25) : 0;
      let total = totalWidth(cPx, vPx, uPx, g1, g2);

      if (total > widthLimit + WIDTH_EPSILON) {
        const ratio1 = Math.max(0.01, widthLimit / Math.max(WIDTH_EPSILON, total));
        vPx = Math.max(MIN_FONT_PX, vPx * ratio1);
        cPx = hasCaption ? Math.max(MIN_FONT_PX, Math.min(heightLimit, cPx * ratio1)) : 0;
        uPx = hasUnit ? Math.max(MIN_FONT_PX, Math.min(heightLimit, uPx * ratio1)) : 0;
        g1 = hasCaption ? Math.max(MIN_FONT_PX, g1 * ratio1) : 0;
        g2 = hasUnit ? Math.max(MIN_FONT_PX, g2 * ratio1) : 0;
        total = totalWidth(cPx, vPx, uPx, g1, g2);
      }

      if (total > widthLimit + WIDTH_EPSILON) {
        const ratio2 = Math.max(0.01, widthLimit / Math.max(WIDTH_EPSILON, total));
        vPx = Math.max(MIN_FONT_PX, vPx * ratio2);
        cPx = hasCaption ? Math.max(MIN_FONT_PX, Math.min(heightLimit, cPx * ratio2)) : 0;
        uPx = hasUnit ? Math.max(MIN_FONT_PX, Math.min(heightLimit, uPx * ratio2)) : 0;
        g1 = hasCaption ? Math.max(MIN_FONT_PX, g1 * ratio2) : 0;
        g2 = hasUnit ? Math.max(MIN_FONT_PX, g2 * ratio2) : 0;
        total = totalWidth(cPx, vPx, uPx, g1, g2);
      }

      return { cPx: cPx, vPx: vPx, uPx: uPx, g1: g1, g2: g2, total: total };
    }

    return {
      id: "CanvasTextFitting",
      MIN_FONT_PX: MIN_FONT_PX,
      WIDTH_EPSILON: WIDTH_EPSILON,
      clampPositive: clampPositive,
      setFont: setFont,
      measureTextWidth: measureTextWidth,
      fitTextPx: fitTextPx,
      fitSingleTextPx: fitSingleTextPx,
      measureValueUnitFit: measureValueUnitFit,
      fitInlineCapValUnit: fitInlineCapValUnit
    };
  }

  return { id: "CanvasTextFitting", create: create };
});

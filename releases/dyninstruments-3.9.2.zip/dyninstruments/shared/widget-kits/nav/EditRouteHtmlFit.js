/**
 * @file EditRouteHtmlFit - Per-box text-fit owner for edit-route HTML renderer
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root, factory) {
  if (typeof define === "function" && define.amd) define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
  else {
    (root.DyniComponents = root.DyniComponents || {}).DyniEditRouteHtmlFit = factory();
  }
})(this, function () {
  "use strict";

  const SOURCE_BADGE_MAX_PX_RATIO = 0.7;
  const METRIC_VALUE_MAX_PX_RATIO = 0.9;
  const METRIC_SECONDARY_TO_VALUE_RATIO = 0.8;
  /** @type {DyniEditRouteMetricId[]} */
  const METRIC_IDS = ["pts", "dst", "rte", "rteEta"];

  /**
   * @param {unknown} def
   * @param {DyniComponentContext} componentContext
   * @returns {DyniEditRouteHtmlFitApi}
   */
  function create(def, componentContext) {
    const theme = /** @type {DyniEditRouteThemeResolver} */ (
      /** @type {unknown} */ (componentContext.theme && componentContext.theme.tokens)
    );
    const textApi = componentContext.components.require("CanvasTextLayout");
    const tileLayout = componentContext.components.require("TextTileLayout");
    const layoutApi = componentContext.components.require("EditRouteLayout");
    const htmlUtils = componentContext.components.require("HtmlWidgetUtils");
    const htmlMeasureUtils = componentContext.components.require("HtmlMeasureUtils");
    const fitMath = componentContext.components.require("TextFitMath");
    const fitSupport = componentContext.components.require("EditRouteHtmlFitSupport");
    const valueMath = componentContext.components.require("ValueMath");
    const toText = valueMath.toText;
    const isNullish = valueMath.isNullish;

    /**
     * @param {DyniEditRouteHtmlFitArgs | undefined} args
     * @returns {DyniEditRouteMarkupFit | null}
     */
    function compute(args) {
      const cfg = /** @type {DyniEditRouteHtmlFitArgs} */ (args || {});
      const model = cfg.model || null;
      const shellRect = cfg.shellRect || null;
      const targetEl = cfg.targetEl || null;
      if (!model || !shellRect || !targetEl) {
        return null;
      }

      const rootEl = componentContext.dom.requirePluginRoot(targetEl);
      const tokens = theme.resolveForRoot(rootEl);
      const family = tokens.font.family;
      const valueFamily = /** @type {string} */ (htmlUtils.resolveMetricValueFamily(model, tokens));
      const measureCtx = htmlMeasureUtils.resolveMeasureContext(cfg.hostContext, targetEl);
      if (!measureCtx || typeof measureCtx.measureText !== "function") {
        return null;
      }

      const shellWidth = Math.max(1, Math.round(shellRect.width));
      const shellHeight = Math.max(1, Math.round(shellRect.height));
      const explicitLayoutHeight = htmlUtils.toFiniteNumber(model.layoutShellHeight);
      const verticalHeight = htmlUtils.toFiniteNumber(model.effectiveLayoutHeight);
      const layoutHeight =
        typeof explicitLayoutHeight === "number" && explicitLayoutHeight > 0
          ? explicitLayoutHeight
          : typeof verticalHeight === "number" && verticalHeight > 0
            ? verticalHeight
            : shellHeight;

      const layout = layoutApi.computeLayout({
        W: shellWidth,
        H: layoutHeight,
        mode: model.mode,
        hasRoute: model.hasRoute === true,
        isLocalRoute: model.isLocalRoute === true,
        ratioThresholdNormal: model.ratioThresholdNormal,
        ratioThresholdFlat: model.ratioThresholdFlat,
        isVerticalCommitted: model.isVerticalCommitted === true,
        effectiveLayoutHeight: verticalHeight
      });

      const valueWeight = tokens.font.weight;
      const labelWeight = tokens.font.labelWeight;
      const textFillScale = layout.responsive && layout.responsive.textFillScale;
      const valueTextOptions =
        model.stableDigitsEnabled === true
          ? {
              useMono: true,
              monoFamily: tokens.font.familyMono || family
            }
          : null;
      /** @type {DyniEditRouteComputedFit} */
      const fitOut = {
        nameTextStyle: fitSupport.measureEditRouteStyle({
          rect: layout.nameTextRect,
          text: toText(!isNullish(model.nameText) ? model.nameText : model.routeNameText),
          maxPxRatio: fitSupport.resolveNamePxRatio(layout.mode),
          textApi: textApi,
          tileLayout: tileLayout,
          ctx: measureCtx,
          family: family,
          weight: valueWeight,
          textFillScale: textFillScale,
          htmlUtils: htmlUtils
        }),
        sourceBadgeStyle: "",
        metrics: Object.create(null),
        metricValues: Object.create(null)
      };

      if (layout.sourceBadgeRect) {
        fitOut.sourceBadgeStyle = fitSupport.measureEditRouteStyle({
          rect: layout.sourceBadgeRect,
          text: toText(model.sourceBadgeText),
          maxPxRatio: SOURCE_BADGE_MAX_PX_RATIO,
          textApi: textApi,
          tileLayout: tileLayout,
          ctx: measureCtx,
          family: family,
          weight: labelWeight,
          textFillScale: textFillScale,
          htmlUtils: htmlUtils
        });
      }

      for (let i = 0; i < METRIC_IDS.length; i += 1) {
        const id = METRIC_IDS[i];
        if (!layout.metricVisibility[id]) {
          continue;
        }
        const box = layout.metricBoxes[id];
        if (!box) {
          continue;
        }
        const metricRect = box.tileRect || box.valueRect || box.labelRect;
        const spacing = layoutApi.computeMetricTileSpacing(metricRect, layout.responsive);
        const labelText = fitSupport.resolveMetricLabel(model, id);
        const valueText = fitSupport.resolveMetricValue(model, id);
        const plainValueText = fitSupport.resolveMetricPlainValue(model, id);
        const unitText = fitSupport.resolveMetricUnit(model, id);

        if (layout.mode === "high") {
          const valueRect = box.valueTextRect || box.valueRect;
          const selectedValue = fitSupport.selectMetricValue({
            stableDigitsEnabled: model.stableDigitsEnabled === true,
            primaryText: valueText,
            plainText: plainValueText,
            rect: valueRect,
            maxPxRatio: METRIC_VALUE_MAX_PX_RATIO,
            textApi: textApi,
            tileLayout: tileLayout,
            ctx: measureCtx,
            valueFamily: valueFamily || family,
            valueWeight: valueWeight,
            textFillScale: textFillScale,
            htmlUtils: htmlUtils
          });
          const valuePx = fitSupport.resolveMetricPx(selectedValue.fit, htmlUtils);
          const secondaryMaxPx = fitMath.resolveSecondaryMaxPx({
            valuePx: valuePx,
            valueRect: valueRect,
            valueMaxPxRatio: METRIC_VALUE_MAX_PX_RATIO,
            secondaryToValueRatio: METRIC_SECONDARY_TO_VALUE_RATIO
          });

          fitOut.metrics[id] = {
            labelStyle: fitSupport.measureEditRouteStyle({
              rect: box.labelRect,
              text: labelText,
              maxPx: secondaryMaxPx,
              maxPxRatio: METRIC_VALUE_MAX_PX_RATIO,
              textApi: textApi,
              tileLayout: tileLayout,
              ctx: measureCtx,
              family: family,
              weight: labelWeight,
              textFillScale: 1,
              htmlUtils: htmlUtils
            }),
            valueRowStyle: "",
            valueStyle: htmlMeasureUtils.toStyle(valuePx, htmlUtils),
            unitStyle: box.unitRect
              ? fitSupport.measureEditRouteStyle({
                  rect: box.unitRect,
                  text: unitText,
                  maxPx: secondaryMaxPx,
                  maxPxRatio: METRIC_VALUE_MAX_PX_RATIO,
                  textApi: textApi,
                  tileLayout: tileLayout,
                  ctx: measureCtx,
                  family: family,
                  weight: labelWeight,
                  textFillScale: 1,
                  htmlUtils: htmlUtils
                })
              : ""
          };
          fitOut.metricValues[id] = selectedValue.text;
          continue;
        }

        const primaryMeasurement = /** @type {DyniMetricTileMeasurement} */ (
          tileLayout.measureMetricTile({
            textApi: textApi,
            ctx: measureCtx,
            metric: {
              id: id,
              caption: labelText,
              value: valueText,
              plainValue: plainValueText,
              unit: unitText
            },
            rect: metricRect,
            textFillScale: layout.responsive.textFillScale,
            family: family,
            valueWeight: valueWeight,
            labelWeight: labelWeight,
            secScale: METRIC_SECONDARY_TO_VALUE_RATIO,
            padX: spacing.padX,
            captionHeightPx: spacing.captionHeightPx,
            valueTextOptions: valueTextOptions
          })
        );
        const primaryClipped = primaryMeasurement.fit.total > primaryMeasurement.textW + 0.01;
        const usePlain =
          model.stableDigitsEnabled === true &&
          primaryClipped &&
          typeof plainValueText === "string" &&
          plainValueText !== valueText;
        const activeMetric = usePlain
          ? {
              id: id,
              caption: labelText,
              value: plainValueText,
              plainValue: plainValueText,
              unit: unitText
            }
          : {
              id: id,
              caption: labelText,
              value: valueText,
              plainValue: plainValueText,
              unit: unitText
            };
        const measurement = usePlain
          ? /** @type {DyniMetricTileMeasurement} */ (
              tileLayout.measureMetricTile({
                textApi: textApi,
                ctx: measureCtx,
                metric: activeMetric,
                rect: metricRect,
                textFillScale: layout.responsive.textFillScale,
                family: family,
                valueWeight: valueWeight,
                labelWeight: labelWeight,
                secScale: METRIC_SECONDARY_TO_VALUE_RATIO,
                padX: spacing.padX,
                captionHeightPx: spacing.captionHeightPx,
                valueTextOptions: valueTextOptions
              })
            )
          : primaryMeasurement;
        const captionText = labelText;
        const captionFit = captionText
          ? /** @type {DyniFittedLineMeasurement} */ (
              tileLayout.measureFittedLine({
                textApi: textApi,
                ctx: measureCtx,
                text: captionText,
                maxW: measurement.textW,
                maxH: measurement.capH,
                maxPx: measurement.capMaxPx,
                textFillScale: layout.responsive.textFillScale,
                family: family,
                weight: labelWeight
              })
            )
          : null;

        fitOut.metrics[id] = {
          labelStyle: htmlMeasureUtils.toStyle(captionFit && captionFit.px, htmlUtils),
          valueRowStyle: "",
          valueStyle: htmlMeasureUtils.toStyle(measurement.fit.vPx, htmlUtils),
          unitStyle: unitText ? htmlMeasureUtils.toStyle(measurement.fit.uPx, htmlUtils) : ""
        };
        fitOut.metricValues[id] = usePlain ? plainValueText : valueText;
      }

      return fitOut;
    }

    return {
      id: "EditRouteHtmlFit",
      compute: compute
    };
  }

  /** @type {DyniEditRouteHtmlFitModule} */
  return { id: "EditRouteHtmlFit", create: create };
});

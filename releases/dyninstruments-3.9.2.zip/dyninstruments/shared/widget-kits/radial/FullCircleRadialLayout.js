/**
 * @file FullCircleRadialLayout - Responsive geometry owner for full-circle radial dials
 * Documentation: documentation/radial/full-circle-dial-engine.md
 */
(function (root, factory) {
  if (typeof define === "function" && define.amd) define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
  else {
    (root.DyniComponents = root.DyniComponents || {}).DyniFullCircleRadialLayout = factory();
  }
})(this, function () {
  "use strict";

  const STRUCTURAL_RATIO_THRESHOLD_NORMAL = 1.0;
  const STRUCTURAL_RATIO_THRESHOLD_FLAT = 2.0;
  const PAD_RATIO = 0.04;
  const GAP_RATIO = 0.03;
  const MARKER_LENGTH_FACTOR = 0.75;
  const MARKER_WIDTH_FACTOR = 0.2;
  const LABEL_SPRITE_RADIUS_FACTOR = 2.2;
  const NORMAL_SAFE_EXTRA_FACTOR = 0.06;
  const NORMAL_COMPACT_CENTER_HEIGHT_FACTOR = 0.9;
  const NORMAL_DUAL_COMPACT_WIDTH_FACTOR = 1.0;
  const NORMAL_DUAL_COMPACT_INSET_FACTOR = 0.035;
  const NORMAL_DUAL_COMPACT_HEIGHT_FACTOR = 0.46;
  const RESPONSIVE_SCALES = {
    textFillScale: 1.18
  };
  let makeRect = /** @type {DyniMakeRect} */ (/** @type {unknown} */ (null));
  /** @type {DyniValueMathApi["clampNumber"]} */
  let clampNumber;

  /**
   * @param {DyniRect} contentRect
   * @param {DyniRadialResolvedTheme | undefined} theme
   * @param {number} compactGeometryScale
   * @param {DyniGeometryScaleApi} gs
   * @returns {DyniFullCircleGeom}
   */
  function computeModeGeometry(contentRect, theme, compactGeometryScale, gs) {
    const width = Math.max(1, contentRect.w);
    const height = Math.max(1, contentRect.h);
    const radial = /** @type {DyniRadialThemeConfig} */ (theme && theme.radial ? theme.radial : {});
    const ring = /** @type {DyniRadialConfigMap} */ (radial.ring || {});
    const labels = /** @type {DyniRadialConfigMap} */ (radial.labels || {});
    const fullCircle = /** @type {DyniRadialConfigMap} */ (radial.fullCircle || {});
    const ticks = /** @type {DyniRadialConfigMap} */ (fullCircle.ticks || radial.ticks || {});
    const pointer = /** @type {DyniRadialConfigMap} */ (radial.pointer || {});
    const radius = Math.max(1, Math.floor(Math.min(width, height) / 2));
    const cx = contentRect.x + Math.floor(width / 2);
    const cy = contentRect.y + Math.floor(height / 2);
    const ringWidthFactor = clampNumber(ring.widthFactor, 0, Number.MAX_SAFE_INTEGER, 0.12);
    const strokeWeight = clampNumber(theme && theme.strokeWeight, 0, Number.MAX_SAFE_INTEGER, 1);
    const pointerDepthWeight = clampNumber(theme && theme.pointerDepthWeight, 0, Number.MAX_SAFE_INTEGER, 1);
    const pointerSideWeight = clampNumber(theme && theme.pointerSideWeight, 0, Number.MAX_SAFE_INTEGER, 1);
    const sFloor = gs.strokeFloor(strokeWeight);
    const eFloor = gs.extentFloor(strokeWeight);
    const ringW = gs.scale(radius, ringWidthFactor, eFloor);
    const majorTickLen = gs.scale(radius, clampNumber(ticks.majorLenFactor, 0, Number.MAX_SAFE_INTEGER, 0.08), eFloor);
    const majorTickWidth = gs.scaleStroke(
      radius,
      clampNumber(ticks.majorWidthFactor, 0, Number.MAX_SAFE_INTEGER, 0.02),
      strokeWeight,
      sFloor
    );
    const minorTickLen = gs.scale(radius, clampNumber(ticks.minorLenFactor, 0, Number.MAX_SAFE_INTEGER, 0.047), eFloor);
    const minorTickWidth = gs.scaleStroke(
      radius,
      clampNumber(ticks.minorWidthFactor, 0, Number.MAX_SAFE_INTEGER, 0.01),
      strokeWeight,
      sFloor
    );
    const arcLineWidth = gs.scaleStroke(
      radius,
      clampNumber(ring.arcLineWidthFactor, 0, Number.MAX_SAFE_INTEGER, 0.013),
      strokeWeight,
      sFloor
    );
    const pointerDepth = gs.scalePointer(
      radius,
      clampNumber(pointer.depthFactor, 0, Number.MAX_SAFE_INTEGER, 0.22),
      pointerDepthWeight,
      eFloor
    );
    const pointerSide = gs.scalePointer(
      radius,
      clampNumber(pointer.sideFactor, 0, Number.MAX_SAFE_INTEGER, 0.11),
      pointerSideWeight,
      eFloor
    );
    const labelInsetFactor = clampNumber(labels.insetFactor, 0, Number.MAX_SAFE_INTEGER, 1.8);
    const labelRadiusOffset = Math.max(1, Math.floor(ringW * labelInsetFactor * compactGeometryScale));
    const labelFontFactor = clampNumber(labels.fontFactor, 0.18, Number.MAX_SAFE_INTEGER, 0.18);
    const labelFontPx = Math.max(1, Math.floor(radius * labelFontFactor * compactGeometryScale));
    const fixedPointerDepth = Math.max(pointerDepth, Math.floor(ringW * 0.6));
    const markerLen = gs.scale(radius, MARKER_LENGTH_FACTOR * ringWidthFactor, eFloor);
    const markerWidth = gs.scalePointer(radius, MARKER_WIDTH_FACTOR * ringWidthFactor, pointerSideWeight, eFloor);
    const leftStrip = Math.max(0, Math.floor((width - radius * 2) / 2));
    const topStrip = Math.max(0, Math.floor((height - radius * 2) / 2));
    const labelRadius = Math.max(
      0,
      radius - Math.max(1, Math.floor(ringW * LABEL_SPRITE_RADIUS_FACTOR * compactGeometryScale))
    );

    return {
      D: radius * 2,
      R: radius,
      cx: cx,
      cy: cy,
      rOuter: radius,
      ringW: ringW,
      majorTickLen: majorTickLen,
      majorTickWidth: majorTickWidth,
      minorTickLen: minorTickLen,
      minorTickWidth: minorTickWidth,
      arcLineWidth: arcLineWidth,
      pointerDepth: pointerDepth,
      pointerSide: pointerSide,
      fixedPointerDepth: fixedPointerDepth,
      markerLen: markerLen,
      markerWidth: markerWidth,
      leftStrip: leftStrip,
      rightStrip: leftStrip,
      topStrip: topStrip,
      bottomStrip: topStrip,
      labelInsetVal: labelRadiusOffset,
      labelPx: labelFontPx,
      labelRadius: labelRadius
    };
  }

  /**
   * @param {DyniRect} contentRect
   * @param {DyniFullCircleGeom} geom
   * @returns {DyniFullCircleSlots}
   */
  function computeFlatSlots(contentRect, geom) {
    /** @type {DyniFullCircleSlots} */
    const slots = {
      leftTop: null,
      leftBottom: null,
      rightTop: null,
      rightBottom: null,
      top: null,
      bottom: null
    };
    const dialTop = geom.cy - geom.R;
    const dialHeight = geom.R * 2;
    const halfHeight = Math.floor(dialHeight / 2);

    if (geom.leftStrip > 0) {
      slots.leftTop = makeRect(contentRect.x, dialTop, geom.leftStrip, halfHeight);
      slots.leftBottom = makeRect(contentRect.x, dialTop + halfHeight, geom.leftStrip, dialHeight - halfHeight);
    }
    if (geom.rightStrip > 0) {
      const rightX = contentRect.x + contentRect.w - geom.rightStrip;
      slots.rightTop = makeRect(rightX, dialTop, geom.rightStrip, halfHeight);
      slots.rightBottom = makeRect(rightX, dialTop + halfHeight, geom.rightStrip, dialHeight - halfHeight);
    }

    return slots;
  }

  /**
   * @param {DyniRect} contentRect
   * @param {DyniFullCircleGeom} geom
   * @param {number} pad
   * @param {DyniRadialConfigMap | undefined} widgetLayout
   * @returns {DyniFullCircleSlots}
   */
  function computeHighSlots(contentRect, geom, pad, widgetLayout) {
    const topFactor = clampNumber(widgetLayout && widgetLayout.highTopFactor, 0, 2, 0.85);
    const bottomFactor = clampNumber(widgetLayout && widgetLayout.highBottomFactor, 0, 2, 0.85);
    const topHeight = Math.max(1, Math.floor((pad + geom.topStrip) * topFactor));
    const bottomHeight = Math.max(1, Math.floor((pad + geom.bottomStrip) * bottomFactor));
    return {
      leftTop: null,
      leftBottom: null,
      rightTop: null,
      rightBottom: null,
      top: makeRect(contentRect.x, contentRect.y, contentRect.w, topHeight),
      bottom: makeRect(contentRect.x, contentRect.y + contentRect.h - bottomHeight, contentRect.w, bottomHeight)
    };
  }

  /**
   * @param {DyniRect} contentRect
   * @param {DyniFullCircleGeom} geom
   * @param {number} compactGeometryScale
   * @returns {DyniFullCircleNormal}
   */
  function computeNormalLayout(contentRect, geom, compactGeometryScale) {
    return {
      safeRadius: Math.max(
        1,
        geom.rOuter -
          (geom.labelInsetVal + Math.max(1, Math.floor(geom.R * NORMAL_SAFE_EXTRA_FACTOR * compactGeometryScale)))
      ),
      compactCenterHeight: Math.max(
        1,
        Math.floor((contentRect.y + geom.topStrip) * NORMAL_COMPACT_CENTER_HEIGHT_FACTOR)
      ),
      dualCompactWidth: Math.max(1, Math.floor(geom.rOuter * NORMAL_DUAL_COMPACT_WIDTH_FACTOR)),
      dualCompactInset: Math.max(1, Math.floor(geom.R * NORMAL_DUAL_COMPACT_INSET_FACTOR * compactGeometryScale)),
      dualCompactHeight: Math.max(1, Math.floor(geom.rOuter * NORMAL_DUAL_COMPACT_HEIGHT_FACTOR))
    };
  }

  /**
   * @param {unknown} def
   * @param {DyniComponentContext} componentContext
   * @returns {DyniFullCircleRadialLayoutApi}
   */
  function create(def, componentContext) {
    const profileApi = componentContext.components.require("ResponsiveScaleProfile");
    const rectApi = componentContext.components.require("LayoutRectMath");
    const gs = componentContext.components.require("GeometryScale");
    const scaleHelpers = componentContext.components.require("TextLayoutScaleHelpers");
    clampNumber = componentContext.components.require("ValueMath").clampNumber;
    makeRect = rectApi.makeRect;

    /**
     * @param {unknown} W
     * @param {unknown} H
     * @param {unknown} thresholdNormal
     * @param {unknown} thresholdFlat
     * @returns {"flat" | "high" | "normal"}
     */
    function computeMode(W, H, thresholdNormal, thresholdFlat) {
      const width = Number(W) || 0;
      const height = Math.max(1, Number(H) || 0);
      const ratio = width / height;
      const normalThreshold = clampNumber(
        thresholdNormal,
        0.1,
        Number.MAX_SAFE_INTEGER,
        STRUCTURAL_RATIO_THRESHOLD_NORMAL
      );
      const flatThreshold = clampNumber(
        thresholdFlat,
        normalThreshold,
        Number.MAX_SAFE_INTEGER,
        STRUCTURAL_RATIO_THRESHOLD_FLAT
      );
      if (ratio > flatThreshold) {
        return "flat";
      }
      return ratio < normalThreshold ? "high" : "normal";
    }

    /**
     * @param {unknown} W
     * @param {unknown} H
     * @returns {DyniRadialInsets}
     */
    function computeInsets(W, H) {
      return profileApi.computeInsetPair(W, H, { scales: RESPONSIVE_SCALES }, PAD_RATIO, GAP_RATIO);
    }

    /**
     * @param {DyniFullCircleLayoutArgs} [args]
     * @returns {DyniFullCircleLayout}
     */
    function computeLayout(args) {
      const cfg = args || {};
      const W = Math.max(1, Math.floor(Number(cfg.W) || 0));
      const H = Math.max(1, Math.floor(Number(cfg.H) || 0));
      const insets = cfg.insets || computeInsets(W, H);
      const responsive =
        cfg.responsive || insets.responsive || profileApi.computeProfile(W, H, { scales: RESPONSIVE_SCALES });
      const textFillScale = scaleHelpers.resolveTextFillScale(responsive);
      const compactGeometryScale = scaleHelpers.resolveCompactGeometryScale(textFillScale);
      const mode = cfg.mode === "flat" || cfg.mode === "high" ? cfg.mode : "normal";
      const contentRect = makeRect(
        insets.pad,
        insets.pad,
        Math.max(1, W - insets.pad * 2),
        Math.max(1, H - insets.pad * 2)
      );
      const geom = computeModeGeometry(contentRect, cfg.theme, compactGeometryScale, gs);
      const labels = {
        radiusOffset: geom.labelInsetVal,
        fontPx: geom.labelPx,
        spriteRadius: geom.labelRadius
      };
      const slots =
        mode === "flat"
          ? computeFlatSlots(contentRect, geom)
          : mode === "high"
            ? computeHighSlots(contentRect, geom, insets.pad, cfg.layoutConfig)
            : {
                leftTop: null,
                leftBottom: null,
                rightTop: null,
                rightBottom: null,
                top: null,
                bottom: null
              };

      return {
        mode: mode,
        pad: insets.pad,
        gap: insets.gap,
        responsive: responsive,
        textFillScale: textFillScale,
        compactGeometryScale: compactGeometryScale,
        contentRect: contentRect,
        geom: geom,
        labels: labels,
        slots: slots,
        flat:
          mode === "flat"
            ? {
                leftTop: slots.leftTop,
                leftBottom: slots.leftBottom,
                rightTop: slots.rightTop,
                rightBottom: slots.rightBottom
              }
            : null,
        high:
          mode === "high"
            ? {
                top: slots.top,
                bottom: slots.bottom
              }
            : null,
        normal: computeNormalLayout(contentRect, geom, compactGeometryScale)
      };
    }

    return {
      id: "FullCircleRadialLayout",
      computeMode: computeMode,
      computeInsets: computeInsets,
      computeLayout: computeLayout
    };
  }

  return { id: "FullCircleRadialLayout", create: create };
});

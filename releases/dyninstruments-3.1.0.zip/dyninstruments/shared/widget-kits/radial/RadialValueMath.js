/**
 * Module: RadialValueMath - Radial geometry helpers plus ValueMath compatibility exports
 * Documentation: documentation/radial/gauge-shared-api.md
 * Depends: RadialAngleMath, ValueMath, RadialSectorMath
 */
(function (root, factory) {
  if (typeof define === "function" && define.amd) define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
  else { (root.DyniComponents = root.DyniComponents || {}).DyniRadialValueMath = factory(); }
}(this, function () {
  "use strict";

  function create(def, componentContext) {
    const angle = componentContext.components.require("RadialAngleMath");
    const value = componentContext.components.require("ValueMath");
    const sectorMath = componentContext.components.require("RadialSectorMath");

    function valueToAngle(rawValue, minV, maxV, arc, doClamp) {
      const opts = {
        min: Number(minV),
        max: Number(maxV),
        startDeg: Number(arc.startDeg),
        endDeg: Number(arc.endDeg),
        clamp: doClamp !== false
      };
      return angle.valueToAngle(rawValue, opts);
    }

    function angleToValue(angleDeg, minV, maxV, arc, doClamp) {
      const opts = {
        min: Number(minV),
        max: Number(maxV),
        startDeg: Number(arc.startDeg),
        endDeg: Number(arc.endDeg),
        clamp: doClamp !== false
      };
      return angle.angleToValue(angleDeg, opts);
    }

    function buildValueTickAngles(minV, maxV, majorStep, minorStep, arc) {
      const majors = [];
      const minors = [];
      if (!Number.isFinite(minV) || !Number.isFinite(maxV) || maxV <= minV) {
        return { majors: majors, minors: minors };
      }

      let minor = Math.abs(Number(minorStep));
      let major = Math.abs(Number(majorStep));
      if (!Number.isFinite(minor) || minor <= 0) minor = (maxV - minV) / 20;
      if (!Number.isFinite(major) || major <= 0) major = minor * 5;

      const steps = Math.max(1, Math.round((maxV - minV) / minor));
      for (let i = 0; i <= steps; i += 1) {
        let v = minV + i * minor;
        if (v > maxV) v = maxV;

        const rel = (v - minV) / major;
        const tickAngle = valueToAngle(v, minV, maxV, arc, true);
        (value.almostInt(rel, 1e-4) ? majors : minors).push(tickAngle);

        if (v === maxV) {
          break;
        }
      }

      if (!majors.length || !value.isApprox(majors[0], arc.startDeg, 1e-6)) majors.unshift(arc.startDeg);
      if (!value.isApprox(majors[majors.length - 1], arc.endDeg, 1e-6)) majors.push(arc.endDeg);

      return { majors: majors, minors: minors };
    }

    return Object.assign({}, value, {
      id: "RadialValueMath",
      valueToAngle: valueToAngle,
      angleToValue: angleToValue,
      buildValueTickAngles: buildValueTickAngles,
      sectorAngles: sectorMath.sectorAngles,
      buildHighEndSectors: sectorMath.buildHighEndSectors,
      buildLowEndSectors: sectorMath.buildLowEndSectors
    });
  }

  return { id: "RadialValueMath", create: create };
}));

/**
 * Module: DyniPlugin Component Loader - Dynamic JS/CSS loading with dependency resolution
 * Documentation: documentation/architecture/component-system.md
 * Depends: window.DyniComponents, runtime/asset-preloader.js
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const runtime = ns.runtime;
  const createAssetPreloader = runtime.createAssetPreloader;

  if (typeof createAssetPreloader !== "function") {
    throw new Error("dyninstruments: runtime.createAssetPreloader missing before runtime/component-loader.js load");
  }

  function loadCssOnce(id, href) {
    if (!href) {
      return Promise.resolve();
    }
    if (document.getElementById(id)) {
      return Promise.resolve();
    }

    return new Promise(function (res, rej) {
      const l = document.createElement("link");
      l.id = id;
      l.rel = "stylesheet";
      l.href = href;
      l.onload = function () {
        res();
      };
      l.onerror = rej;
      document.head.appendChild(l);
    });
  }

  const assetPreloader = createAssetPreloader(ns.baseUrl);
  runtime.assetUrl = function (relativePath) {
    return ns.baseUrl + relativePath;
  };
  runtime.getAsset = assetPreloader.getAsset;

  function createComponentLoader(components) {
    const runtimeLoadScriptOnce = runtime.loadScriptOnce;
    const registry = components;
    const loadCache = new Map();

    function validateComponentApi(componentId, componentDef, mod) {
      const apiShape = componentDef.apiShape || "factory";
      if (apiShape === "factory") {
        if (!mod || typeof mod.create !== "function") {
          throw new Error("Component not found or invalid: " + componentDef.globalKey);
        }
        return mod;
      }
      if (apiShape === "module") {
        if (!mod || typeof mod !== "object") {
          throw new Error("Component not found or invalid: " + componentDef.globalKey);
        }
        return mod;
      }
      throw new Error("Unsupported apiShape '" + apiShape + "' for component: " + componentId);
    }

    function loadComponent(id) {
      if (loadCache.has(id)) {
        return loadCache.get(id);
      }

      const m = registry[id];
      if (!m) {
        const p = Promise.reject(new Error("Unknown component: " + id));
        loadCache.set(id, p);
        return p;
      }

      const deps = m.deps || [];
      const depLoads = Promise.all(deps.map(loadComponent));

      const p = depLoads
        .then(function () {
          return Promise.all([
            loadCssOnce("dyni-css-" + id, m.css),
            runtimeLoadScriptOnce("dyni-js-" + id, m.js)
          ]);
        })
        .then(function () {
          const assetDecls = m.assets || [];
          if (assetDecls.length === 0) {
            return null;
          }
          return assetPreloader.preloadAssets(assetDecls);
        })
        .then(function () {
          const mod = root.DyniComponents[m.globalKey];
          return validateComponentApi(id, m, mod);
        });

      loadCache.set(id, p);
      return p;
    }

    function uniqueComponents(list) {
      const result = new Set();

      function addWithDeps(id) {
        if (!registry[id] || result.has(id)) {
          return;
        }
        result.add(id);
        const deps = registry[id].deps || [];
        deps.forEach(addWithDeps);
      }

      list.forEach(function (i) {
        addWithDeps(i.widget);
      });

      return Array.from(result);
    }

    return {
      loadComponent: loadComponent,
      uniqueComponents: uniqueComponents
    };
  }

  runtime.loadCssOnce = loadCssOnce;
  runtime.createComponentLoader = createComponentLoader;
}(this));

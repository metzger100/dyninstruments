/**
 * @file WindRadialWidget - Full-circle wind dial for angle and speed pairs
 * Documentation: documentation/widgets/wind-dial.md
 */
(function (root, factory) {
  if (typeof define === "function" && define.amd) define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
  else {
    (root.DyniComponents = root.DyniComponents || {}).DyniWindRadialWidget = factory();
  }
})(this, function () {
  "use strict";
  /** @typedef {Record<string, unknown> & { angle?: unknown, speed?: unknown, angleUnit?: unknown, speedUnit?: unknown, angleCaption?: unknown, speedCaption?: unknown, leadingZero?: boolean, stableDigits?: boolean, captionUnitScale?: unknown, easing?: boolean, layEnabled?: boolean, windRadialLayMin?: unknown, windRadialLayMax?: unknown, formatter?: unknown, formatterParameters?: unknown, default?: unknown }} DyniWindRadialProps */
  /** @typedef {{ caption: unknown, value: unknown, unit: unknown, secScale: number }} DyniWindRadialMetric */
  /** @typedef {{ angle: unknown, layEnabled: boolean, windRadialLayMin: number, windRadialLayMax: number, left: DyniWindRadialMetric, right: DyniWindRadialMetric }} DyniWindRadialDisplay */

  /** @param {unknown} def @param {DyniComponentContext} componentContext */
  function create(def, componentContext) {
    const engine = componentContext.components.require("FullCircleRadialEngine");
    const textLayout = componentContext.components.require("FullCircleRadialTextLayout");
    const valueMath = componentContext.components.require("ValueMath");
    const toOptionalFiniteNumber = valueMath.toOptionalFiniteNumber;
    const stableDigits = componentContext.components.require("StableDigits");
    const springMotion = componentContext.components.require("SpringEasing").createMotion({ wrap: 360 });
    const placeholderNormalize = componentContext.components.require("PlaceholderNormalize");

    /** @param {unknown} raw @param {DyniWindRadialProps} props @param {unknown} speedUnit @returns {string} */
    function windFormatSpeedText(raw, props, speedUnit) {
      const p = props || {};
      const defaultText = Object.prototype.hasOwnProperty.call(p, "default")
        ? placeholderNormalize.normalize(p.default, undefined)
        : placeholderNormalize.normalize(undefined, undefined);
      if (raw === null || raw === undefined || (typeof raw === "string" && raw.trim() === "")) {
        return defaultText;
      }
      const n = toOptionalFiniteNumber(raw);
      if (typeof n !== "number") {
        return defaultText;
      }

      const formatter = p.formatter;
      const formatterParameters = p.formatterParameters;

      return placeholderNormalize.normalize(
        String(
          componentContext.format.applyFormatter(n, {
            formatter: formatter,
            formatterParameters: formatterParameters,
            default: defaultText
          })
        ),
        Object.prototype.hasOwnProperty.call(p, "default")
          ? p.default
          : placeholderNormalize.normalize(undefined, undefined)
      );
    }

    /** @param {DyniFullCircleEngineState} state @param {DyniWindRadialProps} props @returns {DyniWindRadialDisplay} */
    function windDisplay(state, props) {
      const p = props || {};
      const defaultText = Object.prototype.hasOwnProperty.call(p, "default")
        ? placeholderNormalize.normalize(p.default, undefined)
        : placeholderNormalize.normalize(undefined, undefined);
      const angleUnit = p.angleUnit;
      const speedUnit = p.speedUnit;
      const secScale = state.value.clamp(p.captionUnitScale, 0.3, 3.0);
      let angleText = defaultText;
      if (state.value.isFiniteNumber(p.angle)) {
        angleText = state.value.formatAngle180(p.angle, !!p.leadingZero);
      }
      const speedText = windFormatSpeedText(p.speed, p, speedUnit);
      const stableDigitsEnabled = p.stableDigits === true;
      if (stableDigitsEnabled) {
        angleText = stableDigits.normalize(angleText, {
          integerWidth: stableDigits.resolveIntegerWidth(angleText, 2),
          reserveSignSlot: true
        }).padded;
      }
      const speedValueText = stableDigitsEnabled
        ? stableDigits.normalize(speedText, {
            integerWidth: stableDigits.resolveIntegerWidth(speedText, 2),
            reserveSignSlot: true
          }).padded
        : speedText;

      return {
        angle: p.angle,
        layEnabled: p.layEnabled !== false,
        windRadialLayMin: state.value.clamp(p.windRadialLayMin, 0, 180),
        windRadialLayMax: state.value.clamp(p.windRadialLayMax, 0, 180),
        left: {
          caption: p.angleCaption,
          value: angleText,
          unit: angleUnit,
          secScale: secScale
        },
        right: {
          caption: p.speedCaption,
          value: speedValueText,
          unit: speedUnit,
          secScale: secScale
        }
      };
    }

    const renderCanvas = engine.createRenderer({
      ratioProps: {
        normal: "windRadialRatioThresholdNormal",
        flat: "windRadialRatioThresholdFlat"
      },
      hideTextualMetricsProp: "windRadialHideTextualMetrics",
      cacheLayers: ["back", "front"],
      buildStaticKey: function (state, props) {
        const display = windDisplay(state, props);
        return {
          layEnabled: display.layEnabled,
          windRadialLayMin: display.windRadialLayMin,
          windRadialLayMax: display.windRadialLayMax,
          laylineStb: state.theme.colors.laylineStb,
          laylinePort: state.theme.colors.laylinePort
        };
      },
      rebuildLayer: function (layerCtx, layerName, state, props, api) {
        const display = windDisplay(state, props);
        if (layerName === "back") {
          if (display.layEnabled && display.windRadialLayMax > display.windRadialLayMin) {
            state.draw.drawAnnularSector(layerCtx, state.geom.cx, state.geom.cy, state.geom.rOuter, {
              startDeg: display.windRadialLayMin,
              endDeg: display.windRadialLayMax,
              thickness: state.geom.ringW,
              fillStyle: state.theme.colors.laylineStb,
              alpha: 1
            });
            state.draw.drawAnnularSector(layerCtx, state.geom.cx, state.geom.cy, state.geom.rOuter, {
              startDeg: -display.windRadialLayMax,
              endDeg: -display.windRadialLayMin,
              thickness: state.geom.ringW,
              fillStyle: state.theme.colors.laylinePort,
              alpha: 1
            });
          }
          api.drawFullCircleRing(layerCtx);
          return;
        }

        if (layerName === "front") {
          api.drawFullCircleTicks(layerCtx, {
            startDeg: -180,
            endDeg: 180,
            stepMajor: 30,
            stepMinor: 10,
            includeEnd: true
          });
          state.draw.drawLabels(layerCtx, state.geom.cx, state.geom.cy, state.geom.rOuter, {
            startDeg: -180,
            endDeg: 180,
            step: 30,
            includeEnd: true,
            radiusOffset: state.labels.radiusOffset,
            fontPx: state.labels.fontPx,
            weight: state.labelWeight,
            family: state.family,
            labelFormatter: /** @param {number} deg @returns {string} */ function (deg) {
              return String(deg);
            },
            labelFilter: /** @param {number} deg @returns {boolean} */ function (deg) {
              return deg !== -180 && deg !== 180;
            }
          });
        }
      },
      drawFrame: function (state, props, api) {
        const display = windDisplay(state, props);
        const easingEnabled = props.easing !== false;
        const motionCanvas = /** @type {object} */ (state.canvas);
        const easedAngle = springMotion.resolve(motionCanvas, display.angle, easingEnabled, Date.now());
        api.drawCachedLayer("back");
        if (state.value.isFiniteNumber(easedAngle)) {
          state.draw.drawPointerAtRim(state.ctx, state.geom.cx, state.geom.cy, state.geom.rOuter, easedAngle, {
            depth: state.geom.pointerDepth,
            halfWidth: Math.max(1, Math.floor(state.geom.pointerSide / 2)),
            fillStyle: state.theme.colors.pointer
          });
        }
        api.drawCachedLayer("front");
        if (springMotion.isActive(motionCanvas)) {
          return { wantsFollowUpFrame: true };
        }
      },
      drawMode: {
        flat: function (state, props) {
          const display = windDisplay(state, props);
          textLayout.drawDualModeText(state, "flat", display.left, display.right, {
            leftAlign: "left",
            rightAlign: "right"
          });
        },
        high: function (state, props) {
          const display = windDisplay(state, props);
          textLayout.drawDualModeText(state, "high", display.left, display.right);
        },
        normal: function (state, props) {
          const display = windDisplay(state, props);
          textLayout.drawDualModeText(state, "normal", display.left, display.right);
        }
      }
    });

    function translateFunction() {
      return {};
    }

    return {
      id: "WindRadialWidget",
      wantsHideNativeHead: true,
      renderCanvas: renderCanvas,
      translateFunction: translateFunction
    };
  }

  return { id: "WindRadialWidget", create };
});

// bootstrap-bundle.js — generated at release time, do not edit
/**
 * @file DyniPlugin Namespace - Internal namespace container
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  const ns = (root.DyniPlugin = root.DyniPlugin || {});
  const runtime = (ns.runtime = ns.runtime || {});
  ns.state = ns.state || {};
  ns.config = ns.config || {};
  ns.config.shared = ns.config.shared || {};
  ns.config.clusters = ns.config.clusters || [];

  /** @param {unknown} rootRef @returns {unknown} */
  runtime.getAvnavApi =
    runtime.getAvnavApi ||
    function (rootRef) {
      if (ns.avnavApi) {
        return ns.avnavApi;
      }
      return null;
    };
})(this);

/**
 * @file ValueMath - Canonical numeric, text, range, and gauge value helpers
 * Documentation: documentation/conventions/shared-helpers.md
 */
(function (root, factory) {
  if (typeof define === "function" && define.amd) define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
  else {
    (root.DyniComponents = root.DyniComponents || {}).DyniValueMath = factory();
  }
})(this, function () {
  "use strict";

  /**
   * @typedef {{ major: number, minor: number }} TickSteps
   * @typedef {{ default: TickSteps, ranges: Array<{ max: number, major: number, minor: number }>, plain: TickSteps }} TickProfile
   * @typedef {{ formatter?: unknown, formatterParameters?: unknown, default?: unknown }} GaugeDisplayProps
   * @typedef {(value: number, options: { formatter: unknown, formatterParameters: unknown, default: unknown }) => unknown} ApplyFormatter
   * @typedef {(text: unknown, defaultText: unknown) => string} NormalizeText
   */

  const hasOwn = Object.prototype.hasOwnProperty;

  /** @param {unknown} value @returns {value is number} */
  function isFiniteNumber(value) {
    return typeof value === "number" && Number.isFinite(value);
  }

  /** @param {unknown} value @returns {value is null | undefined} */
  function isNullish(value) {
    return value === null || value === undefined;
  }

  /** @param {unknown} value @returns {number | undefined} */
  function toFiniteNumber(value) {
    const n = Number(value);
    return Number.isFinite(n) ? n : undefined;
  }

  /** @param {unknown} value @param {number} defaultValue @returns {number} */
  function resolveFiniteNumber(value, defaultValue) {
    const n = Number(value);
    return Number.isFinite(n) ? n : defaultValue;
  }

  /** @param {unknown} value @returns {number | undefined} */
  function toOptionalFiniteNumber(value) {
    if (value === null || value === undefined) {
      return undefined;
    }
    if (typeof value === "string" && value.trim() === "") {
      return undefined;
    }
    const n = Number(value);
    return Number.isFinite(n) ? n : undefined;
  }

  /** @param {unknown} value @returns {number} */
  function toNumber(value) {
    const n = toFiniteNumber(value);
    return typeof n === "number" ? n : NaN;
  }

  /** @param {unknown} value @param {unknown} lo @param {unknown} hi @returns {number} */
  function clamp(value, lo, hi) {
    const low = toFiniteNumber(lo);
    const high = toFiniteNumber(hi);
    const safeLo = typeof low === "number" ? low : 0;
    const safeHi = typeof high === "number" ? high : safeLo;
    if (value === null || value === undefined) {
      return safeLo;
    }
    if (typeof value === "string" && value.trim() === "") {
      return safeLo;
    }
    const n = isFiniteNumber(value) ? value : toFiniteNumber(value);
    if (typeof n !== "number") {
      return safeLo;
    }
    return Math.max(safeLo, Math.min(safeHi, n));
  }

  /** @param {unknown} value @param {number} defaultValue @returns {number} */
  function clampPositive(value, defaultValue) {
    const n = toFiniteNumber(value);
    return typeof n === "number" && n > 0 ? n : defaultValue;
  }

  /** @param {unknown} value @param {unknown} name @returns {object} */
  function ensureObject(value, name) {
    if (!value || typeof value !== "object") {
      throw new Error(String(name || "value") + " must be an object");
    }
    return value;
  }

  /** @param {unknown} value @returns {object} */
  function toObject(value) {
    return value && typeof value === "object" ? value : {};
  }

  /** @param {unknown} value @returns {string} */
  function toText(value) {
    return value === null || value === undefined ? "" : String(value);
  }

  /** @param {unknown} value @returns {string} */
  function trimText(value) {
    return value === null || value === undefined ? "" : String(value).trim();
  }

  /** @param {unknown} value @param {number} min @param {number} max @param {number} defaultValue @returns {number} */
  function clampNumber(value, min, max, defaultValue) {
    if (value === null || value === undefined) {
      return defaultValue;
    }
    if (typeof value === "string" && value.trim() === "") {
      return defaultValue;
    }
    const n = Number(value);
    if (!Number.isFinite(n)) {
      return defaultValue;
    }
    return Math.max(min, Math.min(max, n));
  }

  /** @param {unknown} value @returns {value is object} */
  function isObject(value) {
    return !!value && typeof value === "object";
  }

  /** @param {unknown} value @param {number} defaultValue @returns {number} */
  function toSafeInteger(value, defaultValue) {
    const n = toFiniteNumber(value);
    if (typeof n !== "number") {
      return defaultValue;
    }
    return Math.round(n);
  }

  /** @param {unknown} value @returns {boolean} */
  function hasText(value) {
    return value !== null && value !== undefined && String(value).trim().length > 0;
  }

  /** @param {unknown} value @returns {string | undefined} */
  function keyToText(value) {
    return typeof value === "string" ? value : JSON.stringify(value);
  }

  /** @param {unknown} valueText @param {unknown} displayUnit @param {unknown} defaultText @returns {string} */
  function appendUnit(valueText, displayUnit, defaultText) {
    const text = toText(valueText) || toText(defaultText);
    const unit = displayUnit === null || displayUnit === undefined ? "" : String(displayUnit);
    return unit ? text + unit : text;
  }

  /** @param {unknown} value @returns {number} */
  function textLength(value) {
    if (value === null || value === undefined) {
      return 0;
    }
    return String(value).length;
  }

  /** @param {number} from @param {number} to @param {number} t @returns {number} */
  function lerp(from, to, t) {
    return from + (to - from) * t;
  }

  /** @param {number} value @param {unknown} eps @returns {boolean} */
  function almostInt(value, eps) {
    const epsilon = Number.isFinite(Number(eps)) ? Number(eps) : 1e-6;
    return Math.abs(value - Math.round(value)) <= epsilon;
  }

  /** @param {unknown} a @param {unknown} b @param {unknown} eps @returns {boolean} */
  function isApprox(a, b, eps) {
    const epsilon = Number.isFinite(Number(eps)) ? Number(eps) : 1e-6;
    return Math.abs(Number(a) - Number(b)) <= epsilon;
  }

  /** @param {unknown} text @returns {string} */
  function extractNumberText(text) {
    const match = String(text).match(new RegExp("-?\\d+(?:\\.\\d+)?"));
    return match ? match[0] : "";
  }

  /** @param {unknown} minRaw @param {unknown} maxRaw @param {unknown} defaultMin @param {unknown} defaultMax @returns {{ min: number, max: number, range: number }} */
  function normalizeRange(minRaw, maxRaw, defaultMin, defaultMax) {
    let minV = toNumber(minRaw);
    let maxV = toNumber(maxRaw);

    if (!Number.isFinite(minV)) minV = toNumber(defaultMin);
    if (!Number.isFinite(minV)) minV = 0;

    if (!Number.isFinite(maxV)) maxV = toNumber(defaultMax);
    if (!Number.isFinite(maxV)) maxV = minV + 1;

    if (maxV <= minV) maxV = minV + 1;
    return { min: minV, max: maxV, range: maxV - minV };
  }

  /** @param {number} W @param {number} H @returns {number} */
  function computePad(W, H) {
    return Math.max(6, Math.floor(Math.min(W, H) * 0.04));
  }

  /** @param {number} W @param {number} H @returns {number} */
  function computeGap(W, H) {
    return Math.max(6, Math.floor(Math.min(W, H) * 0.03));
  }

  /** @param {number} ratio @param {number} thresholdNormal @param {number} thresholdFlat @returns {"high" | "flat" | "normal"} */
  function computeMode(ratio, thresholdNormal, thresholdFlat) {
    if (ratio < thresholdNormal) {
      return "high";
    }
    if (ratio > thresholdFlat) {
      return "flat";
    }
    return "normal";
  }

  /** @param {unknown} raw @param {GaugeDisplayProps | undefined} props @param {ApplyFormatter} applyFormatter @param {NormalizeText} normalize @param {unknown} defaultFormatter @param {unknown} defaultFormatterParameters @returns {{ num: number, text: unknown }} */
  function formatGaugeDisplay(raw, props, applyFormatter, normalize, defaultFormatter, defaultFormatterParameters) {
    const p = props || {};
    const defaultText = hasOwn.call(p, "default") ? p.default : normalize(undefined, undefined);
    const numericRaw = toOptionalFiniteNumber(raw);
    if (typeof numericRaw !== "number") {
      return { num: NaN, text: defaultText };
    }

    const formatter = hasOwn.call(p, "formatter") ? p.formatter : defaultFormatter;
    const formatterParameters = hasOwn.call(p, "formatterParameters")
      ? p.formatterParameters
      : defaultFormatterParameters;
    const formatted = normalize(
      String(
        applyFormatter(numericRaw, {
          formatter: formatter,
          formatterParameters: formatterParameters,
          default: defaultText
        })
      ),
      defaultText
    );
    const numberText = extractNumberText(formatted);
    const num = numberText ? Number(numberText) : NaN;
    return Number.isFinite(num) ? { num: num, text: numberText } : { num: NaN, text: defaultText };
  }

  /** @type {Record<string, TickProfile>} */
  const tickProfiles = {
    standard: {
      default: { major: 10, minor: 2 },
      ranges: [
        { max: 6, major: 1, minor: 0.5 },
        { max: 12, major: 2, minor: 1 },
        { max: 30, major: 5, minor: 1 },
        { max: 60, major: 10, minor: 2 },
        { max: 120, major: 20, minor: 5 }
      ],
      plain: { major: 50, minor: 10 }
    },
    temperature: {
      default: { major: 10, minor: 2 },
      ranges: [
        { max: 8, major: 1, minor: 0.5 },
        { max: 20, major: 2, minor: 1 },
        { max: 50, major: 5, minor: 1 },
        { max: 100, major: 10, minor: 2 },
        { max: 200, major: 20, minor: 5 }
      ],
      plain: { major: 50, minor: 10 }
    },
    voltage: {
      default: { major: 1, minor: 0.2 },
      ranges: [
        { max: 3, major: 0.5, minor: 0.1 },
        { max: 6, major: 1, minor: 0.2 },
        { max: 12, major: 2, minor: 0.5 },
        { max: 30, major: 5, minor: 1 },
        { max: 60, major: 10, minor: 2 },
        { max: 120, major: 20, minor: 5 }
      ],
      plain: { major: 50, minor: 10 }
    }
  };

  /** @param {unknown} range @param {string} profileName @returns {TickSteps} */
  function resolveTickSteps(range, profileName) {
    const profile = tickProfiles[profileName] || tickProfiles.standard;
    const n = Number(range);
    if (!Number.isFinite(n) || n <= 0) {
      return { major: profile.default.major, minor: profile.default.minor };
    }
    for (let i = 0; i < profile.ranges.length; i += 1) {
      const step = profile.ranges[i];
      if (n <= step.max) {
        return { major: step.major, minor: step.minor };
      }
    }
    return { major: profile.plain.major, minor: profile.plain.minor };
  }

  /** @param {unknown} range @returns {TickSteps} */
  function resolveStandardTickSteps(range) {
    return resolveTickSteps(range, "standard");
  }

  /** @param {unknown} range @returns {TickSteps} */
  function resolveTemperatureTickSteps(range) {
    return resolveTickSteps(range, "temperature");
  }

  /** @param {unknown} range @returns {TickSteps} */
  function resolveVoltageTickSteps(range) {
    return resolveTickSteps(range, "voltage");
  }

  /** @param {unknown} value @param {boolean | undefined} leadingZero @returns {string} */
  function formatAngle180(value, leadingZero) {
    const n = toOptionalFiniteNumber(value);
    if (typeof n !== "number") {
      return "";
    }
    let a = ((((n + 180) % 360) + 360) % 360) - 180;
    if (a === 180) a = -180;
    const rounded = Math.round(Math.abs(a));
    let out = String(rounded);
    if (leadingZero) out = out.padStart(3, "0");
    if (a < 0) out = "-" + out;
    return out;
  }

  /** @param {unknown} value @param {boolean | undefined} leadingZero @returns {string} */
  function formatDirection360(value, leadingZero) {
    const n = toOptionalFiniteNumber(value);
    if (typeof n !== "number") {
      return "";
    }
    let a = n % 360;
    if (a < 0) a += 360;
    const rounded = Math.round(a) % 360;
    let out = String(rounded);
    if (leadingZero) out = out.padStart(3, "0");
    return out;
  }

  /** @param {unknown} value @returns {string} */
  function formatMajorLabel(value) {
    const n = toOptionalFiniteNumber(value);
    if (typeof n !== "number") {
      return "";
    }
    if (almostInt(n, 1e-6)) {
      return String(Math.round(n));
    }
    const rounded = Math.round(n * 1000) / 1000;
    return String(rounded);
  }

  function create() {
    return {
      id: "ValueMath",
      isFiniteNumber: isFiniteNumber,
      isNullish: isNullish,
      toFiniteNumber: toFiniteNumber,
      resolveFiniteNumber: resolveFiniteNumber,
      toOptionalFiniteNumber: toOptionalFiniteNumber,
      clamp: clamp,
      clampPositive: clampPositive,
      ensureObject: ensureObject,
      toObject: toObject,
      toText: toText,
      trimText: trimText,
      clampNumber: clampNumber,
      isObject: isObject,
      toSafeInteger: toSafeInteger,
      hasText: hasText,
      keyToText: keyToText,
      appendUnit: appendUnit,
      textLength: textLength,
      lerp: lerp,
      almostInt: almostInt,
      isApprox: isApprox,
      extractNumberText: extractNumberText,
      normalizeRange: normalizeRange,
      computePad: computePad,
      computeGap: computeGap,
      computeMode: computeMode,
      formatGaugeDisplay: formatGaugeDisplay,
      resolveTickSteps: resolveTickSteps,
      resolveStandardTickSteps: resolveStandardTickSteps,
      resolveTemperatureTickSteps: resolveTemperatureTickSteps,
      resolveVoltageTickSteps: resolveVoltageTickSteps,
      resolveSemicircleTickSteps: resolveTickSteps,
      resolveStandardSemicircleTickSteps: resolveStandardTickSteps,
      resolveTemperatureSemicircleTickSteps: resolveTemperatureTickSteps,
      resolveVoltageSemicircleTickSteps: resolveVoltageTickSteps,
      formatAngle180: formatAngle180,
      formatDirection360: formatDirection360,
      formatMajorLabel: formatMajorLabel
    };
  }

  return { id: "ValueMath", create: create };
});

/**
 * @file DyniPlugin Format Runtime - Runtime formatter dispatch service
 * Documentation: documentation/shared/helpers.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const runtime = /** @type {DyniRuntimeNamespace & { getAvnavApi(rootRef: unknown): unknown }} */ (ns.runtime);
  const hasOwn = Object.prototype.hasOwnProperty;
  const valueMathModule = /** @type {{ create(): DyniValueMathApi }} */ (
    /** @type {unknown} */ (root.DyniComponents && root.DyniComponents.DyniValueMath)
  );
  const isNullish = valueMathModule.create().isNullish;

  /**
   * @param {unknown} raw
   * @param {DyniFormatterOptions|null|undefined} props
   * @returns {unknown}
   */
  function applyFormatter(raw, props) {
    const p = /** @type {DyniFormatterOptions} */ (props || {});
    if (isNullish(raw) || Number.isNaN(raw)) {
      if (hasOwn.call(p, "default")) {
        return p.default;
      }
      return "---";
    }
    if (typeof raw === "string" && raw.trim() === "") {
      if (hasOwn.call(p, "default")) {
        return p.default;
      }
      return "---";
    }

    const fpRaw = p.formatterParameters;
    /** @type {unknown[]} */
    let fp;
    if (Array.isArray(fpRaw)) {
      fp = fpRaw;
    } else if (typeof fpRaw === "string") {
      fp = fpRaw.split(",");
    } else {
      fp = [];
    }
    const formatterArgs = /** @type {[unknown, ...unknown[]]} */ ([raw].concat(fp));
    const avnavApi = /** @type {DyniAvnavApi|null} */ (runtime.getAvnavApi(root));
    try {
      if (typeof p.formatter === "function") {
        const formatter = /** @type {DyniFormatterCallback} */ (p.formatter);
        return formatter.apply(null, formatterArgs);
      }
      if (typeof p.formatter === "string" && avnavApi && avnavApi.formatter) {
        const formatter = avnavApi.formatter[p.formatter];
        if (typeof formatter === "function") {
          return formatter.apply(avnavApi.formatter, formatterArgs);
        }
      }
    } catch (e) {
      /* intentional: formatter failures fall back to default/raw formatting */
    }

    return String(raw);
  }

  runtime.format = Object.freeze({
    applyFormatter: applyFormatter
  });
})(this);

/**
 * @file DyniPlugin Canvas Runtime - HiDPI canvas setup service
 * Documentation: documentation/shared/helpers.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const runtime = /** @type {DyniRuntimeNamespace} */ (ns.runtime);
  const layoutByCanvas = new WeakMap();

  /** @param {HTMLCanvasElement} canvas @returns {DyniCanvasSurface} */
  function setupCanvas(canvas) {
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      throw new Error("dyninstruments: runtime.canvas.setupCanvas() requires a 2D canvas context");
    }
    const dpr = root.devicePixelRatio || 1;

    const clientWidth = canvas.clientWidth;
    const clientHeight = canvas.clientHeight;
    const cachedLayout = layoutByCanvas.get(canvas);
    const layout =
      cachedLayout && cachedLayout.clientWidth === clientWidth && cachedLayout.clientHeight === clientHeight
        ? cachedLayout
        : (function () {
            const rect = canvas.getBoundingClientRect();
            const nextLayout = {
              clientWidth: clientWidth,
              clientHeight: clientHeight,
              cssWidth: rect.width,
              cssHeight: rect.height
            };
            layoutByCanvas.set(canvas, nextLayout);
            return nextLayout;
          })();

    const w = Math.max(1, Math.round(layout.cssWidth * dpr));
    const h = Math.max(1, Math.round(layout.cssHeight * dpr));
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return {
      ctx: ctx,
      W: Math.max(1, Math.round(layout.cssWidth)),
      H: Math.max(1, Math.round(layout.cssHeight))
    };
  }

  runtime.canvas = Object.freeze({
    setupCanvas: setupCanvas
  });
})(this);

/**
 * @file DyniPlugin DOM Runtime - Root and mode DOM helpers
 * Documentation: documentation/shared/helpers.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const runtime = /** @type {DyniRuntimeNamespace} */ (ns.runtime);

  /** @param {unknown} target @returns {DyniComposedTreeNode | null} */
  function resolveTargetNode(target) {
    const candidate = target && typeof target === "object" ? /** @type {DyniComposedTreeTarget} */ (target) : null;
    if (!candidate) {
      return null;
    }
    if (typeof candidate.nodeType === "number") {
      return /** @type {DyniComposedTreeNode} */ (candidate);
    }
    if (typeof candidate.composedPath === "function") {
      const path = candidate.composedPath();
      const firstNode = Array.isArray(path) && path.length ? path[0] : null;
      if (firstNode && typeof firstNode.nodeType === "number") {
        return firstNode;
      }
    }
    if (candidate.target && typeof candidate.target.nodeType === "number") {
      return candidate.target;
    }
    return null;
  }

  /** @param {DyniComposedTreeNode | null | undefined} node @returns {DyniComposedTreeNode | null} */
  function resolveParentInComposedTree(node) {
    if (!node) {
      return null;
    }
    if (node.nodeType === 11 && node.host) {
      return node.host;
    }
    if (node.parentNode) {
      return node.parentNode;
    }
    if (node.host) {
      return node.host;
    }
    return null;
  }

  const pluginRootCache = new WeakMap();

  /** @param {unknown} target @returns {Element} */
  function requirePluginRoot(target) {
    var node = resolveTargetNode(target);
    if (!node) {
      throw new Error("dyninstruments: runtime.dom.requirePluginRoot() requires a committed .widget.dyniplugin root");
    }

    var cached = pluginRootCache.get(node);
    if (cached) {
      return cached;
    }

    /** @type {DyniComposedTreeNode | null} */
    var walker = node;
    while (walker) {
      if (walker.nodeType === 1 && typeof walker.closest === "function") {
        var rootEl = walker.closest(".widget.dyniplugin");
        if (rootEl) {
          pluginRootCache.set(node, rootEl);
          return rootEl;
        }
      }
      walker = resolveParentInComposedTree(walker);
    }
    throw new Error("dyninstruments: runtime.dom.requirePluginRoot() requires a committed .widget.dyniplugin root");
  }

  /** @param {Element | null | undefined} rootEl @returns {boolean} */
  function getNightModeState(rootEl) {
    return !!(rootEl && typeof rootEl.closest === "function" && rootEl.closest(".nightMode"));
  }

  runtime.dom = Object.freeze({
    requirePluginRoot: requirePluginRoot,
    getNightModeState: getNightModeState
  });
})(this);

/**
 * @file DyniPlugin Editable Defaults - Builds defaults from editable parameters
 * Documentation: documentation/avnav-api/editable-parameters.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const runtime = /** @type {DyniRuntimeNamespace} */ (ns.runtime);

  /**
   * @param {DyniEditableParameters|null|undefined} editableParams
   * @returns {Record<string, unknown>}
   */
  function defaultsFromEditableParams(editableParams) {
    const out = /** @type {Record<string, unknown>} */ ({});
    if (!editableParams) {
      return out;
    }

    Object.keys(editableParams).forEach(function (k) {
      const spec = editableParams[k];
      if (spec && typeof spec === "object" && Object.prototype.hasOwnProperty.call(spec, "default")) {
        const parameterSpec = /** @type {DyniEditableParameterSpec} */ (spec);
        out[k] = parameterSpec.default;
      }
    });

    return out;
  }

  /**
   * @param {DyniEditableParameters|null|undefined} editableParams
   * @returns {Record<string, unknown>}
   */
  function editableParamsForRegistration(editableParams) {
    const out = /** @type {Record<string, unknown>} */ ({});
    if (!editableParams) {
      return out;
    }

    Object.keys(editableParams).forEach(function (k) {
      const spec = editableParams[k];
      if (spec && typeof spec === "object" && /** @type {DyniEditableParameterSpec} */ (spec).internal === true) {
        return;
      }
      out[k] = spec;
    });

    return out;
  }

  runtime.defaultsFromEditableParams = defaultsFromEditableParams;
  runtime.editableParamsForRegistration = editableParamsForRegistration;
})(this);

/**
 * @file DyniPlugin Theme Token Catalog - declarative token definition and preset data
 * Documentation: documentation/shared/theme-tokens.md
 */
(function (root) {
  "use strict";

  /** @typedef {Record<string, unknown>} DyniThemeValues */
  /** @typedef {{ path: string, inputVar: string, type: string, default?: unknown, defaultByMode?: Record<string, unknown>, outputVar?: string, defaultFrom?: string, compatibilityInputVar?: string, [key: string]: unknown }} DyniThemeTokenDefinition */
  /** @typedef {{ base?: DyniThemeValues, day?: DyniThemeValues, night?: DyniThemeValues, [mode: string]: DyniThemeValues | undefined }} DyniThemePreset */
  /** @typedef {{ TOKEN_DEFS: readonly DyniThemeTokenDefinition[], PRESETS: Readonly<Record<string, DyniThemePreset>> }} DyniThemeTokenCatalog */
  /** @typedef {DyniRuntimeNamespace & { createThemeTokenCatalog?: () => DyniThemeTokenCatalog }} DyniThemeTokenCatalogRuntime */
  /** @typedef {{ DyniPlugin: DyniPluginNamespace & { runtime: DyniThemeTokenCatalogRuntime } }} DyniThemeTokenCatalogRoot */

  const ns = /** @type {DyniThemeTokenCatalogRoot} */ (/** @type {unknown} */ (root)).DyniPlugin;
  const runtime = ns.runtime;

  const DEFAULT_FONT_STACK =
    '"Roboto","Inter","SF Pro Text",-apple-system,"Segoe UI","Helvetica Neue","Noto Sans",Ubuntu,Cantarell,"Liberation Sans",Arial,system-ui,"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji"';
  const DEFAULT_MONO_STACK =
    '"Roboto Mono", ui-monospace, "SF Mono", "Menlo", "Consolas", "Liberation Mono", monospace';

  /** @param {string} path @param {string} inputVar @param {string} type @param {[unknown?, (Record<string, unknown> | undefined)?, (string | undefined)?, (string | undefined)?, (string | undefined)?]} options @returns {DyniThemeTokenDefinition} */
  function defineToken(path, inputVar, type, ...options) {
    const [defaultValue, defaultByMode, outputVar, defaultFrom, deprecatedInputVar] = options;
    return {
      path: path,
      inputVar: inputVar,
      type: type,
      default: defaultValue,
      defaultByMode: defaultByMode || undefined,
      outputVar: outputVar || undefined,
      defaultFrom: defaultFrom || undefined,
      deprecatedInputVar: deprecatedInputVar || undefined
    };
  }

  const TOKEN_DEFS = Object.freeze([
    defineToken(
      "surface.fg",
      "--dyni-fg",
      "color",
      "#000000",
      { night: "rgba(252, 11, 11, 0.60)" },
      "--dyni-theme-surface-fg"
    ),
    defineToken("surface.bg", "--dyni-bg", "color", "#ffffff", { night: "black" }, "--dyni-theme-surface-bg"),
    defineToken("surface.border", "--dyni-border", "color", undefined, undefined, "--dyni-theme-surface-border"),
    defineToken("font.family", "--dyni-font", "string", DEFAULT_FONT_STACK, undefined, "--dyni-theme-font-family"),
    defineToken(
      "font.familyMono",
      "--dyni-font-mono",
      "string",
      DEFAULT_MONO_STACK,
      undefined,
      "--dyni-theme-font-family-mono"
    ),
    defineToken("font.weight", "--dyni-font-weight", "number", 700, undefined, "--dyni-theme-font-weight"),
    defineToken("font.labelWeight", "--dyni-label-weight", "number", 700, undefined, "--dyni-theme-font-label-weight"),
    defineToken("opacity.caption", "--dyni-caption-opacity", "number", 1.0, undefined, "--dyni-theme-opacity-caption"),
    defineToken("opacity.unit", "--dyni-unit-opacity", "number", 1.0, undefined, "--dyni-theme-opacity-unit"),

    defineToken("colors.info", "--dyni-info", "color", "#3366cc", { night: "#cc2222" }),
    defineToken("colors.pointer", "--dyni-pointer", "color", undefined, undefined, undefined, "colors.info"),
    defineToken("colors.warning", "--dyni-warning", "color", "#e0a92e", { night: "#8b6914" }),
    defineToken("colors.alarm", "--dyni-alarm", "color", "#d9534a", { night: "rgba(250, 88, 74, 0.60)" }),
    defineToken("colors.ok", "--dyni-ok", "color", "#2e9e6b", { night: "rgba(112, 243, 175, 0.60)" }),
    defineToken(
      "colors.alarmWidget.bg",
      "--dyni-alarm-widget-bg",
      "color",
      undefined,
      undefined,
      undefined,
      "colors.alarm"
    ),
    defineToken("colors.alarmWidget.fg", "--dyni-alarm-widget-fg", "color", "#ffffff", { night: "#ffffff" }),
    defineToken(
      "colors.alarmWidget.strip",
      "--dyni-alarm-widget-strip",
      "color",
      undefined,
      undefined,
      undefined,
      "colors.ok"
    ),
    defineToken("colors.laylineStb", "--dyni-layline-stb", "color", undefined, undefined, undefined, "colors.ok"),
    defineToken("colors.laylinePort", "--dyni-layline-port", "color", undefined, undefined, undefined, "colors.alarm"),
    defineToken("colors.ais.warning", "--dyni-ais-warning", "color", undefined, undefined, undefined, "colors.alarm"),
    defineToken("colors.ais.nearest", "--dyni-ais-nearest", "color", undefined, undefined, undefined, "colors.ok"),
    defineToken(
      "colors.ais.tracking",
      "--dyni-ais-tracking",
      "color",
      undefined,
      undefined,
      undefined,
      "colors.warning"
    ),
    defineToken("colors.ais.normal", "--dyni-ais-normal", "color", undefined, undefined, undefined, "colors.ok"),
    defineToken(
      "colors.regatta.barWarning",
      "--dyni-regatta-bar-warning",
      "color",
      undefined,
      undefined,
      "--dyni-theme-regatta-bar-warning",
      "colors.warning",
      "--dyni-regatta-barWarning"
    ),
    defineToken(
      "colors.regatta.barCritical",
      "--dyni-regatta-bar-critical",
      "color",
      undefined,
      undefined,
      "--dyni-theme-regatta-bar-critical",
      "colors.alarm",
      "--dyni-regatta-barCritical"
    ),
    defineToken(
      "colors.regatta.barDefault",
      "--dyni-regatta-bar-default",
      "color",
      undefined,
      undefined,
      "--dyni-theme-regatta-bar-default",
      "colors.info",
      "--dyni-regatta-barDefault"
    ),

    defineToken("strokeWeight", "--dyni-stroke-weight", "number", 1.28),
    defineToken("pointerDepthWeight", "--dyni-pointer-depth-weight", "number", 1.15),
    defineToken("pointerSideWeight", "--dyni-pointer-side-weight", "number", 2.0),
    defineToken(
      "regatta.buttonStrokeWeight",
      "--dyni-regatta-button-stroke-weight",
      "number",
      undefined,
      undefined,
      undefined,
      "strokeWeight"
    ),

    defineToken("radial.ticks.majorLenFactor", "--dyni-radial-tick-major-len-factor", "number", 0.087),
    defineToken("radial.ticks.majorWidthFactor", "--dyni-radial-tick-major-width-factor", "number", 0.022),
    defineToken("radial.ticks.minorLenFactor", "--dyni-radial-tick-minor-len-factor", "number", 0.051),
    defineToken("radial.ticks.minorWidthFactor", "--dyni-radial-tick-minor-width-factor", "number", 0.011),
    defineToken("radial.pointer.sideFactor", "--dyni-radial-pointer-side-factor", "number", 0.11),
    defineToken("radial.pointer.depthFactor", "--dyni-radial-pointer-depth-factor", "number", 0.22),
    defineToken("radial.ring.arcLineWidthFactor", "--dyni-radial-arc-linewidth-factor", "number", 0.0145),
    defineToken("radial.ring.widthFactor", "--dyni-radial-ring-width", "number", 0.16),
    defineToken("radial.labels.insetFactor", "--dyni-radial-label-inset", "number", 1.8),
    defineToken("radial.labels.fontFactor", "--dyni-radial-label-font", "number", 0.14),
    defineToken(
      "radial.fullCircle.normal.innerMarginFactor",
      "--dyni-radial-fullcircle-normal-inner-margin",
      "number",
      0.03
    ),
    defineToken(
      "radial.fullCircle.normal.minHeightFactor",
      "--dyni-radial-fullcircle-normal-min-height",
      "number",
      0.45
    ),
    defineToken("radial.fullCircle.normal.dualGapFactor", "--dyni-radial-fullcircle-normal-dual-gap", "number", 0.05),
    defineToken(
      "radial.fullCircle.ticks.majorLenFactor",
      "--dyni-radial-fullcircle-tick-major-len-factor",
      "number",
      0.131
    ),
    defineToken(
      "radial.fullCircle.ticks.minorLenFactor",
      "--dyni-radial-fullcircle-tick-minor-len-factor",
      "number",
      0.077
    ),

    defineToken("linear.track.widthFactor", "--dyni-linear-track-width", "number", 0.16),
    defineToken("linear.track.lineWidthFactor", "--dyni-linear-track-linewidth-factor", "number", 0.018),
    defineToken("linear.ticks.majorLenFactor", "--dyni-linear-tick-major-len-factor", "number", 0.109),
    defineToken("linear.ticks.majorWidthFactor", "--dyni-linear-tick-major-width-factor", "number", 0.027),
    defineToken("linear.ticks.minorLenFactor", "--dyni-linear-tick-minor-len-factor", "number", 0.064),
    defineToken("linear.ticks.minorWidthFactor", "--dyni-linear-tick-minor-width-factor", "number", 0.014),
    defineToken("linear.pointer.sideFactor", "--dyni-linear-pointer-side-factor", "number", 0.12),
    defineToken("linear.pointer.depthFactor", "--dyni-linear-pointer-depth-factor", "number", 0.24),
    defineToken("linear.labels.insetFactor", "--dyni-linear-label-inset", "number", 1.8),
    defineToken("linear.labels.fontFactor", "--dyni-linear-label-font", "number", 0.14)
  ]);

  /** @type {Readonly<Record<string, DyniThemePreset>>} */
  const PRESETS = Object.freeze({
    default: {
      base: {},
      night: {
        surface: {
          fg: "rgba(252, 11, 11, 0.60)",
          bg: "black"
        },
        colors: {
          info: "#cc2222",
          warning: "#8b6914",
          alarm: "rgba(250, 88, 74, 0.60)",
          ok: "rgba(112, 243, 175, 0.60)",
          alarmWidget: {
            fg: "#ffffff"
          }
        }
      }
    },
    slim: {
      base: {
        strokeWeight: 0.66,
        pointerDepthWeight: 1.0,
        pointerSideWeight: 0.72,
        font: { labelWeight: 400 }
      }
    },
    bold: {
      base: {
        strokeWeight: 2.2,
        pointerDepthWeight: 1.8,
        pointerSideWeight: 2.3
      }
    },
    darkmode: {
      base: {
        surface: {
          fg: "#ffffff",
          bg: "#000000",
          border: "#ffffff"
        },
        colors: {
          info: "#5aa2ff",
          warning: "#ffd24a",
          alarm: "#ff6b5c",
          ok: "#5fd68b",
          alarmWidget: {
            fg: "#ffffff"
          }
        }
      },
      night: {
        surface: {
          fg: "rgba(252, 11, 11, 0.60)",
          bg: "black",
          border: "rgba(252, 11, 11, 0.60)"
        },
        colors: {
          info: "#cc2222",
          warning: "#8b6914",
          alarm: "rgba(250, 88, 74, 0.60)",
          ok: "rgba(112, 243, 175, 0.60)",
          alarmWidget: {
            fg: "#ffffff"
          }
        }
      }
    },
    highcontrast: {
      base: {
        strokeWeight: 1.32,
        pointerDepthWeight: 1.15,
        pointerSideWeight: 2.15,
        colors: {
          info: "#0057ff",
          warning: "#ffd200",
          alarm: "#ff3b2f",
          ok: "#008f5a",
          alarmWidget: {
            fg: "#ffffff"
          }
        }
      },
      night: {
        colors: {
          info: "#cc2222",
          warning: "#8b6914",
          alarm: "rgba(250, 88, 74, 0.60)",
          ok: "rgba(112, 243, 175, 0.60)",
          alarmWidget: {
            fg: "#ffffff"
          }
        }
      }
    }
  });

  runtime.createThemeTokenCatalog = function createThemeTokenCatalog() {
    return {
      TOKEN_DEFS: TOKEN_DEFS,
      PRESETS: PRESETS
    };
  };
})(this);

/**
 * @file DyniPlugin Theme Model Runtime - Canonical semantic owner for theme token/preset metadata
 * Documentation: documentation/shared/theme-tokens.md
 */
(function (root) {
  "use strict";

  /** @typedef {Record<string, unknown>} DyniThemeValues */
  /** @typedef {{ path: string, inputVar: string, type: string, default?: unknown, defaultByMode?: Record<string, unknown>, outputVar?: string, defaultFrom?: string, compatibilityInputVar?: string, [key: string]: unknown }} DyniThemeTokenDefinition */
  /** @typedef {{ base?: DyniThemeValues, day?: DyniThemeValues, night?: DyniThemeValues, [mode: string]: DyniThemeValues | undefined }} DyniThemePreset */
  /** @typedef {{ TOKEN_DEFS: readonly DyniThemeTokenDefinition[], PRESETS: Readonly<Record<string, DyniThemePreset>> }} DyniThemeTokenCatalog */
  /** @typedef {{ DEFAULT_PRESET_NAME: string, PRESETS: Readonly<Record<string, DyniThemePreset>>, BASE_DEFAULTS: DyniThemeValues, MODE_DEFAULTS: Readonly<Record<string, DyniThemeValues>>, normalizePresetName(presetName: unknown): string, getSupportedPresetNames(): string[], getSupportedModes(): string[], getPresetDefinition(presetName: unknown): DyniThemePreset, getPresetBase(presetName: unknown): DyniThemeValues, getPresetMode(presetName: unknown, mode: unknown): DyniThemeValues, getTokenDefinition(path: string): DyniThemeTokenDefinition | null, getTokenDefinitions(): DyniThemeTokenDefinition[], getOutputTokenDefinitions(): DyniThemeTokenDefinition[], getMergeOrder(): string[] }} DyniThemeModel */
  /** @typedef {DyniRuntimeNamespace & { createThemeModel?: () => DyniThemeModel, createThemeTokenCatalog: () => DyniThemeTokenCatalog }} DyniThemeModelRuntime */
  /** @typedef {{ DyniPlugin: DyniPluginNamespace & { runtime: DyniThemeModelRuntime } }} DyniThemeModelRoot */

  const ns = /** @type {DyniThemeModelRoot} */ (/** @type {unknown} */ (root)).DyniPlugin;
  const runtime = ns.runtime;

  const DEFAULT_PRESET_NAME = "default";
  const SUPPORTED_MODES = ["day", "night"];

  const MERGE_ORDER = Object.freeze([
    "rootInputOverride",
    "presetModeOverride",
    "presetBaseOverride",
    "globalModeDefault",
    "globalBaseDefault",
    "parentCascade"
  ]);

  const tokenCatalog = runtime.createThemeTokenCatalog();
  const TOKEN_DEFS = tokenCatalog.TOKEN_DEFS;
  const PRESETS = tokenCatalog.PRESETS;

  /** @param {DyniThemeValues} target @param {string[]} pathSegments @param {unknown} value */
  function setByPath(target, pathSegments, value) {
    /** @type {DyniThemeValues} */
    let cursor = target;
    for (let i = 0; i < pathSegments.length - 1; i += 1) {
      const segment = pathSegments[i];
      if (!cursor[segment] || typeof cursor[segment] !== "object") {
        cursor[segment] = {};
      }
      cursor = /** @type {DyniThemeValues} */ (cursor[segment]);
    }
    cursor[pathSegments[pathSegments.length - 1]] = value;
  }

  /** @returns {DyniThemeValues} */
  function buildBaseDefaults() {
    /** @type {DyniThemeValues} */
    const out = {};
    TOKEN_DEFS.forEach(function (def) {
      if (typeof def.default === "undefined") {
        return;
      }
      setByPath(out, def.path.split("."), def.default);
    });
    return out;
  }

  /** @param {string} mode @returns {DyniThemeValues} */
  function buildModeDefaults(mode) {
    /** @type {DyniThemeValues} */
    const out = {};
    TOKEN_DEFS.forEach(function (def) {
      if (!def.defaultByMode || typeof def.defaultByMode[mode] === "undefined") {
        return;
      }
      setByPath(out, def.path.split("."), def.defaultByMode[mode]);
    });
    return out;
  }

  const BASE_DEFAULTS = Object.freeze(buildBaseDefaults());
  const MODE_DEFAULTS = Object.freeze({
    day: Object.freeze(buildModeDefaults("day")),
    night: Object.freeze(buildModeDefaults("night"))
  });

  /** @type {Record<string, DyniThemeTokenDefinition>} */
  const TOKEN_DEF_BY_PATH = {};
  TOKEN_DEFS.forEach(function (def) {
    TOKEN_DEF_BY_PATH[def.path] = def;
  });

  const OUTPUT_TOKEN_DEFS = TOKEN_DEFS.filter(function (def) {
    return typeof def.outputVar === "string" && def.outputVar.length > 0;
  });

  /** @param {unknown} presetName @returns {string} */
  function normalizePresetName(presetName) {
    if (typeof presetName !== "string") {
      return DEFAULT_PRESET_NAME;
    }
    const normalized = presetName.trim().toLowerCase();
    if (!normalized || normalized === "night") {
      return DEFAULT_PRESET_NAME;
    }
    return Object.prototype.hasOwnProperty.call(PRESETS, normalized) ? normalized : DEFAULT_PRESET_NAME;
  }

  /** @param {unknown} presetName @returns {DyniThemePreset} */
  function getPresetDefinition(presetName) {
    return PRESETS[normalizePresetName(presetName)];
  }

  /** @param {unknown} presetName @returns {DyniThemeValues} */
  function getPresetBase(presetName) {
    const preset = getPresetDefinition(presetName);
    return preset && preset.base ? preset.base : {};
  }

  /** @param {unknown} presetName @param {unknown} mode @returns {DyniThemeValues} */
  function getPresetMode(presetName, mode) {
    const preset = getPresetDefinition(presetName);
    if (!preset || typeof mode !== "string") {
      return {};
    }
    return preset[mode] && typeof preset[mode] === "object" ? preset[mode] : {};
  }

  /** @param {string} path @returns {DyniThemeTokenDefinition | null} */
  function getTokenDefinition(path) {
    return Object.prototype.hasOwnProperty.call(TOKEN_DEF_BY_PATH, path) ? TOKEN_DEF_BY_PATH[path] : null;
  }

  /** @returns {DyniThemeTokenDefinition[]} */
  function getTokenDefinitions() {
    return TOKEN_DEFS.slice();
  }

  /** @returns {DyniThemeTokenDefinition[]} */
  function getOutputTokenDefinitions() {
    return OUTPUT_TOKEN_DEFS.slice();
  }

  /** @returns {string[]} */
  function getMergeOrder() {
    return MERGE_ORDER.slice();
  }

  runtime.createThemeModel = function createThemeModel() {
    return {
      DEFAULT_PRESET_NAME: DEFAULT_PRESET_NAME,
      PRESETS: PRESETS,
      BASE_DEFAULTS: BASE_DEFAULTS,
      MODE_DEFAULTS: MODE_DEFAULTS,
      normalizePresetName: normalizePresetName,
      getSupportedPresetNames: function () {
        return Object.keys(PRESETS);
      },
      getSupportedModes: function () {
        return SUPPORTED_MODES.slice();
      },
      getPresetDefinition: getPresetDefinition,
      getPresetBase: getPresetBase,
      getPresetMode: getPresetMode,
      getTokenDefinition: getTokenDefinition,
      getTokenDefinitions: getTokenDefinitions,
      getOutputTokenDefinitions: getOutputTokenDefinitions,
      getMergeOrder: getMergeOrder
    };
  };
})(this);

/**
 * @file DyniPlugin Theme Resolver Runtime - Plugin-wide theme token resolver
 * Documentation: documentation/shared/theme-tokens.md
 */
(function (root) {
  "use strict";

  /** @typedef {Record<string, unknown>} DyniThemeValues */
  /** @typedef {{ path: string, inputVar: string, type: string, default?: unknown, defaultByMode?: Record<string, unknown>, defaultFrom?: string, deprecatedInputVar?: string }} DyniThemeTokenDefinition */
  /** @typedef {{ getTokenDefinitions: () => DyniThemeTokenDefinition[], getOutputTokenDefinitions: () => DyniThemeTokenDefinition[], normalizePresetName: (value: unknown) => string, getPresetMode: (presetName: string, mode: string) => DyniThemeValues, getPresetBase: (presetName: string) => DyniThemeValues, getTokenDefinition: (path: string) => DyniThemeTokenDefinition | null }} DyniThemeModel */
  /** @typedef {{ getNightModeState?: (rootEl: Element) => boolean, getActivePresetName?: (rootEl: Element, inlineStyle: CSSStyleDeclaration | null, mode: string) => string, readCssInputVar?: (style: CSSStyleDeclaration | null, inputVar: string) => string }} DyniThemeResolverOptions */
  /** @typedef {{ create: () => DyniValueMathApi }} DyniThemeValueMathModule */
  /** @typedef {{ inputReader: (style: CSSStyleDeclaration | null, inputVar: string) => string, style: CSSStyleDeclaration | null, mode: string, presetMode: DyniThemeValues, presetBase: DyniThemeValues, warnedDeprecations: Set<string>, tokenPathSegmentsByPath?: Record<string, string[]> }} DyniThemeResolutionContext */
  /** @typedef {{ tokenDef: DyniThemeTokenDefinition, pathSegments: string[], parentPathSegments: string[] | null }} DyniThemeMetadataEntry */
  /** @typedef {{ entries: DyniThemeMetadataEntry[], inputVars: string[], pathSegmentsByPath: Record<string, string[]> }} DyniThemeTokenMetadata */
  /** @typedef {{ tokenEntries: DyniThemeMetadataEntry[], outputTokenEntries: DyniThemeMetadataEntry[], snapshotInputVars: string[], tokenPathSegmentsByPath: Record<string, string[]> }} DyniThemeMetadata */
  /** @typedef {{ full: Map<string, DyniThemeValues>, output: Map<string, DyniThemeValues> }} DyniThemeCacheBucket */
  /** @typedef {{ resolveForRoot: (rootEl: Element) => DyniThemeValues, resolveOutputsForRoot: (rootEl: Element) => DyniThemeValues, resetCache: () => void }} DyniThemeResolverApi */
  /** @typedef {DyniRuntimeNamespace & { createThemeResolver: (model: DyniThemeModel, options?: DyniThemeResolverOptions) => DyniThemeResolverApi }} DyniThemeResolverRuntime */
  /** @typedef {Window & { DyniPlugin: DyniPluginNamespace & { runtime: DyniThemeResolverRuntime }, DyniComponents?: Record<string, unknown>, getComputedStyle?: (el: Element) => CSSStyleDeclaration, console: Console }} DyniThemeResolverRoot */

  const browserRoot = /** @type {DyniThemeResolverRoot} */ (/** @type {unknown} */ (root));
  const ns = browserRoot.DyniPlugin;
  const runtime = ns.runtime;

  const valueMathModule =
    browserRoot.DyniComponents &&
    /** @type {DyniThemeValueMathModule | undefined} */ (browserRoot.DyniComponents.DyniValueMath);
  if (!valueMathModule || typeof valueMathModule.create !== "function") {
    throw new Error("ThemeResolver runtime: DyniValueMath module is required before resolver bootstrap");
  }
  const valueMath = valueMathModule.create();
  if (!valueMath || typeof valueMath.toObject !== "function") {
    throw new Error("ThemeResolver runtime: ValueMath.toObject is required before resolver bootstrap");
  }
  const toObject = valueMath.toObject;

  /** @param {DyniThemeValues} target @param {string[]} pathSegments @param {unknown} value */
  function setByPath(target, pathSegments, value) {
    /** @type {DyniThemeValues} */
    let cursor = target;
    const lastIndex = pathSegments.length - 1;
    for (let i = 0; i < lastIndex; i += 1) {
      const segment = pathSegments[i];
      const next = cursor[segment];
      if (!next || typeof next !== "object") {
        cursor[segment] = Object.create(null);
      }
      cursor = /** @type {DyniThemeValues} */ (cursor[segment]);
    }
    cursor[pathSegments[lastIndex]] = value;
  }

  /** @param {unknown} source @param {string[]} pathSegments @returns {unknown} */
  function getByPath(source, pathSegments) {
    let cursor = source;
    for (let i = 0; i < pathSegments.length; i += 1) {
      if (!cursor || typeof cursor !== "object" || !Object.prototype.hasOwnProperty.call(cursor, pathSegments[i])) {
        return undefined;
      }
      cursor = /** @type {Record<string, unknown>} */ (cursor)[pathSegments[i]];
    }
    return cursor;
  }

  /** @param {Element | null} el @returns {CSSStyleDeclaration | null} */
  function getComputedStyleSafe(el) {
    if (!el || typeof browserRoot.getComputedStyle !== "function") {
      return null;
    }
    const style = browserRoot.getComputedStyle(el);
    return style && typeof style.getPropertyValue === "function" ? style : null;
  }

  /** @param {Element | null} rootEl @returns {CSSStyleDeclaration | null} */
  function getInlineStyleSafe(rootEl) {
    const styledRoot = rootEl && /** @type {{ style?: CSSStyleDeclaration }} */ (/** @type {unknown} */ (rootEl));
    const style = styledRoot && styledRoot.style;
    return style && typeof style.getPropertyValue === "function" ? style : null;
  }

  /** @param {CSSStyleDeclaration | null} style @param {string} inputVar @returns {string} */
  function readCssInputVar(style, inputVar) {
    if (!style || typeof style.getPropertyValue !== "function" || !inputVar) {
      return "";
    }
    const raw = style.getPropertyValue(inputVar);
    return typeof raw === "string" ? raw.trim() : "";
  }

  /** @param {string[]} inputVars @param {Record<string, boolean>} seenInputVars @param {unknown} inputVar */
  function addInputVar(inputVars, seenInputVars, inputVar) {
    if (typeof inputVar !== "string" || inputVar.length === 0 || seenInputVars[inputVar]) {
      return;
    }
    seenInputVars[inputVar] = true;
    inputVars.push(inputVar);
  }

  /** @param {DyniThemeTokenDefinition[]} tokenDefs @returns {DyniThemeTokenMetadata} */
  function createTokenMetadata(tokenDefs) {
    /** @type {DyniThemeMetadataEntry[]} */
    const entries = [];
    /** @type {string[]} */
    const inputVars = [];
    const seenInputVars = /** @type {Record<string, boolean>} */ (Object.create(null));
    const pathSegmentsByPath = /** @type {Record<string, string[]>} */ (Object.create(null));

    for (let i = 0; i < tokenDefs.length; i += 1) {
      const tokenDef = tokenDefs[i];
      const pathSegments = tokenDef.path.split(".");
      Object.freeze(pathSegments);
      pathSegmentsByPath[tokenDef.path] = pathSegments;
      const parentPathSegments =
        typeof tokenDef.defaultFrom === "string" && tokenDef.defaultFrom.length > 0
          ? pathSegmentsByPath[tokenDef.defaultFrom] || tokenDef.defaultFrom.split(".")
          : null;
      entries.push({
        tokenDef: tokenDef,
        pathSegments: pathSegments,
        parentPathSegments: parentPathSegments
      });

      addInputVar(inputVars, seenInputVars, tokenDef && tokenDef.inputVar);
      addInputVar(inputVars, seenInputVars, tokenDef && tokenDef.deprecatedInputVar);
    }

    return /** @type {DyniThemeTokenMetadata} */ (
      /** @type {unknown} */ (
        Object.freeze({
          entries: Object.freeze(entries),
          inputVars: Object.freeze(inputVars),
          pathSegmentsByPath: Object.freeze(pathSegmentsByPath)
        })
      )
    );
  }

  /** @param {string} raw @param {DyniThemeTokenDefinition} tokenDef @returns {{ hasValue: boolean, value: unknown }} */
  function parseOverride(raw, tokenDef) {
    if (tokenDef.type === "number") {
      const parsed = parseFloat(raw);
      return Number.isFinite(parsed) ? { hasValue: true, value: parsed } : { hasValue: false, value: tokenDef.default };
    }
    return { hasValue: true, value: raw };
  }

  /** @param {string} oldVar @param {string} newVar @param {Set<string>} warnedDeprecations */
  function logDeprecationWarning(oldVar, newVar, warnedDeprecations) {
    if (warnedDeprecations.has(oldVar)) {
      return;
    }
    warnedDeprecations.add(oldVar);
    if (browserRoot.console && typeof browserRoot.console.warn === "function") {
      browserRoot.console.warn("DyniPlugin: CSS variable " + oldVar + " is deprecated. Use " + newVar + " instead.");
    }
  }

  /** @param {CSSStyleDeclaration | null} style @param {DyniThemeTokenDefinition} tokenDef @param {(style: CSSStyleDeclaration | null, inputVar: string) => string} inputReader @param {Set<string>} warnedDeprecations @returns {{ hasValue: boolean, value: unknown }} */
  function readTokenInputOverride(style, tokenDef, inputReader, warnedDeprecations) {
    const raw = inputReader(style, tokenDef.inputVar);
    if (raw) {
      return parseOverride(raw, tokenDef);
    }
    const aliasInputVar = tokenDef.deprecatedInputVar;
    if (aliasInputVar) {
      const aliasRaw = inputReader(style, aliasInputVar);
      if (aliasRaw) {
        logDeprecationWarning(aliasInputVar, tokenDef.inputVar, warnedDeprecations);
        return parseOverride(aliasRaw, tokenDef);
      }
    }
    return { hasValue: false, value: tokenDef.default };
  }

  /** @param {Element | null} rootEl @returns {boolean} */
  function isCommittedPluginRoot(rootEl) {
    return !!(
      rootEl &&
      rootEl.nodeType === 1 &&
      rootEl.classList &&
      typeof rootEl.classList.contains === "function" &&
      rootEl.classList.contains("widget") &&
      rootEl.classList.contains("dyniplugin")
    );
  }

  /** @param {Element | null} rootEl */
  function requireCommittedPluginRoot(rootEl) {
    if (!isCommittedPluginRoot(rootEl)) {
      throw new Error("ThemeResolver.resolveForRoot: rootEl must be a committed .widget.dyniplugin root element");
    }
  }

  /** @param {Element | null} rootEl @returns {string} */
  function getRootClassSignature(rootEl) {
    let rawClassName = "";
    if (!rootEl) {
      return rawClassName;
    }
    if (typeof rootEl.className === "string") {
      rawClassName = rootEl.className;
    } else if (typeof rootEl.getAttribute === "function") {
      const classAttr = rootEl.getAttribute("class");
      rawClassName = typeof classAttr === "string" ? classAttr : "";
    }
    return rawClassName.trim().replace(/\s+/g, " ");
  }

  /** @param {CSSStyleDeclaration | null} inlineStyle @param {string[]} inputVars @returns {string} */
  function buildInlineInputSignature(inlineStyle, inputVars) {
    const parts = /** @type {string[]} */ ([]);
    for (let i = 0; i < inputVars.length; i += 1) {
      const inputVar = inputVars[i];
      parts.push(inputVar + "=" + readCssInputVar(inlineStyle, inputVar));
    }
    return parts.join(";");
  }

  /** @param {unknown} value @returns {unknown} */
  function deepFreeze(value) {
    if (!value || typeof value !== "object" || Object.isFrozen(value)) {
      return value;
    }
    Object.freeze(value);
    const keys = Object.keys(value);
    for (let i = 0; i < keys.length; i += 1) {
      deepFreeze(/** @type {Record<string, unknown>} */ (value)[keys[i]]);
    }
    return value;
  }

  /** @param {DyniThemeValues} tokens @returns {DyniThemeValues} */
  function applyDerivedSurfaceBorder(tokens) {
    if (!tokens || typeof tokens !== "object") {
      return tokens;
    }
    if (!tokens.surface || typeof tokens.surface !== "object") {
      return tokens;
    }
    const surface = /** @type {DyniThemeValues} */ (tokens.surface);
    if (typeof surface.border !== "undefined") {
      return tokens;
    }
    surface.border = surface.fg;
    return tokens;
  }

  runtime.createThemeResolver = function createThemeResolver(themeModel, options) {
    const model = /** @type {DyniThemeModel} */ (themeModel);
    const opts = /** @type {DyniThemeResolverOptions} */ (toObject(options));
    const warnedDeprecations = new Set();
    /** @type {DyniThemeMetadata | null} */
    let themeMetadata = null;
    /** @type {WeakMap<Element, DyniThemeCacheBucket>} */
    let rootResolutionCache = new WeakMap();

    /** @param {Element} rootEl @returns {boolean} */
    function getNightModeState(rootEl) {
      const override = opts.getNightModeState;
      if (typeof override === "function") {
        return !!override(rootEl);
      }
      return !!(rootEl && typeof rootEl.closest === "function" && rootEl.closest(".nightMode"));
    }

    /** @param {Element} rootEl @param {CSSStyleDeclaration | null} inlineStyle @param {string} mode @returns {string} */
    function getActivePresetName(rootEl, inlineStyle, mode) {
      const override = opts.getActivePresetName;
      if (typeof override === "function") {
        return override(rootEl, inlineStyle, mode);
      }
      return "default";
    }

    /** @returns {(style: CSSStyleDeclaration | null, inputVar: string) => string} */
    function resolveInputReader() {
      return typeof opts.readCssInputVar === "function" ? opts.readCssInputVar : readCssInputVar;
    }

    /** @returns {DyniThemeMetadata} */
    function resolveThemeMetadata() {
      if (themeMetadata) {
        return themeMetadata;
      }
      const tokenMetadata = createTokenMetadata(model.getTokenDefinitions());
      const outputTokenMetadata = createTokenMetadata(model.getOutputTokenDefinitions());
      themeMetadata = Object.freeze({
        tokenEntries: tokenMetadata.entries,
        outputTokenEntries: outputTokenMetadata.entries,
        snapshotInputVars: tokenMetadata.inputVars,
        tokenPathSegmentsByPath: tokenMetadata.pathSegmentsByPath
      });
      return themeMetadata;
    }

    /** @param {Element} rootEl @param {DyniThemeMetadata} metadata @returns {{ mode: string, presetName: string, signature: string }} */
    function createRootSnapshot(rootEl, metadata) {
      const mode = getNightModeState(rootEl) ? "night" : "day";
      const inlineStyle = getInlineStyleSafe(rootEl);
      const presetName = model.normalizePresetName(getActivePresetName(rootEl, inlineStyle, mode));
      const classSignature = getRootClassSignature(rootEl);
      const inlineInputSignature = buildInlineInputSignature(inlineStyle, metadata.snapshotInputVars);

      return {
        mode: mode,
        presetName: presetName,
        signature: mode + "|" + presetName + "|" + classSignature + "|" + inlineInputSignature
      };
    }

    /** @param {Element} rootEl @param {{ mode: string, presetName: string }} snapshot @returns {DyniThemeResolutionContext} */
    function createResolutionContext(rootEl, snapshot) {
      const inputReader = resolveInputReader();
      const style = getComputedStyleSafe(rootEl);
      return {
        inputReader: inputReader,
        style: style,
        mode: snapshot.mode,
        presetMode: model.getPresetMode(snapshot.presetName, snapshot.mode),
        presetBase: model.getPresetBase(snapshot.presetName),
        warnedDeprecations: warnedDeprecations
      };
    }

    /** @param {DyniThemeTokenDefinition} tokenDef @param {string[]} pathSegments @param {string[] | null} parentPathSegments @param {DyniThemeResolutionContext} context @returns {unknown} */
    function resolveTokenValue(tokenDef, pathSegments, parentPathSegments, context) {
      const rootOverride = readTokenInputOverride(
        context.style,
        tokenDef,
        context.inputReader,
        context.warnedDeprecations
      );
      if (rootOverride.hasValue) {
        return rootOverride.value;
      }

      const presetModeValue = getByPath(context.presetMode, pathSegments);
      if (typeof presetModeValue !== "undefined") {
        return presetModeValue;
      }

      const presetBaseValue = getByPath(context.presetBase, pathSegments);
      if (typeof presetBaseValue !== "undefined") {
        return presetBaseValue;
      }

      const modeDefault =
        tokenDef.defaultByMode && Object.prototype.hasOwnProperty.call(tokenDef.defaultByMode, context.mode)
          ? tokenDef.defaultByMode[context.mode]
          : undefined;
      if (typeof modeDefault !== "undefined") {
        return modeDefault;
      }

      if (typeof tokenDef.default !== "undefined") {
        return tokenDef.default;
      }

      if (tokenDef.defaultFrom) {
        const parentDef = model.getTokenDefinition(tokenDef.defaultFrom);
        if (parentDef) {
          const tokenPathSegmentsByPath = context.tokenPathSegmentsByPath || {};
          const resolvedParentPathSegments =
            parentPathSegments || tokenPathSegmentsByPath[parentDef.path] || parentDef.path.split(".");
          return resolveTokenValue(parentDef, resolvedParentPathSegments, null, context);
        }
      }

      return undefined;
    }

    /** @param {Element} rootEl @returns {DyniThemeCacheBucket} */
    function resolveRootCacheBucket(rootEl) {
      let bucket = rootResolutionCache.get(rootEl);
      if (!bucket) {
        bucket = { full: new Map(), output: new Map() };
        rootResolutionCache.set(rootEl, bucket);
      }
      return bucket;
    }

    /** @param {DyniThemeMetadataEntry[]} entries @param {DyniThemeResolutionContext} context @returns {DyniThemeValues} */
    function resolveTokenEntries(entries, context) {
      const out = /** @type {DyniThemeValues} */ ({});
      for (let i = 0; i < entries.length; i += 1) {
        const entry = entries[i];
        setByPath(
          out,
          entry.pathSegments,
          resolveTokenValue(entry.tokenDef, entry.pathSegments, entry.parentPathSegments, context)
        );
      }
      return applyDerivedSurfaceBorder(out);
    }

    /** @param {Element} rootEl @param {"full" | "output"} kind @returns {DyniThemeValues} */
    function resolveWithCache(rootEl, kind) {
      requireCommittedPluginRoot(rootEl);
      const metadata = resolveThemeMetadata();
      const snapshot = createRootSnapshot(rootEl, metadata);
      const bucket = resolveRootCacheBucket(rootEl);
      const cache = kind === "output" ? bucket.output : bucket.full;

      if (cache.has(snapshot.signature)) {
        return /** @type {DyniThemeValues} */ (cache.get(snapshot.signature));
      }

      const context = createResolutionContext(rootEl, snapshot);
      context.tokenPathSegmentsByPath = metadata.tokenPathSegmentsByPath;
      const entries = kind === "output" ? metadata.outputTokenEntries : metadata.tokenEntries;
      const resolved = /** @type {DyniThemeValues} */ (deepFreeze(resolveTokenEntries(entries, context)));
      cache.set(snapshot.signature, resolved);
      return resolved;
    }

    return {
      resolveForRoot: function (rootEl) {
        return resolveWithCache(rootEl, "full");
      },
      resolveOutputsForRoot: function (rootEl) {
        return resolveWithCache(rootEl, "output");
      },
      resetCache: function () {
        themeMetadata = null;
        rootResolutionCache = new WeakMap();
      }
    };
  };
})(this);

/**
 * @file DyniPlugin Theme Runtime - Startup preset wiring, commit-time root materialization, and shadow CSS text cache
 * Documentation: documentation/architecture/runtime-lifecycle.md
 */
(function (root) {
  "use strict";

  /** @typedef {{ outputVar?: unknown, path?: string }} DyniThemeOutputDefinition */
  /** @typedef {{ normalizePresetName(presetName: unknown): string, getOutputTokenDefinitions(): DyniThemeOutputDefinition[] }} DyniThemeModel */
  /** @typedef {{ resolveOutputsForRoot(rootEl: Element): Record<string, unknown>, resolveForRoot(rootEl: Element): unknown }} DyniThemeResolver */
  /** @typedef {{ getNightModeState(rootEl: Element): boolean, getActivePresetName(rootEl: Element): string }} DyniThemeResolverOptions */
  /** @typedef {{ ok?: unknown, status?: unknown, text(): Promise<unknown> }} DyniThemeFetchResponse */
  /** @typedef {{ style: { setProperty(name: string, value: string): void } }} DyniThemeStyleRoot */
  /** @typedef {DyniRuntimeNamespace & { createThemeModel: () => DyniThemeModel, createThemeResolver: (model: DyniThemeModel, options: DyniThemeResolverOptions) => DyniThemeResolver, dom: { getNightModeState(rootEl: Element): boolean }, theme?: unknown }} DyniThemeRuntime */
  /** @typedef {{ DyniPlugin: DyniPluginNamespace & { runtime: DyniThemeRuntime }, fetch?: (url: string) => Promise<DyniThemeFetchResponse>, getComputedStyle?: (element: Element) => CSSStyleDeclaration }} DyniThemeRoot */

  const ns = /** @type {DyniThemeRoot} */ (/** @type {unknown} */ (root)).DyniPlugin;
  const runtime = ns.runtime;
  const hasOwn = Object.prototype.hasOwnProperty;

  let configured = false;
  /** @type {DyniThemeModel | null} */
  let themeModel = null;
  /** @type {DyniThemeResolver | null} */
  let themeResolver = null;
  let activePresetName = "default";

  const shadowCssTextCache = new Map();
  const shadowCssLoadCache = new Map();

  /** @param {unknown} value @returns {value is string} */
  function isNonEmptyString(value) {
    return typeof value === "string" && value.trim().length > 0;
  }

  /** @param {unknown} presetName @returns {string} */
  function normalizePresetName(presetName) {
    const model = themeModel || runtime.createThemeModel();
    return model.normalizePresetName(presetName);
  }

  /** @param {unknown} source @param {unknown} path @returns {unknown} */
  function resolveByPath(source, path) {
    if (!source || typeof source !== "object" || !isNonEmptyString(path)) {
      return undefined;
    }
    const segments = path.split(".");
    /** @type {unknown} */
    let cursor = source;
    for (let i = 0; i < segments.length; i += 1) {
      const segment = segments[i];
      if (!cursor || typeof cursor !== "object" || !hasOwn.call(cursor, segment)) {
        return undefined;
      }
      cursor = /** @type {Record<string, unknown>} */ (cursor)[segment];
    }
    return cursor;
  }

  /** @returns {(url: string) => Promise<DyniThemeFetchResponse>} */
  function ensureFetchApi() {
    if (typeof root.fetch === "function") {
      return root.fetch.bind(root);
    }
    throw new Error("dyninstruments: runtime.theme shadow CSS preload requires fetch()");
  }

  /** @param {unknown} url @returns {Promise<string>} */
  function fetchShadowCssText(url) {
    if (!isNonEmptyString(url)) {
      return Promise.reject(new Error("dyninstruments: shadow CSS preload requires non-empty url"));
    }

    if (shadowCssTextCache.has(url)) {
      return Promise.resolve(shadowCssTextCache.get(url));
    }
    if (shadowCssLoadCache.has(url)) {
      return shadowCssLoadCache.get(url);
    }

    const fetchApi = ensureFetchApi();
    const loadPromise = fetchApi(url)
      .then(function (response) {
        if (!response || (hasOwn.call(response, "ok") && response.ok === false)) {
          const status = response && hasOwn.call(response, "status") ? response.status : "unknown";
          throw new Error("dyninstruments: failed to preload shadow CSS '" + url + "' (status " + String(status) + ")");
        }
        if (typeof response.text !== "function") {
          throw new Error("dyninstruments: invalid response for shadow CSS '" + url + "'");
        }
        return response.text();
      })
      .then(function (cssText) {
        const normalizedText = typeof cssText === "string" ? cssText : String(cssText || "");
        shadowCssTextCache.set(url, normalizedText);
        return normalizedText;
      })
      .then(
        function (cssText) {
          shadowCssLoadCache.delete(url);
          return cssText;
        },
        function (error) {
          shadowCssLoadCache.delete(url);
          throw error;
        }
      );

    shadowCssLoadCache.set(url, loadPromise);
    return loadPromise;
  }

  /** @param {unknown} urls @returns {Promise<string[]>} */
  function preloadShadowCssUrls(urls) {
    if (!Array.isArray(urls) || !urls.length) {
      return Promise.resolve([]);
    }

    const unique = [];
    const seen = Object.create(null);
    for (let i = 0; i < urls.length; i += 1) {
      const url = urls[i];
      if (!isNonEmptyString(url) || seen[url]) {
        continue;
      }
      seen[url] = true;
      unique.push(url);
    }

    if (!unique.length) {
      return Promise.resolve([]);
    }
    return Promise.all(unique.map(fetchShadowCssText));
  }

  /** @param {Element | null | undefined} el @returns {string | null} */
  function readThemePresetCssVarFromElement(el) {
    if (!el || typeof root.getComputedStyle !== "function") {
      return null;
    }
    const style = root.getComputedStyle(el);
    if (!style || typeof style.getPropertyValue !== "function") {
      return null;
    }
    const raw = style.getPropertyValue("--dyni-theme-preset");
    const value = typeof raw === "string" ? raw.trim() : "";
    return value === "" ? null : value;
  }

  /** @param {Element | null | undefined} docElement @returns {string} */
  function resolveStartupPresetName(docElement) {
    const rootPreset = readThemePresetCssVarFromElement(docElement);
    return normalizePresetName(rootPreset);
  }

  /** @param {string} methodName */
  function ensureConfigured(methodName) {
    if (!configured || !themeModel || !themeResolver) {
      throw new Error("dyninstruments: runtime.theme." + methodName + "() requires prior configure()");
    }
  }

  /** @param {{ activePresetName?: unknown } | null | undefined} options @returns {string} */
  function configure(options) {
    const opts = options || {};

    const model = runtime.createThemeModel();
    themeModel = model;
    activePresetName = model.normalizePresetName(opts.activePresetName);

    themeResolver = runtime.createThemeResolver(model, {
      getNightModeState: function (rootEl) {
        return runtime.dom.getNightModeState(rootEl);
      },
      getActivePresetName: function (rootEl) {
        const rootPreset = readThemePresetCssVarFromElement(rootEl);
        return model.normalizePresetName(rootPreset || activePresetName);
      }
    });

    configured = true;
    return activePresetName;
  }

  /** @param {unknown} rootEl @returns {Record<string, unknown>} */
  function applyToRoot(rootEl) {
    ensureConfigured("applyToRoot");

    if (!rootEl || typeof rootEl !== "object") {
      throw new Error("dyninstruments: runtime.theme.applyToRoot() requires root element with style.setProperty()");
    }

    const styleRoot = /** @type {DyniThemeStyleRoot} */ (/** @type {unknown} */ (rootEl));
    if (!styleRoot.style || typeof styleRoot.style.setProperty !== "function") {
      throw new Error("dyninstruments: runtime.theme.applyToRoot() requires root element with style.setProperty()");
    }

    const element = /** @type {Element} */ (rootEl);
    const resolvedTheme = /** @type {DyniThemeResolver} */ (themeResolver).resolveOutputsForRoot(element);
    const outputDefs = /** @type {DyniThemeModel} */ (themeModel).getOutputTokenDefinitions();
    for (let i = 0; i < outputDefs.length; i += 1) {
      const outputDef = outputDefs[i];
      const outputVar = outputDef && outputDef.outputVar;
      if (!isNonEmptyString(outputVar)) {
        continue;
      }
      const resolvedValue = resolveByPath(resolvedTheme, outputDef.path);
      if (typeof resolvedValue === "undefined") {
        throw new Error("dyninstruments: runtime.theme.applyToRoot() missing resolved token '" + outputDef.path + "'");
      }
      styleRoot.style.setProperty(outputVar, String(resolvedValue));
    }

    return resolvedTheme;
  }

  /** @param {Element} rootEl @returns {unknown} */
  function resolveForRoot(rootEl) {
    ensureConfigured("resolveForRoot");
    return /** @type {DyniThemeResolver} */ (themeResolver).resolveForRoot(rootEl);
  }

  runtime.theme = Object.freeze({
    configure: configure,
    applyToRoot: applyToRoot,
    resolveStartupPresetName: resolveStartupPresetName,
    preloadShadowCssUrls: preloadShadowCssUrls,
    tokens: Object.freeze({
      resolveForRoot: resolveForRoot
    }),
    /** @param {unknown} url @returns {string | null} */
    getShadowCssText: function (url) {
      return shadowCssTextCache.has(url) ? shadowCssTextCache.get(url) : null;
    },
    /** @param {unknown} url @returns {boolean} */
    hasShadowCssText: function (url) {
      return shadowCssTextCache.has(url);
    }
  });
})(this);

/**
 * @file DyniPlugin Shared Foundation Registry Format - Shared format and display component definitions
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const config = ns.config;
  const shared = (config.shared = config.shared || {});
  const BASE = ns.baseUrl;

  if (typeof BASE !== "string" || !BASE) {
    throw new Error(
      "dyninstruments: baseUrl missing before config/components/registry-shared-foundation-format.js load"
    );
  }

  const groups = (shared.componentRegistryGroups = shared.componentRegistryGroups || {});
  var sf = (groups.sharedFoundation = groups.sharedFoundation || {});

  sf.PlaceholderNormalize = {
    js: BASE + "shared/widget-kits/format/PlaceholderNormalize.js",
    css: undefined,
    globalKey: "DyniPlaceholderNormalize"
  };

  sf.DepthDisplayFormatter = {
    js: BASE + "shared/widget-kits/format/DepthDisplayFormatter.js",
    css: undefined,
    globalKey: "DyniDepthDisplayFormatter",
    deps: ["ValueMath"]
  };

  sf.UnitAwareFormatter = {
    js: BASE + "shared/widget-kits/format/UnitAwareFormatter.js",
    css: undefined,
    globalKey: "DyniUnitAwareFormatter",
    deps: ["PlaceholderNormalize", "ValueMath"]
  };

  sf.StableDigits = {
    js: BASE + "shared/widget-kits/format/StableDigits.js",
    css: undefined,
    globalKey: "DyniStableDigits",
    deps: ["PlaceholderNormalize", "ValueMath"]
  };
})(this);

/**
 * @file DyniPlugin Shared Foundation Registry Geometry - Shared geometry, layout, and rendering component definitions
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const config = ns.config;
  const shared = (config.shared = config.shared || {});
  const BASE = ns.baseUrl;

  if (typeof BASE !== "string" || !BASE) {
    throw new Error(
      "dyninstruments: baseUrl missing before config/components/registry-shared-foundation-geometry.js load"
    );
  }

  const groups = (shared.componentRegistryGroups = shared.componentRegistryGroups || {});
  var sf = (groups.sharedFoundation = groups.sharedFoundation || {});

  sf.RadialAngleMath = {
    js: BASE + "shared/widget-kits/radial/RadialAngleMath.js",
    css: undefined,
    globalKey: "DyniRadialAngleMath"
  };

  sf.RadialCanvasPrimitives = {
    js: BASE + "shared/widget-kits/radial/RadialCanvasPrimitives.js",
    css: undefined,
    globalKey: "DyniRadialCanvasPrimitives",
    deps: ["RadialAngleMath", "ValueMath"]
  };

  sf.RadialFrameRenderer = {
    js: BASE + "shared/widget-kits/radial/RadialFrameRenderer.js",
    css: undefined,
    globalKey: "DyniRadialFrameRenderer",
    deps: ["RadialAngleMath", "RadialTickMath", "RadialCanvasPrimitives", "ValueMath"]
  };

  sf.ValueMath = {
    js: BASE + "shared/widget-kits/value/ValueMath.js",
    css: undefined,
    globalKey: "DyniValueMath"
  };

  sf.HtmlMeasureUtils = {
    js: BASE + "shared/widget-kits/html/HtmlMeasureUtils.js",
    css: undefined,
    globalKey: "DyniHtmlMeasureUtils",
    deps: ["ValueMath"]
  };

  sf.CanvasTextFitting = {
    js: BASE + "shared/widget-kits/text/CanvasTextFitting.js",
    css: undefined,
    globalKey: "DyniCanvasTextFitting",
    deps: ["ValueMath"]
  };

  sf.CanvasTextLayout = {
    js: BASE + "shared/widget-kits/text/CanvasTextLayout.js",
    css: undefined,
    globalKey: "DyniCanvasTextLayout",
    deps: ["CanvasTextFitting"]
  };

  sf.RadialTextFitting = {
    js: BASE + "shared/widget-kits/radial/RadialTextFitting.js",
    css: undefined,
    globalKey: "DyniRadialTextFitting",
    deps: ["CanvasTextFitting"]
  };

  sf.RadialTextLayout = {
    js: BASE + "shared/widget-kits/radial/RadialTextLayout.js",
    css: undefined,
    globalKey: "DyniRadialTextLayout",
    deps: ["CanvasTextLayout"]
  };

  sf.RadialTickMath = {
    js: BASE + "shared/widget-kits/radial/RadialTickMath.js",
    css: undefined,
    globalKey: "DyniRadialTickMath",
    deps: ["RadialAngleMath"]
  };

  sf.RadialSectorMath = {
    js: BASE + "shared/widget-kits/radial/RadialSectorMath.js",
    css: undefined,
    globalKey: "DyniRadialSectorMath",
    deps: ["RadialAngleMath", "ValueMath"]
  };

  sf.RadialValueMath = {
    js: BASE + "shared/widget-kits/radial/RadialValueMath.js",
    css: undefined,
    globalKey: "DyniRadialValueMath",
    deps: ["RadialAngleMath", "ValueMath", "RadialSectorMath"]
  };

  sf.LinearCanvasPrimitives = {
    js: BASE + "shared/widget-kits/linear/LinearCanvasPrimitives.js",
    css: undefined,
    globalKey: "DyniLinearCanvasPrimitives"
  };

  sf.LinearGaugeEngineDrawing = {
    js: BASE + "shared/widget-kits/linear/LinearGaugeEngineDrawing.js",
    css: undefined,
    globalKey: "DyniLinearGaugeEngineDrawing",
    deps: ["LinearCanvasPrimitives"]
  };

  sf.LinearGaugeLayout = {
    js: BASE + "shared/widget-kits/linear/LinearGaugeLayout.js",
    css: undefined,
    globalKey: "DyniLinearGaugeLayout",
    deps: ["ResponsiveScaleProfile", "LayoutRectMath", "GeometryScale", "ValueMath", "LinearGaugeLayoutVariants"]
  };

  sf.LinearGaugeLayoutVariants = {
    js: BASE + "shared/widget-kits/linear/LinearGaugeLayoutVariants.js",
    css: undefined,
    globalKey: "DyniLinearGaugeLayoutVariants",
    deps: ["LayoutRectMath"]
  };

  sf.LinearGaugeMath = {
    js: BASE + "shared/widget-kits/linear/LinearGaugeMath.js",
    css: undefined,
    globalKey: "DyniLinearGaugeMath",
    deps: ["ValueMath"]
  };

  sf.LinearGaugeEngineSupport = {
    js: BASE + "shared/widget-kits/linear/LinearGaugeEngineSupport.js",
    css: undefined,
    globalKey: "DyniLinearGaugeEngineSupport",
    deps: ["HtmlWidgetUtils"]
  };

  sf.LinearGaugeLabelFit = {
    js: BASE + "shared/widget-kits/linear/LinearGaugeLabelFit.js",
    css: undefined,
    globalKey: "DyniLinearGaugeLabelFit",
    deps: ["CanvasTextFitting", "HtmlWidgetUtils", "ValueMath"]
  };

  sf.LinearGaugeTextLayout = {
    js: BASE + "shared/widget-kits/linear/LinearGaugeTextLayout.js",
    css: undefined,
    globalKey: "DyniLinearGaugeTextLayout",
    deps: ["LinearGaugeLabelFit", "TextLayoutScaleHelpers", "CanvasTextFitting", "HtmlWidgetUtils"]
  };

  sf.TextLayoutPrimitives = {
    js: BASE + "shared/widget-kits/text/TextLayoutPrimitives.js",
    css: undefined,
    globalKey: "DyniTextLayoutPrimitives",
    deps: ["CanvasTextLayout"]
  };

  sf.TextTileLayout = {
    js: BASE + "shared/widget-kits/text/TextTileLayout.js",
    css: undefined,
    globalKey: "DyniTextTileLayout",
    deps: ["ValueMath", "TextLayoutScaleHelpers"]
  };

  sf.TextFitMath = {
    js: BASE + "shared/widget-kits/text/TextFitMath.js",
    css: undefined,
    globalKey: "DyniTextFitMath",
    deps: ["ValueMath"]
  };

  sf.TextLayoutEngine = {
    js: BASE + "shared/widget-kits/text/TextLayoutEngine.js",
    css: undefined,
    globalKey: "DyniTextLayoutEngine",
    deps: ["ValueMath", "TextLayoutPrimitives", "TextLayoutComposite", "ResponsiveScaleProfile"]
  };

  sf.TextLayoutComposite = {
    js: BASE + "shared/widget-kits/text/TextLayoutComposite.js",
    css: undefined,
    globalKey: "DyniTextLayoutComposite",
    deps: ["TextLayoutPrimitives", "TextLayoutScaleHelpers"]
  };

  sf.TextLayoutScaleHelpers = {
    js: BASE + "shared/widget-kits/text/TextLayoutScaleHelpers.js",
    css: undefined,
    globalKey: "DyniTextLayoutScaleHelpers",
    deps: ["ValueMath"]
  };

  sf.PositionCoordinateFormatting = {
    js: BASE + "shared/widget-kits/text/PositionCoordinateFormatting.js",
    css: undefined,
    globalKey: "DyniPositionCoordinateFormatting"
  };

  sf.GeometryScale = {
    js: BASE + "shared/widget-kits/layout/GeometryScale.js",
    css: undefined,
    globalKey: "DyniGeometryScale",
    deps: ["ValueMath"]
  };

  sf.LayoutRectMath = {
    js: BASE + "shared/widget-kits/layout/LayoutRectMath.js",
    css: undefined,
    globalKey: "DyniLayoutRectMath"
  };

  sf.LayoutSizingHelpers = {
    js: BASE + "shared/widget-kits/layout/LayoutSizingHelpers.js",
    css: undefined,
    globalKey: "DyniLayoutSizingHelpers"
  };

  sf.ResponsiveScaleProfile = {
    js: BASE + "shared/widget-kits/layout/ResponsiveScaleProfile.js",
    css: undefined,
    globalKey: "DyniResponsiveScaleProfile",
    deps: ["ValueMath"]
  };
})(this);

/**
 * @file DyniPlugin Shared Foundation Registry Layout - Shared widget layout and fit component definitions
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  /** @typedef {DyniPluginSharedConfig & { componentRegistryGroups: Record<string, DyniComponentRegistryGroup> }} DyniFoundationRegistryShared */

  const ns = /** @type {DyniPluginNamespace} */ (/** @type {unknown} */ (root.DyniPlugin));
  const config = ns.config;
  const shared = /** @type {DyniFoundationRegistryShared} */ (config.shared = config.shared || {});
  const BASE = ns.baseUrl;

  if (typeof BASE !== "string" || !BASE) {
    throw new Error(
      "dyninstruments: baseUrl missing before config/components/registry-shared-foundation-layout.js load"
    );
  }

  const groups = (shared.componentRegistryGroups = shared.componentRegistryGroups || {});
  var sf = /** @type {DyniComponentRegistryGroup} */ (groups.sharedFoundation = groups.sharedFoundation || {});

  sf.AisTargetLayoutSizing = {
    js: BASE + "shared/widget-kits/nav/AisTargetLayoutSizing.js",
    css: undefined,
    globalKey: "DyniAisTargetLayoutSizing",
    deps: ["ResponsiveScaleProfile", "LayoutRectMath", "AisTargetLayoutMath"]
  };

  sf.AisTargetLayout = {
    js: BASE + "shared/widget-kits/nav/AisTargetLayout.js",
    css: undefined,
    globalKey: "DyniAisTargetLayout",
    deps: [
      "AisTargetLayoutSizing",
      "ResponsiveScaleProfile",
      "LayoutRectMath",
      "AisTargetLayoutGeometry",
      "AisTargetLayoutMath"
    ]
  };

  sf.AisTargetLayoutMath = {
    js: BASE + "shared/widget-kits/nav/AisTargetLayoutMath.js",
    css: undefined,
    globalKey: "DyniAisTargetLayoutMath",
    deps: ["ValueMath"]
  };

  sf.AisTargetLayoutGeometry = {
    js: BASE + "shared/widget-kits/nav/AisTargetLayoutGeometry.js",
    css: undefined,
    globalKey: "DyniAisTargetLayoutGeometry",
    deps: ["AisTargetLayoutGeometryStyles"]
  };

  sf.AisTargetLayoutGeometryStyles = {
    js: BASE + "shared/widget-kits/nav/AisTargetLayoutGeometryStyles.js",
    css: undefined,
    globalKey: "DyniAisTargetLayoutGeometryStyles",
    deps: ["HtmlWidgetUtils"]
  };

  sf.AlarmHtmlFitChrome = {
    js: BASE + "shared/widget-kits/vessel/AlarmHtmlFitChrome.js",
    css: undefined,
    globalKey: "DyniAlarmHtmlFitChrome",
    deps: ["HtmlWidgetUtils", "AisTargetLayoutSizing", "ValueMath"]
  };

  sf.AisTargetHtmlFit = {
    js: BASE + "shared/widget-kits/nav/AisTargetHtmlFit.js",
    css: undefined,
    globalKey: "DyniAisTargetHtmlFit",
    deps: [
      "CanvasTextLayout",
      "TextTileLayout",
      "AisTargetLayout",
      "HtmlWidgetUtils",
      "HtmlMeasureUtils",
      "ValueMath",
      "TextFitMath",
      "NavModeRatio"
    ]
  };

  sf.AlarmHtmlFit = {
    js: BASE + "shared/widget-kits/vessel/AlarmHtmlFit.js",
    css: undefined,
    globalKey: "DyniAlarmHtmlFit",
    deps: ["AlarmHtmlFitChrome", "TextLayoutEngine", "HtmlWidgetUtils", "HtmlMeasureUtils", "ValueMath"]
  };

  sf.ActiveRouteHtmlFit = {
    js: BASE + "shared/widget-kits/nav/ActiveRouteHtmlFit.js",
    css: undefined,
    globalKey: "DyniActiveRouteHtmlFit",
    deps: [
      "CanvasTextLayout",
      "TextTileLayout",
      "ActiveRouteLayout",
      "HtmlWidgetUtils",
      "HtmlMeasureUtils",
      "UnitAwareFormatter",
      "ValueMath"
    ]
  };

  sf.ActiveRouteLayout = {
    js: BASE + "shared/widget-kits/nav/ActiveRouteLayout.js",
    css: undefined,
    globalKey: "DyniActiveRouteLayout",
    deps: ["ResponsiveScaleProfile", "LayoutRectMath", "LayoutSizingHelpers", "ValueMath"]
  };

  sf.EditRouteLayout = {
    js: BASE + "shared/widget-kits/nav/EditRouteLayout.js",
    css: undefined,
    globalKey: "DyniEditRouteLayout",
    deps: [
      "ResponsiveScaleProfile",
      "LayoutRectMath",
      "LayoutSizingHelpers",
      "EditRouteLayoutMath",
      "EditRouteLayoutTiles"
    ]
  };

  sf.EditRouteLayoutTiles = {
    js: BASE + "shared/widget-kits/nav/EditRouteLayoutTiles.js",
    css: undefined,
    globalKey: "DyniEditRouteLayoutTiles",
    deps: [
      "ResponsiveScaleProfile",
      "LayoutRectMath",
      "EditRouteLayoutMath",
      "EditRouteLayoutGeometry",
      "HtmlWidgetUtils"
    ]
  };

  sf.EditRouteLayoutMath = {
    js: BASE + "shared/widget-kits/nav/EditRouteLayoutMath.js",
    css: undefined,
    globalKey: "DyniEditRouteLayoutMath",
    deps: ["ValueMath", "LayoutRectMath"]
  };

  sf.EditRouteLayoutGeometry = {
    js: BASE + "shared/widget-kits/nav/EditRouteLayoutGeometry.js",
    css: undefined,
    globalKey: "DyniEditRouteLayoutGeometry",
    deps: ["LayoutRectMath", "EditRouteLayoutMath"]
  };

  sf.EditRouteHtmlFitSupport = {
    js: BASE + "shared/widget-kits/nav/EditRouteHtmlFitSupport.js",
    css: undefined,
    globalKey: "DyniEditRouteHtmlFitSupport",
    deps: ["HtmlMeasureUtils", "HtmlWidgetUtils", "ValueMath", "NavModeRatio"]
  };

  sf.EditRouteHtmlFit = {
    js: BASE + "shared/widget-kits/nav/EditRouteHtmlFit.js",
    css: undefined,
    globalKey: "DyniEditRouteHtmlFit",
    deps: [
      "CanvasTextLayout",
      "TextTileLayout",
      "EditRouteLayout",
      "HtmlWidgetUtils",
      "HtmlMeasureUtils",
      "TextFitMath",
      "EditRouteHtmlFitSupport",
      "ValueMath"
    ]
  };

  sf.RoutePointsLayoutSizing = {
    js: BASE + "shared/widget-kits/nav/RoutePointsLayoutSizing.js",
    css: undefined,
    globalKey: "DyniRoutePointsLayoutSizing",
    deps: ["ValueMath"]
  };

  sf.RoutePointsRowGeometry = {
    js: BASE + "shared/widget-kits/nav/RoutePointsRowGeometry.js",
    css: undefined,
    globalKey: "DyniRoutePointsRowGeometry",
    deps: ["LayoutRectMath", "RoutePointsLayoutSizing"]
  };

  sf.RoutePointsLayout = {
    js: BASE + "shared/widget-kits/nav/RoutePointsLayout.js",
    css: undefined,
    globalKey: "DyniRoutePointsLayout",
    deps: ["ResponsiveScaleProfile", "LayoutRectMath", "RoutePointsLayoutSizing", "RoutePointsRowGeometry"]
  };

  sf.RoutePointsInfoText = {
    js: BASE + "shared/widget-kits/nav/RoutePointsInfoText.js",
    css: undefined,
    globalKey: "DyniRoutePointsInfoText",
    deps: ["UnitAwareFormatter"]
  };

  sf.RoutePointsHtmlFit = {
    js: BASE + "shared/widget-kits/nav/RoutePointsHtmlFit.js",
    css: undefined,
    globalKey: "DyniRoutePointsHtmlFit",
    deps: [
      "CanvasTextLayout",
      "TextTileLayout",
      "RoutePointsLayout",
      "HtmlWidgetUtils",
      "HtmlMeasureUtils",
      "RoutePointsInfoText",
      "ValueMath"
    ]
  };

  sf.MapZoomHtmlFit = {
    js: BASE + "shared/widget-kits/nav/MapZoomHtmlFit.js",
    css: undefined,
    globalKey: "DyniMapZoomHtmlFit",
    deps: ["TextLayoutEngine", "HtmlWidgetUtils", "HtmlMeasureUtils", "ValueMath"]
  };

  sf.RegattaTimerHtmlFit = {
    js: BASE + "shared/widget-kits/vessel/RegattaTimerHtmlFit.js",
    css: undefined,
    globalKey: "DyniRegattaTimerHtmlFit",
    deps: ["HtmlWidgetUtils", "ValueMath", "GeometryScale", "RegattaTimerPhase", "HtmlMeasureUtils", "TextLayoutEngine"]
  };

  sf.CenterDisplayLayout = {
    js: BASE + "shared/widget-kits/nav/CenterDisplayLayout.js",
    css: undefined,
    globalKey: "DyniCenterDisplayLayout",
    deps: ["ResponsiveScaleProfile", "LayoutRectMath", "LayoutSizingHelpers", "ValueMath"]
  };

  sf.CenterDisplayMath = {
    js: BASE + "shared/widget-kits/nav/CenterDisplayMath.js",
    css: undefined,
    globalKey: "DyniCenterDisplayMath",
    deps: ["ValueMath"]
  };

  sf.CenterDisplayRenderModel = {
    js: BASE + "shared/widget-kits/nav/CenterDisplayRenderModel.js",
    css: undefined,
    globalKey: "DyniCenterDisplayRenderModel",
    deps: ["StableDigits", "UnitAwareFormatter", "ValueMath"]
  };

  sf.NavModeRatio = {
    js: BASE + "shared/widget-kits/nav/NavModeRatio.js",
    css: undefined,
    globalKey: "DyniNavModeRatio"
  };

  sf.RegattaTimerPhase = {
    js: BASE + "shared/widget-kits/vessel/RegattaTimerPhase.js",
    css: undefined,
    globalKey: "DyniRegattaTimerPhase"
  };
})(this);

/**
 * @file DyniPlugin Shared Foundation Registry State - Shared state, DOM, caching, and animation component definitions
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const config = ns.config;
  const shared = (config.shared = config.shared || {});
  const BASE = ns.baseUrl;

  if (typeof BASE !== "string" || !BASE) {
    throw new Error(
      "dyninstruments: baseUrl missing before config/components/registry-shared-foundation-state.js load"
    );
  }

  const groups = (shared.componentRegistryGroups = shared.componentRegistryGroups || {});
  var sf = (groups.sharedFoundation = groups.sharedFoundation || {});

  sf.StateScreenLabels = {
    js: BASE + "shared/widget-kits/state/StateScreenLabels.js",
    css: undefined,
    globalKey: "DyniStateScreenLabels"
  };

  sf.StateScreenPrecedence = {
    js: BASE + "shared/widget-kits/state/StateScreenPrecedence.js",
    css: undefined,
    globalKey: "DyniStateScreenPrecedence"
  };

  sf.StateScreenInteraction = {
    js: BASE + "shared/widget-kits/state/StateScreenInteraction.js",
    css: undefined,
    globalKey: "DyniStateScreenInteraction"
  };

  sf.StateScreenTextFit = {
    js: BASE + "shared/widget-kits/state/StateScreenTextFit.js",
    css: undefined,
    globalKey: "DyniStateScreenTextFit",
    deps: ["ValueMath", "HtmlWidgetUtils", "HtmlMeasureUtils", "CanvasTextFitting"]
  };

  sf.StateScreenMarkup = {
    js: BASE + "shared/widget-kits/state/StateScreenMarkup.js",
    css: undefined,
    globalKey: "DyniStateScreenMarkup",
    deps: ["HtmlWidgetUtils", "StateScreenLabels", "StateScreenTextFit", "ValueMath"]
  };

  sf.StateScreenCanvasOverlay = {
    js: BASE + "shared/widget-kits/state/StateScreenCanvasOverlay.js",
    css: undefined,
    globalKey: "DyniStateScreenCanvasOverlay",
    deps: ["StateScreenLabels", "CanvasTextFitting"]
  };

  sf.HtmlDomPatchUtils = {
    js: BASE + "shared/widget-kits/html/HtmlDomPatchUtils.js",
    css: undefined,
    globalKey: "DyniHtmlDomPatchUtils",
    deps: ["ValueMath"]
  };

  sf.HtmlWidgetUtils = {
    js: BASE + "shared/widget-kits/html/HtmlWidgetUtils.js",
    css: undefined,
    globalKey: "DyniHtmlWidgetUtils",
    deps: ["ValueMath", "HtmlDomPatchUtils"]
  };

  sf.PreparedPayloadModelCache = {
    js: BASE + "shared/widget-kits/html/PreparedPayloadModelCache.js",
    css: undefined,
    globalKey: "DyniPreparedPayloadModelCache"
  };

  sf.CanvasLayerCache = {
    js: BASE + "shared/widget-kits/canvas/CanvasLayerCache.js",
    css: undefined,
    globalKey: "DyniCanvasLayerCache",
    deps: ["ValueMath"]
  };

  sf.SpringEasing = {
    js: BASE + "shared/widget-kits/anim/SpringEasing.js",
    css: undefined,
    globalKey: "DyniSpringEasing",
    deps: ["ValueMath"]
  };

  sf.HtmlWidgetLifecycle = {
    js: BASE + "shared/widget-kits/html/HtmlWidgetLifecycle.js",
    css: undefined,
    globalKey: "DyniHtmlWidgetLifecycle"
  };

  sf.CenterDisplayStateAdapter = {
    js: BASE + "shared/widget-kits/text/CenterDisplayStateAdapter.js",
    css: undefined,
    globalKey: "DyniCenterDisplayStateAdapter",
    deps: ["StateScreenLabels", "StateScreenPrecedence", "StateScreenCanvasOverlay"]
  };
})(this);

/**
 * @file DyniPlugin Shared Foundation Registry Xte - Shared XTE display component definitions
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  /** @typedef {DyniPluginSharedConfig & { componentRegistryGroups: Record<string, DyniComponentRegistryGroup> }} DyniFoundationRegistryShared */

  const ns = /** @type {DyniPluginNamespace} */ (/** @type {unknown} */ (root.DyniPlugin));
  const config = ns.config;
  const shared = /** @type {DyniFoundationRegistryShared} */ (config.shared = config.shared || {});
  const BASE = ns.baseUrl;

  if (typeof BASE !== "string" || !BASE) {
    throw new Error("dyninstruments: baseUrl missing before config/components/registry-shared-foundation-xte.js load");
  }

  const groups = (shared.componentRegistryGroups = shared.componentRegistryGroups || {});
  var sf = /** @type {DyniComponentRegistryGroup} */ (groups.sharedFoundation = groups.sharedFoundation || {});

  sf.XteHighwayLayout = {
    js: BASE + "shared/widget-kits/xte/XteHighwayLayout.js",
    css: undefined,
    globalKey: "DyniXteHighwayLayout",
    deps: ["ResponsiveScaleProfile", "LayoutRectMath", "LayoutSizingHelpers", "ValueMath"]
  };

  sf.XteLinearLayout = {
    js: BASE + "shared/widget-kits/xte/XteLinearLayout.js",
    css: undefined,
    globalKey: "DyniXteLinearLayout",
    deps: ["ResponsiveScaleProfile", "LayoutRectMath", "LayoutSizingHelpers", "ValueMath"]
  };

  sf.XteHighwayPrimitives = {
    js: BASE + "shared/widget-kits/xte/XteHighwayPrimitives.js",
    css: undefined,
    globalKey: "DyniXteHighwayPrimitives",
    deps: ["GeometryScale", "ValueMath"]
  };

  sf.XteLinearPrimitives = {
    js: BASE + "shared/widget-kits/xte/XteLinearPrimitives.js",
    css: undefined,
    globalKey: "DyniXteLinearPrimitives",
    deps: ["GaugeToolkit", "LinearGaugeMath", "GeometryScale", "LinearCanvasPrimitives"]
  };

  sf.XteLinearDynamicMetrics = {
    js: BASE + "shared/widget-kits/xte/XteLinearDynamicMetrics.js",
    css: undefined,
    globalKey: "DyniXteLinearDynamicMetrics",
    deps: [
      "GaugeToolkit",
      "LinearGaugeMath",
      "XteLinearPrimitives",
      "PlaceholderNormalize",
      "UnitAwareFormatter",
      "SpringEasing",
      "StableDigits",
      "XteLinearLayout",
      "TextTileLayout"
    ]
  };

  sf.XteDisplayPropsNormalize = {
    js: BASE + "shared/widget-kits/xte/XteDisplayPropsNormalize.js",
    css: undefined,
    globalKey: "DyniXteDisplayPropsNormalize"
  };

  sf.XteDisplayRenderSetup = {
    js: BASE + "shared/widget-kits/xte/XteDisplayRenderSetup.js",
    css: undefined,
    globalKey: "DyniXteDisplayRenderSetup"
  };

  sf.XteDisplayMetrics = {
    js: BASE + "shared/widget-kits/xte/XteDisplayMetrics.js",
    css: undefined,
    globalKey: "DyniXteDisplayMetrics",
    deps: [
      "GaugeToolkit",
      "XteHighwayPrimitives",
      "XteHighwayLayout",
      "TextTileLayout",
      "PlaceholderNormalize",
      "StableDigits",
      "UnitAwareFormatter"
    ]
  };
})(this);

/**
 * @file DyniPlugin Shared Engines Registry - Shared rendering engine and layout component definitions
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const config = ns.config;
  const shared = (config.shared = config.shared || {});
  const BASE = ns.baseUrl;

  if (typeof BASE !== "string" || !BASE) {
    throw new Error("dyninstruments: baseUrl missing before config/components/registry-shared-engines.js load");
  }

  const groups = (shared.componentRegistryGroups = shared.componentRegistryGroups || {});

  groups.sharedEngines = {
    FullCircleRadialEngine: {
      js: BASE + "shared/widget-kits/radial/FullCircleRadialEngine.js",
      css: undefined,
      globalKey: "DyniFullCircleRadialEngine",
      deps: [
        "RadialToolkit",
        "CanvasLayerCache",
        "FullCircleRadialLayout",
        "StableDigits",
        "StateScreenLabels",
        "StateScreenPrecedence",
        "StateScreenCanvasOverlay"
      ]
    },
    FullCircleRadialLayout: {
      js: BASE + "shared/widget-kits/radial/FullCircleRadialLayout.js",
      css: undefined,
      globalKey: "DyniFullCircleRadialLayout",
      deps: ["ResponsiveScaleProfile", "LayoutRectMath", "GeometryScale", "TextLayoutScaleHelpers", "ValueMath"]
    },
    FullCircleRadialTextLayout: {
      js: BASE + "shared/widget-kits/radial/FullCircleRadialTextLayout.js",
      css: undefined,
      globalKey: "DyniFullCircleRadialTextLayout",
      deps: ["FullCircleRadialDrawing"]
    },
    FullCircleRadialDrawing: {
      js: BASE + "shared/widget-kits/radial/FullCircleRadialDrawing.js",
      css: undefined,
      globalKey: "DyniFullCircleRadialDrawing",
      deps: ["HtmlWidgetUtils", "FullCircleRadialMeasure"]
    },
    FullCircleRadialMeasure: {
      js: BASE + "shared/widget-kits/radial/FullCircleRadialMeasure.js",
      css: undefined,
      globalKey: "DyniFullCircleRadialMeasure",
      deps: ["ValueMath", "TextLayoutScaleHelpers"]
    },
    LinearGaugeEngine: {
      js: BASE + "shared/widget-kits/linear/LinearGaugeEngine.js",
      css: undefined,
      globalKey: "DyniLinearGaugeEngine",
      deps: [
        "GaugeToolkit",
        "CanvasLayerCache",
        "LinearCanvasPrimitives",
        "LinearGaugeEngineDrawing",
        "LinearGaugeEngineFrame",
        "LinearGaugeMath",
        "LinearGaugeLayout",
        "LinearGaugeTextLayout",
        "LinearGaugeEngineSupport",
        "TextLayoutScaleHelpers",
        "SpringEasing",
        "StableDigits",
        "StateScreenLabels",
        "StateScreenPrecedence",
        "StateScreenCanvasOverlay"
      ]
    },
    LinearGaugeEngineFrame: {
      js: BASE + "shared/widget-kits/linear/LinearGaugeEngineFrame.js",
      css: undefined,
      globalKey: "DyniLinearGaugeEngineFrame",
      deps: []
    },
    GaugeToolkit: {
      js: BASE + "shared/widget-kits/gauge/GaugeToolkit.js",
      css: undefined,
      globalKey: "DyniGaugeToolkit",
      deps: ["CanvasTextLayout", "ValueMath"]
    },
    RadialToolkit: {
      js: BASE + "shared/widget-kits/radial/RadialToolkit.js",
      css: undefined,
      globalKey: "DyniRadialToolkit",
      deps: ["GaugeToolkit", "RadialAngleMath", "RadialTickMath", "RadialCanvasPrimitives", "RadialFrameRenderer"]
    },
    RadialMajorValueLabels: {
      js: BASE + "shared/widget-kits/radial/RadialMajorValueLabels.js",
      css: undefined,
      globalKey: "DyniRadialMajorValueLabels",
      deps: ["RadialToolkit"]
    },
    SemicircleRadialEngine: {
      js: BASE + "shared/widget-kits/radial/SemicircleRadialEngine.js",
      css: undefined,
      globalKey: "DyniSemicircleRadialEngine",
      deps: [
        "RadialToolkit",
        "CanvasLayerCache",
        "SemicircleRadialLayout",
        "SemicircleRadialTextLayout",
        "RadialSectorMath",
        "RadialValueMath",
        "SpringEasing",
        "StableDigits",
        "StateScreenLabels",
        "StateScreenPrecedence",
        "StateScreenCanvasOverlay",
        "RadialMajorValueLabels"
      ]
    },
    SemicircleRadialLayout: {
      js: BASE + "shared/widget-kits/radial/SemicircleRadialLayout.js",
      css: undefined,
      globalKey: "DyniSemicircleRadialLayout",
      deps: ["ResponsiveScaleProfile", "LayoutRectMath", "GeometryScale", "TextLayoutScaleHelpers", "ValueMath"]
    },
    SemicircleRadialTextLayout: {
      js: BASE + "shared/widget-kits/radial/SemicircleRadialTextLayout.js",
      css: undefined,
      globalKey: "DyniSemicircleRadialTextLayout",
      deps: ["TextLayoutScaleHelpers", "TextLayoutEngine", "HtmlWidgetUtils"]
    }
  };
})(this);

/**
 * @file DyniPlugin Widgets Registry Nav - Nav and route widget component definitions
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const config = ns.config;
  const shared = (config.shared = config.shared || {});
  const BASE = ns.baseUrl;

  if (typeof BASE !== "string" || !BASE) {
    throw new Error("dyninstruments: baseUrl missing before config/components/registry-widgets-nav.js load");
  }

  const SHARED_HTML_SHADOW_CSS = BASE + "shared/html/HtmlShadowCommon.css";

  const groups = (shared.componentRegistryGroups = shared.componentRegistryGroups || {});
  var w = (groups.widgets = groups.widgets || {});

  w.NavInteractionPolicy = {
    js: BASE + "shared/widget-kits/nav/NavInteractionPolicy.js",
    css: undefined,
    globalKey: "DyniNavInteractionPolicy",
    deps: ["HtmlWidgetUtils", "ValueMath"]
  };

  w.AisTargetRenderModel = {
    js: BASE + "shared/widget-kits/nav/AisTargetRenderModel.js",
    css: undefined,
    globalKey: "DyniAisTargetRenderModel",
    deps: [
      "AisTargetLayout",
      "HtmlWidgetUtils",
      "PlaceholderNormalize",
      "StableDigits",
      "StateScreenLabels",
      "StateScreenPrecedence",
      "StateScreenInteraction",
      "UnitAwareFormatter",
      "ValueMath"
    ]
  };

  w.AisTargetMarkup = {
    js: BASE + "shared/widget-kits/nav/AisTargetMarkup.js",
    css: undefined,
    globalKey: "DyniAisTargetMarkup",
    deps: ["StateScreenMarkup", "ValueMath"]
  };

  w.AisTargetTextHtmlWidget = {
    js: BASE + "widgets/text/AisTargetTextHtmlWidget/AisTargetTextHtmlWidget.js",
    css: undefined,
    shadowCss: [SHARED_HTML_SHADOW_CSS, BASE + "widgets/text/AisTargetTextHtmlWidget/AisTargetTextHtmlWidget.css"],
    globalKey: "DyniAisTargetTextHtmlWidget",
    deps: [
      "AisTargetHtmlFit",
      "HtmlWidgetUtils",
      "HtmlWidgetLifecycle",
      "AisTargetRenderModel",
      "AisTargetMarkup",
      "ValueMath"
    ]
  };

  w.ActiveRouteTextHtmlWidget = {
    js: BASE + "widgets/text/ActiveRouteTextHtmlWidget/ActiveRouteTextHtmlWidget.js",
    css: undefined,
    shadowCss: [SHARED_HTML_SHADOW_CSS, BASE + "widgets/text/ActiveRouteTextHtmlWidget/ActiveRouteTextHtmlWidget.css"],
    globalKey: "DyniActiveRouteTextHtmlWidget",
    deps: [
      "ActiveRouteHtmlFit",
      "HtmlWidgetUtils",
      "NavInteractionPolicy",
      "HtmlWidgetLifecycle",
      "PreparedPayloadModelCache",
      "PlaceholderNormalize",
      "StableDigits",
      "StateScreenLabels",
      "StateScreenPrecedence",
      "StateScreenInteraction",
      "StateScreenMarkup"
    ]
  };

  w.EditRouteRenderModel = {
    js: BASE + "shared/widget-kits/nav/EditRouteRenderModel.js",
    css: undefined,
    globalKey: "DyniEditRouteRenderModel",
    deps: [
      "EditRouteLayout",
      "HtmlWidgetUtils",
      "NavInteractionPolicy",
      "PlaceholderNormalize",
      "StableDigits",
      "StateScreenLabels",
      "StateScreenPrecedence",
      "StateScreenInteraction",
      "UnitAwareFormatter",
      "ValueMath"
    ]
  };

  w.EditRouteMarkup = {
    js: BASE + "shared/widget-kits/nav/EditRouteMarkup.js",
    css: undefined,
    globalKey: "DyniEditRouteMarkup",
    deps: ["StateScreenMarkup", "ValueMath"]
  };

  w.EditRouteTextHtmlWidget = {
    js: BASE + "widgets/text/EditRouteTextHtmlWidget/EditRouteTextHtmlWidget.js",
    css: undefined,
    shadowCss: [SHARED_HTML_SHADOW_CSS, BASE + "widgets/text/EditRouteTextHtmlWidget/EditRouteTextHtmlWidget.css"],
    globalKey: "DyniEditRouteTextHtmlWidget",
    deps: ["EditRouteHtmlFit", "HtmlWidgetUtils", "HtmlWidgetLifecycle", "EditRouteRenderModel", "EditRouteMarkup"]
  };

  w.RoutePointsRenderModel = {
    js: BASE + "shared/widget-kits/nav/RoutePointsRenderModel.js",
    css: undefined,
    globalKey: "DyniRoutePointsRenderModel",
    deps: [
      "CenterDisplayMath",
      "RoutePointsHtmlFit",
      "RoutePointsLayout",
      "HtmlWidgetUtils",
      "NavInteractionPolicy",
      "PlaceholderNormalize",
      "StableDigits",
      "StateScreenLabels",
      "StateScreenPrecedence",
      "StateScreenInteraction",
      "ValueMath"
    ]
  };

  w.RoutePointsMarkup = {
    js: BASE + "shared/widget-kits/nav/RoutePointsMarkup.js",
    css: undefined,
    globalKey: "DyniRoutePointsMarkup",
    deps: ["StateScreenMarkup", "ValueMath"]
  };

  w.RoutePointsDomEffects = {
    js: BASE + "shared/widget-kits/nav/RoutePointsDomEffects.js",
    css: undefined,
    globalKey: "DyniRoutePointsDomEffects",
    deps: ["HtmlWidgetUtils", "ValueMath"]
  };

  w.RoutePointsTextHtmlWidget = {
    js: BASE + "widgets/text/RoutePointsTextHtmlWidget/RoutePointsTextHtmlWidget.js",
    css: undefined,
    shadowCss: [SHARED_HTML_SHADOW_CSS, BASE + "widgets/text/RoutePointsTextHtmlWidget/RoutePointsTextHtmlWidget.css"],
    globalKey: "DyniRoutePointsTextHtmlWidget",
    deps: [
      "RoutePointsHtmlFit",
      "HtmlWidgetUtils",
      "HtmlWidgetLifecycle",
      "RoutePointsRenderModel",
      "RoutePointsLayout",
      "RoutePointsMarkup",
      "RoutePointsDomEffects"
    ]
  };

  w.MapZoomMarkup = {
    js: BASE + "shared/widget-kits/nav/MapZoomMarkup.js",
    css: undefined,
    globalKey: "DyniMapZoomMarkup",
    deps: ["HtmlWidgetUtils", "StateScreenLabels", "StateScreenMarkup"]
  };

  w.MapZoomTextHtmlWidget = {
    js: BASE + "widgets/text/MapZoomTextHtmlWidget/MapZoomTextHtmlWidget.js",
    css: undefined,
    shadowCss: [SHARED_HTML_SHADOW_CSS, BASE + "widgets/text/MapZoomTextHtmlWidget/MapZoomTextHtmlWidget.css"],
    globalKey: "DyniMapZoomTextHtmlWidget",
    deps: [
      "MapZoomHtmlFit",
      "HtmlWidgetUtils",
      "HtmlWidgetLifecycle",
      "MapZoomMarkup",
      "ValueMath",
      "PlaceholderNormalize",
      "PreparedPayloadModelCache",
      "StableDigits",
      "StateScreenLabels",
      "StateScreenPrecedence",
      "StateScreenInteraction"
    ]
  };

  w.CenterDisplayTextWidget = {
    js: BASE + "widgets/text/CenterDisplayTextWidget/CenterDisplayTextWidget.js",
    css: undefined,
    globalKey: "DyniCenterDisplayTextWidget",
    deps: [
      "TextLayoutEngine",
      "CanvasTextLayout",
      "TextTileLayout",
      "TextLayoutScaleHelpers",
      "CenterDisplayLayout",
      "CenterDisplayMath",
      "CenterDisplayStateAdapter",
      "CenterDisplayRenderModel"
    ]
  };
})(this);

/**
 * @file DyniPlugin Widgets Registry Vessel - Vessel, alarm, and text widget component definitions
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const config = ns.config;
  const shared = (config.shared = config.shared || {});
  const BASE = ns.baseUrl;

  if (typeof BASE !== "string" || !BASE) {
    throw new Error("dyninstruments: baseUrl missing before config/components/registry-widgets-vessel.js load");
  }

  const SHARED_HTML_SHADOW_CSS = BASE + "shared/html/HtmlShadowCommon.css";

  const groups = (shared.componentRegistryGroups = shared.componentRegistryGroups || {});
  var w = (groups.widgets = groups.widgets || {});

  w.AlarmRenderModel = {
    js: BASE + "shared/widget-kits/vessel/AlarmRenderModel.js",
    css: undefined,
    globalKey: "DyniAlarmRenderModel",
    deps: ["HtmlWidgetUtils", "ValueMath"]
  };

  w.AlarmTextHtmlWidget = {
    js: BASE + "widgets/text/AlarmTextHtmlWidget/AlarmTextHtmlWidget.js",
    css: undefined,
    shadowCss: [SHARED_HTML_SHADOW_CSS, BASE + "widgets/text/AlarmTextHtmlWidget/AlarmTextHtmlWidget.css"],
    globalKey: "DyniAlarmTextHtmlWidget",
    deps: ["AlarmHtmlFit", "HtmlWidgetUtils", "AlarmRenderModel", "AlarmMarkup", "ValueMath"]
  };

  w.AlarmMarkup = {
    js: BASE + "shared/widget-kits/vessel/AlarmMarkup.js",
    css: undefined,
    globalKey: "DyniAlarmMarkup",
    deps: ["HtmlWidgetUtils", "ValueMath"]
  };

  w.RegattaTimerModel = {
    js: BASE + "shared/widget-kits/vessel/RegattaTimerModel.js",
    css: undefined,
    globalKey: "DyniRegattaTimerModel",
    deps: ["ValueMath"]
  };

  w.RegattaTimerAudio = {
    js: BASE + "shared/widget-kits/vessel/RegattaTimerAudio.js",
    css: undefined,
    globalKey: "DyniRegattaTimerAudio",
    deps: []
  };

  w.RegattaTimerSessionStore = {
    js: BASE + "shared/widget-kits/vessel/RegattaTimerSessionStore.js",
    css: undefined,
    globalKey: "DyniRegattaTimerSessionStore",
    deps: ["ValueMath"]
  };

  w.RegattaTimerMarkup = {
    js: BASE + "shared/widget-kits/vessel/RegattaTimerMarkup.js",
    css: undefined,
    globalKey: "DyniRegattaTimerMarkup",
    deps: ["HtmlWidgetUtils", "RegattaTimerPhase"]
  };

  w.RegattaTimerTextHtmlWidget = {
    js: BASE + "widgets/text/RegattaTimerTextHtmlWidget/RegattaTimerTextHtmlWidget.js",
    css: undefined,
    shadowCss: [
      SHARED_HTML_SHADOW_CSS,
      BASE + "widgets/text/RegattaTimerTextHtmlWidget/RegattaTimerTextHtmlWidget.css"
    ],
    globalKey: "DyniRegattaTimerTextHtmlWidget",
    deps: [
      "RegattaTimerModel",
      "RegattaTimerAudio",
      "RegattaTimerSessionStore",
      "RegattaTimerMarkup",
      "RegattaTimerHtmlFit",
      "HtmlWidgetUtils",
      "ValueMath"
    ]
  };

  w.PositionCoordinateWidget = {
    js: BASE + "widgets/text/PositionCoordinateWidget/PositionCoordinateWidget.js",
    css: undefined,
    globalKey: "DyniPositionCoordinateWidget",
    deps: [
      "TextLayoutEngine",
      "ValueMath",
      "PlaceholderNormalize",
      "StateScreenLabels",
      "StateScreenPrecedence",
      "StateScreenCanvasOverlay",
      "PositionCoordinateFormatting"
    ]
  };

  w.ThreeValueTextWidget = {
    js: BASE + "widgets/text/ThreeValueTextWidget/ThreeValueTextWidget.js",
    css: undefined,
    globalKey: "DyniThreeValueTextWidget",
    deps: [
      "TextLayoutEngine",
      "PlaceholderNormalize",
      "StableDigits",
      "StateScreenLabels",
      "StateScreenPrecedence",
      "StateScreenCanvasOverlay"
    ]
  };

  w.XteDisplayWidget = {
    js: BASE + "widgets/text/XteDisplayWidget/XteDisplayWidget.js",
    css: undefined,
    globalKey: "DyniXteDisplayWidget",
    deps: [
      "GaugeToolkit",
      "CanvasLayerCache",
      "XteHighwayPrimitives",
      "XteDisplayPropsNormalize",
      "XteDisplayRenderSetup",
      "XteHighwayLayout",
      "TextTileLayout",
      "SpringEasing",
      "XteDisplayMetrics",
      "StateScreenLabels",
      "StateScreenPrecedence",
      "StateScreenCanvasOverlay"
    ]
  };

  w.XteDisplayLinearWidget = {
    js: BASE + "widgets/text/XteDisplayLinearWidget/XteDisplayLinearWidget.js",
    css: undefined,
    globalKey: "DyniXteDisplayLinearWidget",
    deps: [
      "GaugeToolkit",
      "CanvasLayerCache",
      "LinearGaugeMath",
      "XteLinearPrimitives",
      "XteDisplayPropsNormalize",
      "XteDisplayRenderSetup",
      "XteLinearLayout",
      "TextTileLayout",
      "XteLinearDynamicMetrics",
      "StateScreenLabels",
      "StateScreenPrecedence",
      "StateScreenCanvasOverlay"
    ]
  };
})(this);

/**
 * @file DyniPlugin Widgets Registry Gauge - Gauge widget component definitions
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const config = ns.config;
  const shared = (config.shared = config.shared || {});
  const BASE = ns.baseUrl;

  if (typeof BASE !== "string" || !BASE) {
    throw new Error("dyninstruments: baseUrl missing before config/components/registry-widgets-gauge.js load");
  }

  const groups = (shared.componentRegistryGroups = shared.componentRegistryGroups || {});
  var w = (groups.widgets = groups.widgets || {});

  w.ClockRadialWidget = {
    js: BASE + "widgets/radial/ClockRadialWidget/ClockRadialWidget.js",
    css: undefined,
    globalKey: "DyniClockRadialWidget",
    deps: ["FullCircleRadialEngine", "GeometryScale"]
  };

  w.CompassLinearWidget = {
    js: BASE + "widgets/linear/CompassLinearWidget/CompassLinearWidget.js",
    css: undefined,
    globalKey: "DyniCompassLinearWidget",
    deps: ["LinearGaugeEngine", "ValueMath", "SpringEasing"]
  };

  w.CompassRadialWidget = {
    js: BASE + "widgets/radial/CompassRadialWidget/CompassRadialWidget.js",
    css: undefined,
    globalKey: "DyniCompassRadialWidget",
    deps: ["FullCircleRadialEngine", "FullCircleRadialTextLayout", "SpringEasing", "StableDigits"]
  };

  w.DepthLinearWidget = {
    js: BASE + "widgets/linear/DepthLinearWidget/DepthLinearWidget.js",
    css: undefined,
    globalKey: "DyniDepthLinearWidget",
    deps: ["LinearGaugeEngine", "ValueMath", "DepthDisplayFormatter", "PlaceholderNormalize", "UnitAwareFormatter"]
  };

  w.DepthRadialWidget = {
    js: BASE + "widgets/radial/DepthRadialWidget/DepthRadialWidget.js",
    css: undefined,
    globalKey: "DyniDepthRadialWidget",
    deps: ["SemicircleRadialEngine", "ValueMath", "DepthDisplayFormatter", "PlaceholderNormalize", "UnitAwareFormatter"]
  };

  w.DefaultRadialWidget = {
    js: BASE + "widgets/radial/DefaultRadialWidget/DefaultRadialWidget.js",
    css: undefined,
    globalKey: "DyniDefaultRadialWidget",
    deps: ["SemicircleRadialEngine", "ValueMath", "PlaceholderNormalize"]
  };

  w.DefaultLinearWidget = {
    js: BASE + "widgets/linear/DefaultLinearWidget/DefaultLinearWidget.js",
    css: undefined,
    globalKey: "DyniDefaultLinearWidget",
    deps: ["LinearGaugeEngine", "ValueMath", "PlaceholderNormalize"]
  };

  w.SpeedLinearWidget = {
    js: BASE + "widgets/linear/SpeedLinearWidget/SpeedLinearWidget.js",
    css: undefined,
    globalKey: "DyniSpeedLinearWidget",
    deps: ["LinearGaugeEngine", "ValueMath", "PlaceholderNormalize"]
  };

  w.SpeedRadialWidget = {
    js: BASE + "widgets/radial/SpeedRadialWidget/SpeedRadialWidget.js",
    css: undefined,
    globalKey: "DyniSpeedRadialWidget",
    deps: ["SemicircleRadialEngine", "ValueMath", "PlaceholderNormalize"]
  };

  w.TemperatureLinearWidget = {
    js: BASE + "widgets/linear/TemperatureLinearWidget/TemperatureLinearWidget.js",
    css: undefined,
    globalKey: "DyniTemperatureLinearWidget",
    deps: ["LinearGaugeEngine", "ValueMath", "PlaceholderNormalize"]
  };

  w.TemperatureRadialWidget = {
    js: BASE + "widgets/radial/TemperatureRadialWidget/TemperatureRadialWidget.js",
    css: undefined,
    globalKey: "DyniTemperatureRadialWidget",
    deps: ["SemicircleRadialEngine", "ValueMath", "PlaceholderNormalize"]
  };

  w.VoltageLinearWidget = {
    js: BASE + "widgets/linear/VoltageLinearWidget/VoltageLinearWidget.js",
    css: undefined,
    globalKey: "DyniVoltageLinearWidget",
    deps: ["LinearGaugeEngine", "ValueMath", "PlaceholderNormalize"]
  };

  w.VoltageRadialWidget = {
    js: BASE + "widgets/radial/VoltageRadialWidget/VoltageRadialWidget.js",
    css: undefined,
    globalKey: "DyniVoltageRadialWidget",
    deps: ["SemicircleRadialEngine", "ValueMath", "PlaceholderNormalize"]
  };

  w.WindLinearWidget = {
    js: BASE + "widgets/linear/WindLinearWidget/WindLinearWidget.js",
    css: undefined,
    globalKey: "DyniWindLinearWidget",
    deps: ["LinearGaugeEngine", "ValueMath", "StableDigits", "PlaceholderNormalize"]
  };

  w.WindRadialWidget = {
    js: BASE + "widgets/radial/WindRadialWidget/WindRadialWidget.js",
    css: undefined,
    globalKey: "DyniWindRadialWidget",
    deps: [
      "FullCircleRadialEngine",
      "FullCircleRadialTextLayout",
      "ValueMath",
      "SpringEasing",
      "StableDigits",
      "PlaceholderNormalize"
    ]
  };
})(this);

/**
 * @file DyniPlugin Cluster Registry - Cluster mapper/renderer/router component definitions
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const config = ns.config;
  const shared = (config.shared = config.shared || {});
  const BASE = ns.baseUrl;

  if (typeof BASE !== "string" || !BASE) {
    throw new Error("dyninstruments: baseUrl missing before config/components/registry-cluster.js load");
  }

  const groups = (shared.componentRegistryGroups = shared.componentRegistryGroups || {});

  groups.cluster = {
    AisTargetViewModel: {
      js: BASE + "cluster/viewmodels/AisTargetViewModel.js",
      css: undefined,
      globalKey: "DyniAisTargetViewModel",
      deps: ["ValueMath"]
    },
    AlarmViewModel: {
      js: BASE + "cluster/viewmodels/AlarmViewModel.js",
      css: undefined,
      globalKey: "DyniAlarmViewModel"
    },
    ActiveRouteViewModel: {
      js: BASE + "cluster/viewmodels/ActiveRouteViewModel.js",
      css: undefined,
      globalKey: "DyniActiveRouteViewModel",
      deps: ["ValueMath"]
    },
    EditRouteViewModel: {
      js: BASE + "cluster/viewmodels/EditRouteViewModel.js",
      css: undefined,
      globalKey: "DyniEditRouteViewModel",
      deps: ["CenterDisplayMath", "ValueMath"]
    },
    RoutePointsViewModel: {
      js: BASE + "cluster/viewmodels/RoutePointsViewModel.js",
      css: undefined,
      globalKey: "DyniRoutePointsViewModel",
      deps: ["ValueMath"]
    },
    AnchorMapper: {
      js: BASE + "cluster/mappers/AnchorMapper.js",
      css: undefined,
      globalKey: "DyniAnchorMapper"
    },
    DefaultMapper: {
      js: BASE + "cluster/mappers/DefaultMapper.js",
      css: undefined,
      globalKey: "DyniDefaultMapper"
    },
    ClusterMapperToolkit: {
      js: BASE + "cluster/mappers/ClusterMapperToolkit.js",
      css: undefined,
      globalKey: "DyniClusterMapperToolkit",
      deps: ["RadialAngleMath", "ValueMath"]
    },
    ClusterWidget: {
      js: BASE + "cluster/ClusterWidget.js",
      css: undefined,
      globalKey: "DyniClusterWidget",
      deps: ["ValueMath"]
    },
    CourseHeadingMapper: {
      js: BASE + "cluster/mappers/CourseHeadingMapper.js",
      css: undefined,
      globalKey: "DyniCourseHeadingMapper"
    },
    NavMapper: {
      js: BASE + "cluster/mappers/NavMapper.js",
      css: undefined,
      globalKey: "DyniNavMapper"
    },
    MapMapper: {
      js: BASE + "cluster/mappers/MapMapper.js",
      css: undefined,
      globalKey: "DyniMapMapper"
    },
    SpeedMapper: {
      js: BASE + "cluster/mappers/SpeedMapper.js",
      css: undefined,
      globalKey: "DyniSpeedMapper"
    },
    VesselMapper: {
      js: BASE + "cluster/mappers/VesselMapper.js",
      css: undefined,
      globalKey: "DyniVesselMapper",
      deps: ["ValueMath"]
    },
    EnvironmentMapper: {
      js: BASE + "cluster/mappers/EnvironmentMapper.js",
      css: undefined,
      globalKey: "DyniEnvironmentMapper"
    },
    WindMapper: {
      js: BASE + "cluster/mappers/WindMapper.js",
      css: undefined,
      globalKey: "DyniWindMapper"
    }
  };
})(this);

/**
 * @file DyniUnitFormatFamilies - Bootstrap-loaded formatter family catalog and metric bindings
 * Documentation: documentation/architecture/component-system.md
 */
(function (root, factory) {
  if (typeof define === "function" && define.amd) {
    define([], factory);
  } else if (typeof module === "object" && module.exports) {
    module.exports = factory();
  } else {
    (root.DyniComponents = root.DyniComponents || {}).DyniUnitFormatFamilies = factory();
  }
})(
  this,
  /** @this {unknown} */ function () {
    "use strict";

    /** @typedef {{ tokens: readonly string[], labels: Readonly<Record<string, string>>, selectorList: readonly DyniEditableOption[] }} DyniUnitFormatFamilyRecord */
    /** @typedef {{ families: Readonly<Record<string, DyniUnitFormatFamilyRecord>>, metricBindings: Readonly<Record<string, DyniUnitFormatBinding>> }} DyniUnitFormatCatalogRecord */
    /** @typedef {{ config?: DyniPluginConfig }} DyniUnitFormatNamespace */
    /** @typedef {{ DyniPlugin?: DyniUnitFormatNamespace, DyniComponents?: Record<string, unknown> }} DyniUnitFormatGlobalRoot */

    const globalRoot = /** @type {DyniUnitFormatGlobalRoot} */ (
      typeof globalThis !== "undefined"
        ? globalThis
        : typeof window !== "undefined"
          ? window
          : /** @type {unknown} */ (this)
    );
    const ns = (globalRoot.DyniPlugin = globalRoot.DyniPlugin || {});
    const config = (ns.config = ns.config || /** @type {DyniPluginConfig} */ ({}));
    const shared = (config.shared = config.shared || {});

    /** @param {string} name @param {string} value @returns {DyniEditableOption} */
    function opt(name, value) {
      return { name: name, value: value };
    }

    /** @param {readonly string[]} tokens @param {Readonly<Record<string, string>>} labels @returns {readonly DyniEditableOption[]} */
    function freezeSelectorList(tokens, labels) {
      return Object.freeze(
        tokens.map(function (token) {
          return opt(labels[token], token);
        })
      );
    }

    /** @param {readonly string[]} tokens @param {Readonly<Record<string, string>>} labels @returns {DyniUnitFormatFamilyRecord} */
    function freezeFamily(tokens, labels) {
      const frozenTokens = Object.freeze(tokens.slice());
      const frozenLabels = Object.freeze(Object.assign({}, labels));
      return Object.freeze({
        tokens: frozenTokens,
        labels: frozenLabels,
        selectorList: freezeSelectorList(frozenTokens, frozenLabels)
      });
    }

    /** @param {string} family @param {string} defaultToken @param {string | undefined} [rendererKey] @returns {DyniUnitFormatBinding} */
    function freezeBinding(family, defaultToken, rendererKey) {
      /** @type {DyniUnitFormatBinding} */
      const out = {
        family: family,
        defaultToken: defaultToken
      };
      if (typeof rendererKey === "string" && rendererKey.length > 0) {
        out.rendererKey = rendererKey;
      }
      return Object.freeze(out);
    }

    const families = Object.freeze({
      speed: freezeFamily(["kn", "ms", "kmh"], {
        kn: "kn",
        ms: "m/s",
        kmh: "km/h"
      }),
      distance: freezeFamily(["nm", "m", "km", "ft", "yd"], {
        nm: "nm",
        m: "m",
        km: "km",
        ft: "ft",
        yd: "yd"
      }),
      temperature: freezeFamily(["celsius", "kelvin"], {
        celsius: "\u00b0C",
        kelvin: "K"
      }),
      pressure: freezeFamily(["pa", "hpa", "bar"], {
        pa: "Pa",
        hpa: "hPa",
        bar: "bar"
      })
    });

    const metricBindings = Object.freeze({
      sog: freezeBinding("speed", "kn"),
      stw: freezeBinding("speed", "kn"),
      sogLinear: freezeBinding("speed", "kn"),
      stwLinear: freezeBinding("speed", "kn"),
      sogRadial: freezeBinding("speed", "kn"),
      stwRadial: freezeBinding("speed", "kn"),
      vmg: freezeBinding("speed", "kn"),
      speedTrue: freezeBinding("speed", "kn"),
      speedApparent: freezeBinding("speed", "kn"),
      angleTrueRadialSpeed: freezeBinding("speed", "kn"),
      angleApparentRadialSpeed: freezeBinding("speed", "kn"),
      angleTrueLinearSpeed: freezeBinding("speed", "kn"),
      angleApparentLinearSpeed: freezeBinding("speed", "kn"),

      dst: freezeBinding("distance", "nm"),
      rteDistance: freezeBinding("distance", "nm"),
      activeRouteRemain: freezeBinding("distance", "nm", "remain"),
      xteDisplayXte: freezeBinding("distance", "nm", "xte"),
      xteDisplayDst: freezeBinding("distance", "nm", "dtw"),
      xteDisplayLinearXte: freezeBinding("distance", "nm", "xte"),
      xteDisplayLinearDst: freezeBinding("distance", "nm", "dtw"),
      editRouteDst: freezeBinding("distance", "nm", "dst"),
      editRouteRte: freezeBinding("distance", "nm", "rte"),
      routePointsDistance: freezeBinding("distance", "nm", "distance"),
      aisTargetDst: freezeBinding("distance", "nm", "dst"),
      aisTargetCpa: freezeBinding("distance", "nm", "cpa"),
      centerDisplayMarker: freezeBinding("distance", "nm", "marker"),
      centerDisplayBoat: freezeBinding("distance", "nm", "boat"),
      centerDisplayMeasure: freezeBinding("distance", "nm", "measure"),
      anchorDistance: freezeBinding("distance", "m"),
      anchorWatch: freezeBinding("distance", "m"),
      depth: freezeBinding("distance", "m"),
      depthLinear: freezeBinding("distance", "m"),
      depthRadial: freezeBinding("distance", "m"),

      temp: freezeBinding("temperature", "celsius"),
      tempLinear: freezeBinding("temperature", "celsius"),
      tempRadial: freezeBinding("temperature", "celsius"),

      pressure: freezeBinding("pressure", "hpa")
    });

    /** @type {DyniUnitFormatCatalogRecord} */
    const catalog = Object.freeze({
      families: families,
      metricBindings: metricBindings
    });

    shared.unitFormatFamilies = catalog;

    return catalog;
  }
);

/**
 * @file DyniPlugin Component Registry Assembly - Merges registry fragments into config.components
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const config = ns.config;
  const shared = (config.shared = config.shared || {});
  const BASE = ns.baseUrl;

  if (typeof BASE !== "string" || !BASE) {
    throw new Error("dyninstruments: baseUrl missing before config/components.js load");
  }

  const groups = shared.componentRegistryGroups;
  const orderedGroupIds = ["sharedFoundation", "sharedEngines", "widgets", "cluster"];
  /** @type {DyniComponentRegistryGroup} */
  const mergedComponents = {};

  if (!groups || typeof groups !== "object") {
    throw new Error("dyninstruments: component registry groups missing before config/components.js load");
  }

  orderedGroupIds.forEach(function (groupId) {
    const groupEntries = groups[groupId];
    if (!groupEntries || typeof groupEntries !== "object") {
      throw new Error("dyninstruments: missing component registry group '" + groupId + "'");
    }

    Object.keys(groupEntries).forEach(function (componentId) {
      if (Object.prototype.hasOwnProperty.call(mergedComponents, componentId)) {
        throw new Error("dyninstruments: duplicate component id '" + componentId + "' across registry groups");
      }
      mergedComponents[componentId] = groupEntries[componentId];
    });
  });

  config.components = mergedComponents;
})(this);

/**
 * @file DyniPlugin Cluster Utils - Shared helpers for cluster config authoring
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const config = /** @type {DyniPluginConfig} */ (ns.config);
  const shared = /** @type {DyniPluginSharedConfig} */ (config.shared);

  /** @param {unknown} kind @param {string} fallbackKind @returns {DyniEditableCondition} */
  function makeKindCondition(kind, fallbackKind) {
    if (Array.isArray(kind)) {
      return kind.map(function (k) {
        return { kind: k };
      });
    }
    if (typeof kind === "string" && kind.length) {
      return { kind: kind };
    }
    return { kind: fallbackKind };
  }

  /** @param {DyniPerKindTextParameterMap} map @returns {DyniEditableParameters} */
  function makePerKindTextParams(map) {
    const out = /** @type {DyniEditableParameters} */ ({});
    Object.keys(map).forEach(function (k) {
      const d = map[k];
      const condition = makeKindCondition(d.kind, k);
      out["caption_" + k] = {
        type: "STRING",
        displayName: typeof d.captionName === "string" && d.captionName.length ? d.captionName : "Caption",
        default: typeof d.cap === "string" ? d.cap : "",
        condition: condition
      };
      out["unit_" + k] = {
        type: "STRING",
        displayName: typeof d.unitName === "string" && d.unitName.length ? d.unitName : "Unit",
        default: typeof d.unit === "string" ? d.unit : "",
        condition: condition
      };
    });
    return out;
  }

  /** @param {unknown} name @param {unknown} value @returns {DyniEditableOption} */
  function opt(name, value) {
    return { name: name, value: value };
  }

  shared.makePerKindTextParams = makePerKindTextParams;
  shared.makeKindCondition = makeKindCondition;
  shared.opt = opt;
})(this);

/**
 * @file DyniPlugin Kind Maps - Per-kind caption and unit defaults
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  /** @typedef {DyniPluginSharedConfig & { kindMaps: Record<string, DyniPerKindTextParameterMap> }} DyniKindDefaultsShared */

  const ns = /** @type {DyniPluginNamespace} */ (/** @type {unknown} */ (root.DyniPlugin));
  const config = ns.config;
  const shared = /** @type {DyniKindDefaultsShared} */ (config.shared);

  shared.kindMaps = {
    DEFAULT_KIND: {
      text: { cap: "VALUE", unit: "" },
      linearGauge: { cap: "VALUE", unit: "" },
      radialGauge: { cap: "VALUE", unit: "" }
    },
    COURSE_KIND: {
      cog: { cap: "COG", unit: "\u00b0" },
      hdt: { cap: "HDT", unit: "\u00b0" },
      hdm: { cap: "HDM", unit: "\u00b0" },
      brg: { cap: "BRG", unit: "\u00b0" },
      hdtRadial: { cap: "HDT", unit: "\u00b0" },
      hdmRadial: { cap: "HDM", unit: "\u00b0" },
      hdtLinear: { cap: "HDT", unit: "\u00b0" },
      hdmLinear: { cap: "HDM", unit: "\u00b0" }
    },
    SPEED_KIND: {
      sog: { cap: "SOG" },
      stw: { cap: "STW" },
      sogLinear: { cap: "SOG" },
      stwLinear: { cap: "STW" },
      sogRadial: { cap: "SOG" },
      stwRadial: { cap: "STW" }
    },
    ENV_KIND: {
      depth: { cap: "DBK" },
      depthLinear: { cap: "DBK" },
      depthRadial: { cap: "DBK" },
      temp: { cap: "TEMP" },
      tempLinear: { cap: "TEMP" },
      tempRadial: { cap: "TEMP" },
      pressure: { cap: "PRES" }
    },
    WIND_ANGLE_KIND: {
      angleTrue: { cap: "TWA", unit: "\u00b0" },
      angleApparent: { cap: "AWA", unit: "\u00b0" },
      angleTrueDirection: { cap: "TWD", unit: "\u00b0" },
      angleTrueRadialAngle: {
        cap: "TWA",
        unit: "\u00b0",
        kind: "angleTrueRadial",
        captionName: "Angle caption",
        unitName: "Angle unit"
      },
      angleApparentRadialAngle: {
        cap: "AWA",
        unit: "\u00b0",
        kind: "angleApparentRadial",
        captionName: "Angle caption",
        unitName: "Angle unit"
      },
      angleTrueLinearAngle: {
        cap: "TWA",
        unit: "\u00b0",
        kind: "angleTrueLinear",
        captionName: "Angle caption",
        unitName: "Angle unit"
      },
      angleApparentLinearAngle: {
        cap: "AWA",
        unit: "\u00b0",
        kind: "angleApparentLinear",
        captionName: "Angle caption",
        unitName: "Angle unit"
      }
    },
    WIND_SPEED_KIND: {
      speedTrue: { cap: "TWS" },
      speedApparent: { cap: "AWS" },
      angleTrueRadialSpeed: {
        cap: "TWS",
        kind: "angleTrueRadial",
        captionName: "Speed caption",
        unitName: "Speed unit"
      },
      angleApparentRadialSpeed: {
        cap: "AWS",
        kind: "angleApparentRadial",
        captionName: "Speed caption",
        unitName: "Speed unit"
      },
      angleTrueLinearSpeed: {
        cap: "TWS",
        kind: "angleTrueLinear",
        captionName: "Speed caption",
        unitName: "Speed unit"
      },
      angleApparentLinearSpeed: {
        cap: "AWS",
        kind: "angleApparentLinear",
        captionName: "Speed caption",
        unitName: "Speed unit"
      }
    },
    NAV_TEXT_KIND: {
      wpEta: { cap: "WP ETA", unit: "" },
      rteEta: { cap: "RTE ETA", unit: "" },
      positionBoat: { cap: "POS", unit: "" },
      positionWp: { cap: "WP", unit: "" },
      activeRouteEta: {
        cap: "RTE ETA",
        unit: "",
        kind: "activeRoute",
        captionName: "RTE ETA caption",
        unitName: "RTE ETA unit"
      },
      activeRouteNextCourse: {
        cap: "NEXT",
        unit: "\u00b0",
        kind: "activeRoute",
        captionName: "Next course caption",
        unitName: "Next course unit"
      },
      xteDisplayCog: {
        cap: "COG",
        unit: "\u00b0",
        kind: "xteDisplay",
        captionName: "Track caption",
        unitName: "Track unit"
      },
      xteDisplayBrg: {
        cap: "BRG",
        unit: "\u00b0",
        kind: "xteDisplay",
        captionName: "BRG caption",
        unitName: "BRG unit"
      },
      xteDisplayLinearCog: {
        cap: "COG",
        unit: "\u00b0",
        kind: "xteDisplayLinear",
        captionName: "Track caption",
        unitName: "Track unit"
      },
      xteDisplayLinearBrg: {
        cap: "BRG",
        unit: "\u00b0",
        kind: "xteDisplayLinear",
        captionName: "BRG caption",
        unitName: "BRG unit"
      }
    },
    NAV_UNIT_AWARE_KIND: {
      dst: { cap: "DST" },
      rteDistance: { cap: "RTE" },
      vmg: { cap: "VMG" },
      activeRouteRemain: {
        cap: "RTE",
        kind: "activeRoute",
        captionName: "Route distance caption",
        unitName: "Route distance unit"
      },
      xteDisplayXte: {
        cap: "XTE",
        kind: "xteDisplay",
        captionName: "XTE caption",
        unitName: "XTE unit"
      },
      xteDisplayDst: {
        cap: "DST",
        kind: "xteDisplay",
        captionName: "DST caption",
        unitName: "DST unit"
      },
      xteDisplayLinearXte: {
        cap: "XTE",
        kind: "xteDisplayLinear",
        captionName: "XTE caption",
        unitName: "XTE unit"
      },
      xteDisplayLinearDst: {
        cap: "DST",
        kind: "xteDisplayLinear",
        captionName: "DST caption",
        unitName: "DST unit"
      }
    },
    MAP_TEXT_KIND: {
      zoom: { cap: "ZOOM", unit: "" },
      aisTargetTcpa: {
        cap: "TCPA",
        unit: "min",
        kind: "aisTarget",
        captionName: "TCPA caption",
        unitName: "TCPA unit"
      },
      aisTargetBrg: {
        cap: "BRG",
        unit: "\u00b0",
        kind: "aisTarget",
        captionName: "BRG caption",
        unitName: "BRG unit"
      },
      centerDisplayPosition: {
        cap: "CENTER",
        unit: "",
        kind: "centerDisplay",
        captionName: "Center caption",
        unitName: "Center unit"
      }
    },
    MAP_UNIT_AWARE_KIND: {
      aisTargetDst: {
        cap: "DST",
        kind: "aisTarget",
        captionName: "Distance caption",
        unitName: "Distance unit"
      },
      aisTargetCpa: {
        cap: "DCPA",
        kind: "aisTarget",
        captionName: "DCPA caption",
        unitName: "DCPA unit"
      },
      centerDisplayMarker: {
        cap: "WP",
        kind: "centerDisplay",
        captionName: "Waypoint caption",
        unitName: "Waypoint distance unit"
      },
      centerDisplayBoat: {
        cap: "POS",
        kind: "centerDisplay",
        captionName: "Boat caption",
        unitName: "Boat distance unit"
      },
      centerDisplayMeasure: {
        cap: "MEAS",
        kind: "centerDisplay",
        captionName: "Measure caption",
        unitName: "Measure distance unit"
      }
    },
    ANCHOR_TEXT_KIND: {
      anchorBearing: { cap: "ABRG", unit: "\u00b0" }
    },
    ANCHOR_UNIT_AWARE_KIND: {
      anchorDistance: { cap: "ANCHOR" },
      anchorWatch: { cap: "AWATCH" }
    },
    VESSEL_KIND: {
      voltage: { cap: "VOLT", unit: "V" },
      voltageLinear: { cap: "VOLT", unit: "V" },
      voltageRadial: { cap: "VOLT", unit: "V" },
      regattaTimer: { cap: "REGATTA", unit: "" },
      alarm: { cap: "ALARM", unit: "" },
      clock: { cap: "TIME", unit: "" },
      clockRadial: { cap: "TIME", unit: "" },
      dateTime: { cap: "", unit: "" },
      timeStatus: { cap: "", unit: "" },
      pitch: { cap: "PITCH", unit: "\u00b0" },
      roll: { cap: "ROLL", unit: "\u00b0" }
    }
  };
})(this);

/**
 * @file DyniPlugin Unit Editable Utils - Shared generators for formatter-token and unit-label editables
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  /** @typedef {{ min: number, max: number, step: number, default: number, internal?: boolean }} DyniUnitFloatTokenSpec */
  /** @typedef {{ baseKey?: unknown, key?: unknown, displayName?: unknown, name?: unknown, condition?: unknown, internal?: boolean, tokens?: Record<string, DyniUnitFloatTokenSpec>, perToken?: Record<string, DyniUnitFloatTokenSpec> }} DyniUnitFloatFieldSpec */
  /** @typedef {{ kind: unknown }} DyniUnitConditionItem */
  /** @typedef {DyniPluginSharedConfig & { kindMaps: Record<string, DyniPerKindTextParameterMap>, unitFormatFamilies: DyniUnitFormatCatalog, makeKindCondition: (kind: unknown, fallbackKind: string) => DyniEditableCondition, makeFormatUnitSelectParam: (metricKey: string, binding: DyniUnitFormatBinding, kindDef?: DyniPerKindTextParameterDescriptor) => DyniEditableParameters, makePerUnitStringParams: (metricKey: string, binding: DyniUnitFormatBinding, kindDef?: DyniPerKindTextParameterDescriptor) => DyniEditableParameters, makePerUnitFloatParams: (metricKey: string, binding: DyniUnitFormatBinding, kindDef: DyniPerKindTextParameterDescriptor | undefined, fieldSpec: DyniUnitFloatFieldSpec) => DyniEditableParameters }} DyniUnitEditableShared */

  const ns = /** @type {DyniPluginNamespace} */ (/** @type {unknown} */ (root.DyniPlugin));
  const config = ns.config;
  const shared = /** @type {DyniUnitEditableShared} */ (config.shared = config.shared || {});
  const makeKindCondition = shared.makeKindCondition;
  const kindMaps = shared.kindMaps;
  const catalog = shared.unitFormatFamilies;
  const valueMathModule = /** @type {{ create?: () => DyniValueMathApi } | undefined} */ (
    root.DyniComponents && root.DyniComponents.DyniValueMath
  );
  if (!valueMathModule || typeof valueMathModule.create !== "function") {
    throw new Error(
      "dyninstruments: shared/widget-kits/value/ValueMath.js must load before config/shared/unit-editable-utils.js"
    );
  }
  const valueMath = valueMathModule.create();
  if (!valueMath || typeof valueMath.toText !== "function") {
    throw new Error("dyninstruments: ValueMath.toText must exist before config/shared/unit-editable-utils.js");
  }
  const toText = valueMath.toText;

  if (!kindMaps || typeof kindMaps !== "object") {
    throw new Error("dyninstruments: kind-defaults.js must load before config/shared/unit-editable-utils.js");
  }

  if (!catalog || typeof catalog !== "object" || !catalog.families || !catalog.metricBindings) {
    throw new Error(
      "dyninstruments: shared/unit-format-families.js must load before config/shared/unit-editable-utils.js"
    );
  }

  /** @param {unknown} condition @returns {DyniUnitConditionItem[]} */
  function toConditionList(condition) {
    if (!condition) {
      return [];
    }
    return Array.isArray(condition)
      ? /** @type {DyniUnitConditionItem[]} */ (condition)
      : [/** @type {DyniUnitConditionItem} */ (condition)];
  }

  /** @param {unknown} baseCondition @param {unknown} extraCondition @returns {DyniEditableCondition | undefined} */
  function mergeConditions(baseCondition, extraCondition) {
    const baseList = toConditionList(baseCondition);
    const extraList = toConditionList(extraCondition);

    if (!baseList.length && !extraList.length) {
      return undefined;
    }
    if (!baseList.length) {
      return extraList.length === 1 ? /** @type {DyniEditableCondition} */ (extraList[0]) : extraList.slice();
    }
    if (!extraList.length) {
      return baseList.length === 1 ? /** @type {DyniEditableCondition} */ (baseList[0]) : baseList.slice();
    }

    /** @type {DyniUnitConditionItem[]} */
    const merged = [];
    baseList.forEach(function (base) {
      extraList.forEach(function (extra) {
        merged.push(Object.assign({}, base, extra));
      });
    });
    return merged.length === 1 ? /** @type {DyniEditableCondition} */ (merged[0]) : merged;
  }

  /** @param {DyniPerKindTextParameterDescriptor | undefined} kindDef @param {string} fallbackKind @returns {DyniEditableCondition} */
  function resolveKindCondition(kindDef, fallbackKind) {
    if (kindDef && Object.prototype.hasOwnProperty.call(kindDef, "kind")) {
      return makeKindCondition(kindDef.kind, fallbackKind);
    }
    return makeKindCondition(undefined, fallbackKind);
  }

  /** @param {DyniUnitFormatBinding} binding @param {string} metricKey @returns {DyniUnitFormatFamily} */
  function getFamily(binding, metricKey) {
    const familyId = binding && binding.family;
    const family = catalog.families[familyId];
    if (!family) {
      throw new Error("dyninstruments: missing unit family '" + familyId + "' for metric '" + metricKey + "'");
    }
    const defaultToken = binding.defaultToken;
    if (family.tokens.indexOf(defaultToken) === -1) {
      throw new Error("dyninstruments: invalid default token '" + defaultToken + "' for metric '" + metricKey + "'");
    }
    return family;
  }

  /** @param {string} metricKey @param {Readonly<Record<string, DyniUnitFormatBinding>> | undefined} bindings @returns {DyniUnitFormatBinding} */
  function getBinding(metricKey, bindings) {
    const source = bindings && typeof bindings === "object" ? bindings : catalog.metricBindings;
    const binding = source[metricKey] || catalog.metricBindings[metricKey];
    if (!binding) {
      throw new Error("dyninstruments: missing unit binding for metric '" + metricKey + "'");
    }
    return binding;
  }

  /** @param {DyniPerKindTextParameterMap} kindMap @returns {DyniEditableParameters} */
  function makePerKindCaptionParams(kindMap) {
    /** @type {DyniEditableParameters} */
    const out = {};
    Object.keys(kindMap || {}).forEach(function (metricKey) {
      const def = kindMap[metricKey] || {};
      out["caption_" + metricKey] = {
        type: "STRING",
        displayName: toText(def.captionName) || "Caption",
        default: typeof def.cap === "string" ? def.cap : "",
        condition: resolveKindCondition(def, metricKey)
      };
    });
    return out;
  }

  /** @param {string} metricKey @param {DyniUnitFormatBinding} binding @param {DyniPerKindTextParameterDescriptor | undefined} kindDef @returns {DyniEditableParameters} */
  function makeFormatUnitSelectParam(metricKey, binding, kindDef) {
    const family = getFamily(binding, metricKey);
    return {
      ["formatUnit_" + metricKey]: {
        type: "SELECT",
        list: family.selectorList,
        default: binding.defaultToken,
        displayName: "Formatter unit",
        condition: resolveKindCondition(kindDef, metricKey)
      }
    };
  }

  /** @param {string} metricKey @param {DyniUnitFormatBinding} binding @param {DyniPerKindTextParameterDescriptor | undefined} kindDef @returns {DyniEditableParameters} */
  function makePerUnitStringParams(metricKey, binding, kindDef) {
    const family = getFamily(binding, metricKey);
    /** @type {DyniEditableParameters} */
    const out = {};
    family.tokens.forEach(function (token) {
      const label = family.labels[token];
      out["unit_" + metricKey + "_" + token] = {
        type: "STRING",
        displayName: label + " unit",
        default: label,
        condition: mergeConditions(resolveKindCondition(kindDef, metricKey), {
          ["formatUnit_" + metricKey]: token
        })
      };
    });
    return out;
  }

  /** @param {DyniPerKindTextParameterMap} kindMap @param {Readonly<Record<string, DyniUnitFormatBinding>>} bindings @returns {DyniEditableParameters} */
  function makeUnitAwareTextParams(kindMap, bindings) {
    /** @type {DyniEditableParameters} */
    const out = {};
    Object.keys(kindMap || {}).forEach(function (metricKey) {
      const def = kindMap[metricKey] || {};
      const binding = getBinding(metricKey, bindings);
      Object.assign(out, makeFormatUnitSelectParam(metricKey, binding, def));
      Object.assign(out, makePerUnitStringParams(metricKey, binding, def));
    });
    return out;
  }

  /** @param {DyniUnitFloatFieldSpec | undefined} fieldSpec @param {string} token @returns {DyniUnitFloatTokenSpec} */
  function resolveFloatTokenSpec(fieldSpec, token) {
    const specDef = fieldSpec || {};
    const tokenSpecs = specDef.tokens || specDef.perToken || {};
    const spec = tokenSpecs[token];
    if (!spec || typeof spec !== "object") {
      const baseKey = toText(specDef.baseKey || specDef.key);
      throw new Error("dyninstruments: missing per-token float spec for '" + baseKey + "' token '" + token + "'");
    }
    return spec;
  }

  /** @param {string} metricKey @param {DyniUnitFormatBinding} binding @param {DyniPerKindTextParameterDescriptor | undefined} kindDef @param {DyniUnitFloatFieldSpec} fieldSpec @returns {DyniEditableParameters} */
  function makePerUnitFloatParams(metricKey, binding, kindDef, fieldSpec) {
    const family = getFamily(binding, metricKey);
    const specDef = fieldSpec || {};
    const baseKey = toText(specDef.baseKey || specDef.key);
    if (!baseKey) {
      throw new Error(
        "dyninstruments: makePerUnitFloatParams requires fieldSpec.baseKey for metric '" + metricKey + "'"
      );
    }

    const baseDisplayName = toText(specDef.displayName || specDef.name || baseKey);
    /** @type {DyniEditableParameters} */
    const out = {};

    family.tokens.forEach(function (token) {
      const tokenSpec = resolveFloatTokenSpec(specDef, token);
      const label = family.labels[token];
      const field = /** @type {DyniEditableParameterSpec} */ ({
        type: "FLOAT",
        min: tokenSpec.min,
        max: tokenSpec.max,
        step: tokenSpec.step,
        default: tokenSpec.default,
        displayName: baseDisplayName + " (" + label + ")",
        condition: mergeConditions(
          resolveKindCondition(kindDef, metricKey),
          mergeConditions(specDef.condition, {
            ["formatUnit_" + metricKey]: token
          })
        )
      });

      if (specDef.internal === true || tokenSpec.internal === true) {
        field.internal = true;
      }

      out[baseKey + "_" + token] = field;
    });

    return out;
  }

  shared.makePerKindCaptionParams = makePerKindCaptionParams;
  shared.makeUnitAwareTextParams = makeUnitAwareTextParams;
  shared.makeFormatUnitSelectParam = makeFormatUnitSelectParam;
  shared.makePerUnitStringParams = makePerUnitStringParams;
  shared.makePerUnitFloatParams = makePerUnitFloatParams;
})(this);

/**
 * @file DyniPlugin Common Editables - Shared ThreeValueTextWidget layout defaults
 * Documentation: documentation/widgets/three-elements.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const config = /** @type {DyniPluginConfig} */ (ns.config);
  const shared = /** @type {DyniPluginSharedConfig} */ (config.shared);

  shared.commonThreeElementsEditables = /** @type {DyniEditableParameters} */ ({
    ratioThresholdNormal: {
      type: "FLOAT",
      min: 0.5,
      max: 2.0,
      step: 0.05,
      default: 1.0,
      internal: true,
      name: "3-Rows Threshold (higher = flatter)"
    },
    ratioThresholdFlat: {
      type: "FLOAT",
      min: 1.5,
      max: 6.0,
      step: 0.05,
      default: 3.0,
      internal: true,
      name: "1-Row Threshold (higher = flatter)"
    },
    captionUnitScale: {
      type: "FLOAT",
      min: 0.5,
      max: 1.5,
      step: 0.05,
      default: 0.8,
      name: "Caption/Unit size"
    }
  });
})(this);

/**
 * @file DyniPlugin Environment Base Editables - Shared environment editable fragments
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  /** @typedef {DyniPluginSharedConfig & { kindMaps: Record<string, DyniPerKindTextParameterMap>, unitFormatFamilies: DyniUnitFormatCatalog, environmentDefaultDepthKey?: string, opt: (name: unknown, value: unknown) => DyniEditableOption, makePerKindCaptionParams: (map: DyniPerKindTextParameterMap) => DyniEditableParameters, makeUnitAwareTextParams: (map: DyniPerKindTextParameterMap, bindings: Readonly<Record<string, DyniUnitFormatBinding>>) => DyniEditableParameters }} DyniEnvironmentBaseShared */

  const ns = /** @type {DyniPluginNamespace} */ (/** @type {unknown} */ (root.DyniPlugin));
  const config = ns.config;
  const shared = /** @type {DyniEnvironmentBaseShared} */ (config.shared);
  const opt = shared.opt;
  const ENV_KIND = shared.kindMaps.ENV_KIND;
  const envBindings = shared.unitFormatFamilies.metricBindings;
  const DEFAULT_DEPTH_KEY = "nav.gps.depthBelowKeel";

  shared.environmentDefaultDepthKey = DEFAULT_DEPTH_KEY;

  /** @returns {DyniEditableParameters} */
  shared.buildEnvironmentBaseEditableParameters = function () {
    return {
      kind: {
        type: "SELECT",
        list: [
          opt("Depth", "depth"),
          opt("Depth gauge (linear)", "depthLinear"),
          opt("Depth gauge (radial)", "depthRadial"),
          opt("Temperature", "temp"),
          opt("Temperature gauge (linear)", "tempLinear"),
          opt("Temperature gauge (radial)", "tempRadial"),
          opt("Pressure (SignalK)", "pressure")
        ],
        default: "depth",
        name: "Instrument"
      },
      depthKey: {
        type: "KEY",
        default: DEFAULT_DEPTH_KEY,
        name: "Depth store path",
        condition: [{ kind: "depth" }, { kind: "depthLinear" }, { kind: "depthRadial" }]
      },
      // Temperature source (for BOTH numeric + radial); empty -> default waterTemp
      tempKey: {
        type: "KEY",
        default: "",
        name: "Temperature store path",
        condition: [{ kind: "temp" }, { kind: "tempLinear" }, { kind: "tempRadial" }]
      },

      // Pressure source (SignalK)
      value: {
        type: "KEY",
        default: "",
        name: "Pressure store path",
        condition: { kind: "pressure" }
      }
    };
  };

  /** @returns {DyniEditableParameters} */
  shared.buildEnvironmentModeEditableParameters = function () {
    return {
      easing: {
        type: "BOOLEAN",
        default: true,
        name: "Smooth motion",
        condition: [{ kind: "depthLinear" }, { kind: "depthRadial" }, { kind: "tempLinear" }, { kind: "tempRadial" }]
      },
      depthLinearHideTextualMetrics: {
        type: "BOOLEAN",
        default: false,
        name: "Hide textual metrics",
        condition: { kind: "depthLinear" }
      },
      depthRadialHideTextualMetrics: {
        type: "BOOLEAN",
        default: false,
        name: "Hide textual metrics",
        condition: { kind: "depthRadial" }
      },
      tempLinearHideTextualMetrics: {
        type: "BOOLEAN",
        default: false,
        name: "Hide textual metrics",
        condition: { kind: "tempLinear" }
      },
      tempRadialHideTextualMetrics: {
        type: "BOOLEAN",
        default: false,
        name: "Hide textual metrics",
        condition: { kind: "tempRadial" }
      }
    };
  };

  /** @returns {DyniEditableParameters} */
  shared.buildEnvironmentSharedScaleEditableParameters = function () {
    return {
      // Shared scale (numeric + radial)
      captionUnitScale: {
        type: "FLOAT",
        min: 0.5,
        max: 1.5,
        step: 0.05,
        default: 0.8,
        name: "Caption/Unit size"
      },
      stableDigits: {
        type: "BOOLEAN",
        default: false,
        name: "Stable digits",
        condition: [
          { kind: "depth" },
          { kind: "depthLinear" },
          { kind: "depthRadial" },
          { kind: "temp" },
          { kind: "tempLinear" },
          { kind: "tempRadial" },
          { kind: "pressure" }
        ]
      },

      caption: false,
      unit: false,
      formatter: false,
      formatterParameters: false,
      className: true
    };
  };

  /** @returns {DyniEditableParameters} */
  shared.buildEnvironmentPerKindEditableParameters = function () {
    return Object.assign(
      {},
      shared.makePerKindCaptionParams(ENV_KIND),
      shared.makeUnitAwareTextParams(ENV_KIND, envBindings)
    );
  };

  /** @returns {DyniEditableParameters} */
  shared.buildEnvironmentThresholdEditableParameters = function () {
    return {
      // ThreeValueTextWidget thresholds (numeric kinds)
      ratioThresholdNormal: {
        type: "FLOAT",
        min: 0.5,
        max: 2.0,
        step: 0.05,
        default: 1.0,
        internal: true,
        name: "3-Rows Threshold (numeric)",
        condition: [{ kind: "depth" }, { kind: "temp" }, { kind: "pressure" }]
      },
      ratioThresholdFlat: {
        type: "FLOAT",
        min: 1.5,
        max: 6.0,
        step: 0.05,
        default: 3.0,
        internal: true,
        name: "1-Row Threshold (numeric)",
        condition: [{ kind: "depth" }, { kind: "temp" }, { kind: "pressure" }]
      }
    };
  };
})(this);

/**
 * @file DyniPlugin Environment Depth Editables - Depth gauge editables
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  /** @typedef {{ baseKey: string, displayName: string, tokens: Record<string, { min: number, max: number, step: number, default: number }>, condition?: unknown }} DyniEnvironmentFloatSpec */
  /** @typedef {DyniPluginSharedConfig & { unitFormatFamilies: DyniUnitFormatCatalog, makePerUnitFloatParams: (metricKey: string, binding: DyniUnitFormatBinding, kindDef: DyniEditableCondition, fieldSpec: DyniEnvironmentFloatSpec) => DyniEditableParameters }} DyniEnvironmentDepthShared */

  const ns = /** @type {DyniPluginNamespace} */ (/** @type {unknown} */ (root.DyniPlugin));
  const shared = /** @type {DyniEnvironmentDepthShared} */ (ns.config.shared);
  const depthBindings = shared.unitFormatFamilies.metricBindings;
  const depthLinearBinding = depthBindings.depthLinear;
  const depthRadialBinding = depthBindings.depthRadial;
  const DEPTH_LINEAR_KIND = { kind: "depthLinear" };
  const DEPTH_RADIAL_KIND = { kind: "depthRadial" };
  /** @type {Record<string, { min: number, max: number, step: number }>} */
  const DEPTH_UNIT_RANGES = {
    nm: { min: 0, max: 0.016, step: 0.001 },
    m: { min: 0, max: 200, step: 0.5 },
    km: { min: 0, max: 0.03, step: 0.001 },
    ft: { min: 0, max: 600, step: 1 },
    yd: { min: 0, max: 200, step: 1 }
  };

  /** @param {Record<string, number>} defaults @returns {Record<string, { min: number, max: number, step: number, default: number }>} */
  function buildTokenSpecs(defaults) {
    /** @type {Record<string, { min: number, max: number, step: number, default: number }>} */
    const out = {};
    Object.keys(DEPTH_UNIT_RANGES).forEach(function (token) {
      out[token] = Object.assign({ default: defaults[token] }, DEPTH_UNIT_RANGES[token]);
    });
    return out;
  }

  /** @returns {DyniEditableParameters} */
  shared.buildEnvironmentDepthEditableParameters = function () {
    const linearMin = shared.makePerUnitFloatParams("depthLinear", depthLinearBinding, DEPTH_LINEAR_KIND, {
      baseKey: "depthLinearMinValue",
      displayName: "Min depth",
      tokens: buildTokenSpecs({
        nm: 0,
        m: 0,
        km: 0,
        ft: 0,
        yd: 0
      })
    });
    const linearMax = shared.makePerUnitFloatParams("depthLinear", depthLinearBinding, DEPTH_LINEAR_KIND, {
      baseKey: "depthLinearMaxValue",
      displayName: "Max depth",
      tokens: buildTokenSpecs({
        nm: 0.016,
        m: 30,
        km: 0.03,
        ft: 100,
        yd: 35
      })
    });
    const linearTickMajor = shared.makePerUnitFloatParams("depthLinear", depthLinearBinding, DEPTH_LINEAR_KIND, {
      baseKey: "depthLinearTickMajor",
      displayName: "Major tick step",
      tokens: buildTokenSpecs({
        nm: 0.002,
        m: 5,
        km: 0.005,
        ft: 20,
        yd: 5
      })
    });
    const linearTickMinor = shared.makePerUnitFloatParams("depthLinear", depthLinearBinding, DEPTH_LINEAR_KIND, {
      baseKey: "depthLinearTickMinor",
      displayName: "Minor tick step",
      tokens: buildTokenSpecs({
        nm: 0.0005,
        m: 1,
        km: 0.001,
        ft: 5,
        yd: 1
      })
    });
    const linearWarning = shared.makePerUnitFloatParams("depthLinear", depthLinearBinding, DEPTH_LINEAR_KIND, {
      baseKey: "depthLinearWarningFrom",
      displayName: "Warning at or below",
      tokens: buildTokenSpecs({
        nm: 0.003,
        m: 5,
        km: 0.005,
        ft: 16,
        yd: 5.5
      }),
      condition: { depthLinearWarningEnabled: true }
    });
    const linearAlarm = shared.makePerUnitFloatParams("depthLinear", depthLinearBinding, DEPTH_LINEAR_KIND, {
      baseKey: "depthLinearAlarmFrom",
      displayName: "Alarm at or below",
      tokens: buildTokenSpecs({
        nm: 0.001,
        m: 2,
        km: 0.002,
        ft: 6,
        yd: 2
      }),
      condition: { depthLinearAlarmEnabled: true }
    });
    const radialMin = shared.makePerUnitFloatParams("depthRadial", depthRadialBinding, DEPTH_RADIAL_KIND, {
      baseKey: "depthRadialMinValue",
      displayName: "Min depth",
      tokens: buildTokenSpecs({
        nm: 0,
        m: 0,
        km: 0,
        ft: 0,
        yd: 0
      })
    });
    const radialMax = shared.makePerUnitFloatParams("depthRadial", depthRadialBinding, DEPTH_RADIAL_KIND, {
      baseKey: "depthRadialMaxValue",
      displayName: "Max depth",
      tokens: buildTokenSpecs({
        nm: 0.016,
        m: 30,
        km: 0.03,
        ft: 100,
        yd: 35
      })
    });
    const radialTickMajor = shared.makePerUnitFloatParams("depthRadial", depthRadialBinding, DEPTH_RADIAL_KIND, {
      baseKey: "depthRadialTickMajor",
      displayName: "Major tick step",
      tokens: buildTokenSpecs({
        nm: 0.002,
        m: 5,
        km: 0.005,
        ft: 20,
        yd: 5
      })
    });
    const radialTickMinor = shared.makePerUnitFloatParams("depthRadial", depthRadialBinding, DEPTH_RADIAL_KIND, {
      baseKey: "depthRadialTickMinor",
      displayName: "Minor tick step",
      tokens: buildTokenSpecs({
        nm: 0.0005,
        m: 1,
        km: 0.001,
        ft: 5,
        yd: 1
      })
    });
    const radialWarning = shared.makePerUnitFloatParams("depthRadial", depthRadialBinding, DEPTH_RADIAL_KIND, {
      baseKey: "depthRadialWarningFrom",
      displayName: "Warning at or below",
      tokens: buildTokenSpecs({
        nm: 0.003,
        m: 5,
        km: 0.005,
        ft: 16,
        yd: 5.5
      }),
      condition: { depthRadialWarningEnabled: true }
    });
    const radialAlarm = shared.makePerUnitFloatParams("depthRadial", depthRadialBinding, DEPTH_RADIAL_KIND, {
      baseKey: "depthRadialAlarmFrom",
      displayName: "Alarm at or below",
      tokens: buildTokenSpecs({
        nm: 0.001,
        m: 2,
        km: 0.002,
        ft: 6,
        yd: 2
      }),
      condition: { depthRadialAlarmEnabled: true }
    });

    return {
      ...linearMin,
      ...linearMax,
      ...linearTickMajor,
      ...linearTickMinor,
      depthLinearShowEndLabels: {
        type: "BOOLEAN",
        default: false,
        name: "Show min/max labels",
        condition: { kind: "depthLinear" }
      },
      depthLinearWarningEnabled: {
        type: "BOOLEAN",
        default: true,
        name: "Show warning sector",
        condition: { kind: "depthLinear" }
      },
      depthLinearAlarmEnabled: {
        type: "BOOLEAN",
        default: true,
        name: "Show alarm sector",
        condition: { kind: "depthLinear" }
      },
      ...linearWarning,
      ...linearAlarm,
      depthLinearRatioThresholdNormal: {
        type: "FLOAT",
        min: 0.5,
        max: 2.0,
        step: 0.05,
        default: 1.1,
        internal: true,
        name: "DepthLinearWidget: Normal Threshold",
        condition: { kind: "depthLinear" }
      },
      depthLinearRatioThresholdFlat: {
        type: "FLOAT",
        min: 1.0,
        max: 6.0,
        step: 0.05,
        default: 3.5,
        internal: true,
        name: "DepthLinearWidget: Flat Threshold",
        condition: { kind: "depthLinear" }
      },
      ...radialMin,
      ...radialMax,
      ...radialTickMajor,
      ...radialTickMinor,
      depthRadialShowEndLabels: {
        type: "BOOLEAN",
        default: false,
        name: "Show min/max labels",
        condition: { kind: "depthRadial" }
      },
      depthRadialWarningEnabled: {
        type: "BOOLEAN",
        default: true,
        name: "Show warning sector",
        condition: { kind: "depthRadial" }
      },
      depthRadialAlarmEnabled: {
        type: "BOOLEAN",
        default: true,
        name: "Show alarm sector",
        condition: { kind: "depthRadial" }
      },
      ...radialWarning,
      ...radialAlarm,
      depthRadialRatioThresholdNormal: {
        type: "FLOAT",
        min: 0.5,
        max: 2.0,
        step: 0.05,
        default: 1.1,
        internal: true,
        name: "DepthRadialWidget: Normal Threshold",
        condition: { kind: "depthRadial" }
      },
      depthRadialRatioThresholdFlat: {
        type: "FLOAT",
        min: 1.0,
        max: 6.0,
        step: 0.05,
        default: 3.5,
        internal: true,
        name: "DepthRadialWidget: Flat Threshold",
        condition: { kind: "depthRadial" }
      }
    };
  };
})(this);

/**
 * @file DyniPlugin Environment Temperature Editables - Temperature gauge editables
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  /** @typedef {{ baseKey: string, displayName: string, tokens: Record<string, { min: number, max: number, step: number, default: number }>, condition?: unknown }} DyniEnvironmentTemperatureFloatSpec */
  /** @typedef {DyniPluginSharedConfig & { unitFormatFamilies: DyniUnitFormatCatalog, makePerUnitFloatParams: (metricKey: string, binding: DyniUnitFormatBinding, kindDef: DyniEditableCondition, fieldSpec: DyniEnvironmentTemperatureFloatSpec) => DyniEditableParameters }} DyniEnvironmentTemperatureShared */

  const ns = /** @type {DyniPluginNamespace} */ (/** @type {unknown} */ (root.DyniPlugin));
  const shared = /** @type {DyniEnvironmentTemperatureShared} */ (ns.config.shared);
  const tempBindings = shared.unitFormatFamilies.metricBindings;
  const tempLinearBinding = tempBindings.tempLinear;
  const tempRadialBinding = tempBindings.tempRadial;
  const TEMP_LINEAR_KIND = { kind: "tempLinear" };
  const TEMP_RADIAL_KIND = { kind: "tempRadial" };
  /** @type {Record<string, { min: number, max: number, step: number }>} */
  const TEMP_UNIT_RANGES = {
    celsius: { min: -50, max: 200, step: 0.5 },
    kelvin: { min: 223.15, max: 473.15, step: 0.5 }
  };

  /** @param {Record<string, number>} defaults @returns {Record<string, { min: number, max: number, step: number, default: number }>} */
  function buildTokenSpecs(defaults) {
    /** @type {Record<string, { min: number, max: number, step: number, default: number }>} */
    const out = {};
    Object.keys(TEMP_UNIT_RANGES).forEach(function (token) {
      out[token] = Object.assign({ default: defaults[token] }, TEMP_UNIT_RANGES[token]);
    });
    return out;
  }

  /** @returns {DyniEditableParameters} */
  shared.buildEnvironmentTemperatureEditableParameters = function () {
    const linearMin = shared.makePerUnitFloatParams("tempLinear", tempLinearBinding, TEMP_LINEAR_KIND, {
      baseKey: "tempLinearMinValue",
      displayName: "Min temp",
      tokens: buildTokenSpecs({
        celsius: 0,
        kelvin: 273.15
      })
    });
    const linearMax = shared.makePerUnitFloatParams("tempLinear", tempLinearBinding, TEMP_LINEAR_KIND, {
      baseKey: "tempLinearMaxValue",
      displayName: "Max temp",
      tokens: buildTokenSpecs({
        celsius: 35,
        kelvin: 308.15
      })
    });
    const linearTickMajor = shared.makePerUnitFloatParams("tempLinear", tempLinearBinding, TEMP_LINEAR_KIND, {
      baseKey: "tempLinearTickMajor",
      displayName: "Major tick step",
      tokens: buildTokenSpecs({
        celsius: 5,
        kelvin: 5
      })
    });
    const linearTickMinor = shared.makePerUnitFloatParams("tempLinear", tempLinearBinding, TEMP_LINEAR_KIND, {
      baseKey: "tempLinearTickMinor",
      displayName: "Minor tick step",
      tokens: buildTokenSpecs({
        celsius: 1,
        kelvin: 1
      })
    });
    const linearWarning = shared.makePerUnitFloatParams("tempLinear", tempLinearBinding, TEMP_LINEAR_KIND, {
      baseKey: "tempLinearWarningFrom",
      displayName: "Warning at or above",
      tokens: buildTokenSpecs({
        celsius: 28,
        kelvin: 301.15
      }),
      condition: { tempLinearWarningEnabled: true }
    });
    const linearAlarm = shared.makePerUnitFloatParams("tempLinear", tempLinearBinding, TEMP_LINEAR_KIND, {
      baseKey: "tempLinearAlarmFrom",
      displayName: "Alarm at or above",
      tokens: buildTokenSpecs({
        celsius: 32,
        kelvin: 305.15
      }),
      condition: { tempLinearAlarmEnabled: true }
    });
    const radialMin = shared.makePerUnitFloatParams("tempRadial", tempRadialBinding, TEMP_RADIAL_KIND, {
      baseKey: "tempRadialMinValue",
      displayName: "Min temp",
      tokens: buildTokenSpecs({
        celsius: 0,
        kelvin: 273.15
      })
    });
    const radialMax = shared.makePerUnitFloatParams("tempRadial", tempRadialBinding, TEMP_RADIAL_KIND, {
      baseKey: "tempRadialMaxValue",
      displayName: "Max temp",
      tokens: buildTokenSpecs({
        celsius: 35,
        kelvin: 308.15
      })
    });
    const radialTickMajor = shared.makePerUnitFloatParams("tempRadial", tempRadialBinding, TEMP_RADIAL_KIND, {
      baseKey: "tempRadialTickMajor",
      displayName: "Major tick step",
      tokens: buildTokenSpecs({
        celsius: 5,
        kelvin: 5
      })
    });
    const radialTickMinor = shared.makePerUnitFloatParams("tempRadial", tempRadialBinding, TEMP_RADIAL_KIND, {
      baseKey: "tempRadialTickMinor",
      displayName: "Minor tick step",
      tokens: buildTokenSpecs({
        celsius: 1,
        kelvin: 1
      })
    });
    const radialWarning = shared.makePerUnitFloatParams("tempRadial", tempRadialBinding, TEMP_RADIAL_KIND, {
      baseKey: "tempRadialWarningFrom",
      displayName: "Warning at or above",
      tokens: buildTokenSpecs({
        celsius: 28,
        kelvin: 301.15
      }),
      condition: { tempRadialWarningEnabled: true }
    });
    const radialAlarm = shared.makePerUnitFloatParams("tempRadial", tempRadialBinding, TEMP_RADIAL_KIND, {
      baseKey: "tempRadialAlarmFrom",
      displayName: "Alarm at or above",
      tokens: buildTokenSpecs({
        celsius: 32,
        kelvin: 305.15
      }),
      condition: { tempRadialAlarmEnabled: true }
    });

    return {
      ...linearMin,
      ...linearMax,
      ...linearTickMajor,
      ...linearTickMinor,
      tempLinearShowEndLabels: {
        type: "BOOLEAN",
        default: false,
        name: "Show min/max labels",
        condition: { kind: "tempLinear" }
      },
      tempLinearWarningEnabled: {
        type: "BOOLEAN",
        default: false,
        name: "Show warning sector",
        condition: { kind: "tempLinear" }
      },
      tempLinearAlarmEnabled: {
        type: "BOOLEAN",
        default: false,
        name: "Show alarm sector",
        condition: { kind: "tempLinear" }
      },
      ...linearWarning,
      ...linearAlarm,
      tempLinearRatioThresholdNormal: {
        type: "FLOAT",
        min: 0.5,
        max: 2.0,
        step: 0.05,
        default: 1.1,
        internal: true,
        name: "TempLinearWidget: Normal Threshold",
        condition: { kind: "tempLinear" }
      },
      tempLinearRatioThresholdFlat: {
        type: "FLOAT",
        min: 1.0,
        max: 6.0,
        step: 0.05,
        default: 3.5,
        internal: true,
        name: "TempLinearWidget: Flat Threshold",
        condition: { kind: "tempLinear" }
      },
      ...radialMin,
      ...radialMax,
      ...radialTickMajor,
      ...radialTickMinor,
      tempRadialShowEndLabels: {
        type: "BOOLEAN",
        default: false,
        name: "Show min/max labels",
        condition: { kind: "tempRadial" }
      },
      tempRadialWarningEnabled: {
        type: "BOOLEAN",
        default: false,
        name: "Show warning sector",
        condition: { kind: "tempRadial" }
      },
      tempRadialAlarmEnabled: {
        type: "BOOLEAN",
        default: false,
        name: "Show alarm sector",
        condition: { kind: "tempRadial" }
      },
      ...radialWarning,
      ...radialAlarm,
      tempRadialRatioThresholdNormal: {
        type: "FLOAT",
        min: 0.5,
        max: 2.0,
        step: 0.05,
        default: 1.1,
        internal: true,
        name: "TempGauge: Normal Threshold",
        condition: { kind: "tempRadial" }
      },
      tempRadialRatioThresholdFlat: {
        type: "FLOAT",
        min: 1.0,
        max: 6.0,
        step: 0.05,
        default: 3.5,
        internal: true,
        name: "TempGauge: Flat Threshold",
        condition: { kind: "tempRadial" }
      }
    };
  };
})(this);

/**
 * @file DyniPlugin Environment Cluster Editables - Shared editable parameter fragments
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const shared = /** @type {DyniPluginSharedConfig & DyniEnvironmentEditableBuilders} */ (ns.config.shared);

  /** @returns {DyniEditableParameters} */
  shared.buildEnvironmentEditableParameters = function () {
    const base = shared.buildEnvironmentBaseEditableParameters();
    const depth = shared.buildEnvironmentDepthEditableParameters();
    const mode = shared.buildEnvironmentModeEditableParameters();
    const temperature = shared.buildEnvironmentTemperatureEditableParameters();
    const sharedScale = shared.buildEnvironmentSharedScaleEditableParameters();
    const perKind = shared.buildEnvironmentPerKindEditableParameters();
    const thresholds = shared.buildEnvironmentThresholdEditableParameters();
    return Object.assign({}, base, depth, mode, temperature, sharedScale, perKind, thresholds);
  };
})(this);

/**
 * @file DyniPlugin Vessel Voltage Editables - Voltage gauge editable parameter fragments
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const shared = /** @type {DyniPluginSharedConfig} */ (ns.config.shared);

  /** @returns {DyniEditableParameters} */
  shared.buildVesselVoltageGaugeParams = function () {
    return /** @type {DyniEditableParameters} */ ({
      voltageLinearMinValue: {
        type: "FLOAT",
        min: 0,
        max: 60,
        step: 0.1,
        default: 7.0,
        name: "Min voltage",
        condition: { kind: "voltageLinear" }
      },
      voltageLinearMaxValue: {
        type: "FLOAT",
        min: 1,
        max: 80,
        step: 0.1,
        default: 15.0,
        name: "Max voltage",
        condition: { kind: "voltageLinear" }
      },
      voltageLinearTickMajor: {
        type: "FLOAT",
        min: 0.1,
        max: 20,
        step: 0.1,
        default: 1.0,
        name: "Major tick step",
        condition: { kind: "voltageLinear" }
      },
      voltageLinearTickMinor: {
        type: "FLOAT",
        min: 0.1,
        max: 10,
        step: 0.1,
        default: 0.2,
        name: "Minor tick step",
        condition: { kind: "voltageLinear" }
      },
      voltageLinearShowEndLabels: {
        type: "BOOLEAN",
        default: false,
        name: "Show min/max labels",
        condition: { kind: "voltageLinear" }
      },
      voltageRadialMinValue: {
        type: "FLOAT",
        min: 0,
        max: 60,
        step: 0.1,
        default: 7.0,
        name: "Min voltage",
        condition: { kind: "voltageRadial" }
      },
      voltageRadialMaxValue: {
        type: "FLOAT",
        min: 1,
        max: 80,
        step: 0.1,
        default: 15.0,
        name: "Max voltage",
        condition: { kind: "voltageRadial" }
      },
      voltageRadialTickMajor: {
        type: "FLOAT",
        min: 0.1,
        max: 20,
        step: 0.1,
        default: 1.0,
        name: "Major tick step",
        condition: { kind: "voltageRadial" }
      },
      voltageRadialTickMinor: {
        type: "FLOAT",
        min: 0.1,
        max: 10,
        step: 0.1,
        default: 0.2,
        name: "Minor tick step",
        condition: { kind: "voltageRadial" }
      },
      voltageRadialShowEndLabels: {
        type: "BOOLEAN",
        default: false,
        name: "Show min/max labels",
        condition: { kind: "voltageRadial" }
      },

      voltageLinearWarningEnabled: {
        type: "BOOLEAN",
        default: true,
        name: "Show warning sector",
        condition: { kind: "voltageLinear" }
      },
      voltageLinearAlarmEnabled: {
        type: "BOOLEAN",
        default: true,
        name: "Show alarm sector",
        condition: { kind: "voltageLinear" }
      },

      voltageLinearAlarmFrom: {
        type: "FLOAT",
        min: 0,
        max: 80,
        step: 0.1,
        default: 11.6,
        name: "Alarm at or below",
        condition: { kind: "voltageLinear", voltageLinearAlarmEnabled: true }
      },
      voltageLinearWarningFrom: {
        type: "FLOAT",
        min: 0,
        max: 80,
        step: 0.1,
        default: 12.2,
        name: "Warning at or below",
        condition: { kind: "voltageLinear", voltageLinearWarningEnabled: true }
      },

      voltageLinearRatioThresholdNormal: {
        type: "FLOAT",
        min: 0.5,
        max: 2.0,
        step: 0.05,
        default: 1.1,
        internal: true,
        name: "VoltageLinearWidget: Normal Threshold",
        condition: { kind: "voltageLinear" }
      },
      voltageLinearRatioThresholdFlat: {
        type: "FLOAT",
        min: 1.0,
        max: 6.0,
        step: 0.05,
        default: 3.5,
        internal: true,
        name: "VoltageLinearWidget: Flat Threshold",
        condition: { kind: "voltageLinear" }
      },

      // --- VoltageRadialWidget sector toggles and sectors ----------------
      voltageRadialWarningEnabled: {
        type: "BOOLEAN",
        default: true,
        name: "Show warning sector",
        condition: { kind: "voltageRadial" }
      },
      voltageRadialAlarmEnabled: {
        type: "BOOLEAN",
        default: true,
        name: "Show alarm sector",
        condition: { kind: "voltageRadial" }
      },

      // low-end sectors (DepthRadialWidget-Regeln)
      voltageRadialAlarmFrom: {
        type: "FLOAT",
        min: 0,
        max: 80,
        step: 0.1,
        default: 11.6,
        name: "Alarm at or below",
        condition: { kind: "voltageRadial", voltageRadialAlarmEnabled: true }
      },
      voltageRadialWarningFrom: {
        type: "FLOAT",
        min: 0,
        max: 80,
        step: 0.1,
        default: 12.2,
        name: "Warning at or below",
        condition: { kind: "voltageRadial", voltageRadialWarningEnabled: true }
      },

      voltageRadialRatioThresholdNormal: {
        type: "FLOAT",
        min: 0.5,
        max: 2.0,
        step: 0.05,
        default: 1.1,
        internal: true,
        name: "VoltageRadialWidget: Normal Threshold",
        condition: { kind: "voltageRadial" }
      },
      voltageRadialRatioThresholdFlat: {
        type: "FLOAT",
        min: 1.0,
        max: 6.0,
        step: 0.05,
        default: 3.5,
        internal: true,
        name: "VoltageRadialWidget: Flat Threshold",
        condition: { kind: "voltageRadial" }
      }
    });
  };
})(this);

/**
 * @file DyniPlugin CourseHeading Cluster - Course and heading widget config
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  /** @typedef {DyniPluginSharedConfig & { makePerKindTextParams: (map: DyniPerKindTextParameterMap) => DyniEditableParameters, opt: (name: unknown, value: unknown) => DyniEditableOption, kindMaps: Record<string, DyniPerKindTextParameterMap> }} DyniCourseHeadingSharedConfig */
  /** @typedef {{ DyniPlugin: DyniPluginNamespace & { config: DyniPluginConfig & { clusters: DyniWidgetDefinition[] } } }} DyniCourseHeadingRoot */

  const ns = /** @type {DyniCourseHeadingRoot} */ (/** @type {unknown} */ (root)).DyniPlugin;
  const config = ns.config;
  const shared = /** @type {DyniCourseHeadingSharedConfig} */ (config.shared);

  const makePerKindTextParams = shared.makePerKindTextParams;
  const opt = shared.opt;
  const COURSE_KIND = shared.kindMaps.COURSE_KIND;

  config.clusters.push({
    widget: "ClusterWidget",
    def: {
      name: "dyni_CourseHeading_Instruments",
      description: "Course & headings (COG/HDT/HDM/BRG) incl. radial and linear compass gauges",
      caption: "",
      unit: "",
      default: "---",
      cluster: "courseHeading",
      storeKeys: {
        cog: "nav.gps.course",
        hdt: "nav.gps.headingTrue",
        hdm: "nav.gps.headingMag",
        brg: "nav.wp.course"
      },
      editableParameters: {
        kind: {
          type: "SELECT",
          list: [
            opt("Course over ground (COG)", "cog"),
            opt("Heading — True (HDT)", "hdt"),
            opt("Heading — Magnetic (HDM)", "hdm"),
            opt("Bearing to waypoint (BRG)", "brg"),
            opt("Compass — True (HDT) [Radial]", "hdtRadial"),
            opt("Compass — Magnetic (HDM) [Radial]", "hdmRadial"),
            opt("Compass — True (HDT) [Linear]", "hdtLinear"),
            opt("Compass — Magnetic (HDM) [Linear]", "hdmLinear")
          ],
          default: "cog",
          name: "Instrument"
        },

        leadingZero: {
          type: "BOOLEAN",
          default: true,
          name: "Leading zero (e.g., 005°)"
        },

        // ThreeValueTextWidget thresholds — only for numeric kinds
        ratioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.0,
          internal: true,
          name: "3-Rows Threshold (numeric)",
          condition: [{ kind: "cog" }, { kind: "hdt" }, { kind: "hdm" }, { kind: "brg" }]
        },
        ratioThresholdFlat: {
          type: "FLOAT",
          min: 1.5,
          max: 6.0,
          step: 0.05,
          default: 3.0,
          internal: true,
          name: "1-Row Threshold (numeric)",
          condition: [{ kind: "cog" }, { kind: "hdt" }, { kind: "hdm" }, { kind: "brg" }]
        },

        // CompassRadialWidget thresholds — only for radial kinds
        compassRadialRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 0.8,
          internal: true,
          name: "Compass 2-Rows Threshold",
          condition: [{ kind: "hdtRadial" }, { kind: "hdmRadial" }]
        },
        compassRadialRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.0,
          max: 6.0,
          step: 0.05,
          default: 2.2,
          internal: true,
          name: "Compass 1-Row Threshold",
          condition: [{ kind: "hdtRadial" }, { kind: "hdmRadial" }]
        },

        // CompassLinearWidget settings — only for linear kinds
        compassLinearRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.1,
          internal: true,
          name: "CompassLinearWidget: Normal Threshold",
          condition: [{ kind: "hdtLinear" }, { kind: "hdmLinear" }]
        },
        compassLinearRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.0,
          max: 6.0,
          step: 0.05,
          default: 3.5,
          internal: true,
          name: "CompassLinearWidget: Flat Threshold",
          condition: [{ kind: "hdtLinear" }, { kind: "hdmLinear" }]
        },
        compassLinearTickMajor: {
          type: "FLOAT",
          min: 1,
          max: 180,
          step: 1,
          default: 30,
          name: "Major tick step",
          condition: [{ kind: "hdtLinear" }, { kind: "hdmLinear" }]
        },
        compassLinearTickMinor: {
          type: "FLOAT",
          min: 1,
          max: 180,
          step: 1,
          default: 10,
          name: "Minor tick step",
          condition: [{ kind: "hdtLinear" }, { kind: "hdmLinear" }]
        },
        compassLinearShowEndLabels: {
          type: "BOOLEAN",
          default: false,
          name: "Show min/max labels",
          condition: [{ kind: "hdtLinear" }, { kind: "hdmLinear" }]
        },
        compassLinearRange: {
          type: "SELECT",
          list: [
            { name: "360°", value: 360 },
            { name: "180°", value: 180 }
          ],
          default: 360,
          name: "Visible range",
          condition: [{ kind: "hdtLinear" }, { kind: "hdmLinear" }]
        },

        // Shared caption/unit-to-value scale applies to both numeric & radial
        captionUnitScale: {
          type: "FLOAT",
          min: 0.5,
          max: 1.5,
          step: 0.05,
          default: 0.8,
          name: "Caption/Unit size"
        },
        stableDigits: {
          type: "BOOLEAN",
          default: false,
          name: "Stable digits",
          condition: [
            { kind: "cog" },
            { kind: "hdt" },
            { kind: "hdm" },
            { kind: "brg" },
            { kind: "hdtRadial" },
            { kind: "hdmRadial" },
            { kind: "hdtLinear" },
            { kind: "hdmLinear" }
          ]
        },
        easing: {
          type: "BOOLEAN",
          default: true,
          name: "Smooth motion",
          condition: [{ kind: "hdtRadial" }, { kind: "hdmRadial" }, { kind: "hdtLinear" }, { kind: "hdmLinear" }]
        },
        compassRadialHideTextualMetrics: {
          type: "BOOLEAN",
          default: false,
          name: "Hide textual metrics",
          condition: [{ kind: "hdtRadial" }, { kind: "hdmRadial" }]
        },
        compassLinearHideTextualMetrics: {
          type: "BOOLEAN",
          default: false,
          name: "Hide textual metrics",
          condition: [{ kind: "hdtLinear" }, { kind: "hdmLinear" }]
        },

        // hide low-levels
        caption: false,
        unit: false,
        formatter: false,
        formatterParameters: false,
        className: true,

        ...makePerKindTextParams(COURSE_KIND)
      }
    }
  });
})(this);

/**
 * @file DyniPlugin Speed Cluster - Speed numeric and gauge widget config
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  /** @typedef {{ min: number, max: number, step: number }} DyniSpeedUnitRange */
  /** @typedef {DyniSpeedUnitRange & { default: number, label: string, internal?: boolean }} DyniSpeedTokenSpec */
  /** @typedef {{ condition?: Record<string, unknown>, internal?: boolean }} DyniSpeedFieldSpec */
  /** @typedef {DyniPluginSharedConfig & { makePerKindCaptionParams: (map: DyniPerKindTextParameterMap) => DyniEditableParameters, makeUnitAwareTextParams: (map: DyniPerKindTextParameterMap, bindings: Readonly<Record<string, DyniUnitFormatBinding>>) => DyniEditableParameters, opt: (name: unknown, value: unknown) => DyniEditableOption, kindMaps: Record<string, DyniPerKindTextParameterMap>, unitFormatFamilies: DyniUnitFormatCatalog }} DyniSpeedSharedConfig */
  /** @typedef {{ DyniPlugin: DyniPluginNamespace & { config: DyniPluginConfig & { clusters: DyniWidgetDefinition[] } } }} DyniSpeedRoot */

  const ns = /** @type {DyniSpeedRoot} */ (/** @type {unknown} */ (root)).DyniPlugin;
  const config = ns.config;
  const shared = /** @type {DyniSpeedSharedConfig} */ (config.shared);

  const makePerKindCaptionParams = shared.makePerKindCaptionParams;
  const makeUnitAwareTextParams = shared.makeUnitAwareTextParams;
  const opt = shared.opt;
  const SPEED_KIND = shared.kindMaps.SPEED_KIND;
  const speedBindings = shared.unitFormatFamilies.metricBindings;
  const SPEED_LINEAR_KIND_KEYS = ["sogLinear", "stwLinear"];
  const SPEED_RADIAL_KIND_KEYS = ["sogRadial", "stwRadial"];
  /** @type {Record<string, DyniSpeedUnitRange>} */
  const SPEED_UNIT_RANGES = {
    kn: { min: 0, max: 200, step: 0.5 },
    ms: { min: 0, max: 100, step: 0.1 },
    kmh: { min: 0, max: 400, step: 1 }
  };
  /** @type {Record<string, string>} */
  const SPEED_UNIT_LABELS = {
    kn: "kn",
    ms: "m/s",
    kmh: "km/h"
  };

  /** @param {Record<string, number>} defaults @returns {Record<string, DyniSpeedTokenSpec>} */
  function buildTokenSpecs(defaults) {
    /** @type {Record<string, DyniSpeedTokenSpec>} */
    const out = {};
    Object.keys(SPEED_UNIT_RANGES).forEach(function (token) {
      out[token] = Object.assign(
        {
          default: defaults[token],
          label: SPEED_UNIT_LABELS[token] || token
        },
        SPEED_UNIT_RANGES[token]
      );
    });
    return out;
  }

  /** @param {string[]} kindKeys @param {string} baseKey @param {string} displayName @param {Record<string, number>} defaults @param {DyniSpeedFieldSpec | undefined} [fieldSpec] @returns {DyniEditableParameters} */
  function buildPerUnitFloatParams(kindKeys, baseKey, displayName, defaults, fieldSpec) {
    const spec = fieldSpec && typeof fieldSpec === "object" ? fieldSpec : {};
    /** @type {DyniEditableParameters} */
    const out = {};
    const tokenSpecs = buildTokenSpecs(defaults);

    Object.keys(tokenSpecs).forEach(function (token) {
      const tokenSpec = tokenSpecs[token];
      /** @type {DyniEditableParameterSpec} */
      const field = {
        type: "FLOAT",
        min: tokenSpec.min,
        max: tokenSpec.max,
        step: tokenSpec.step,
        default: tokenSpec.default,
        displayName: displayName + " (" + tokenSpec.label + ")",
        condition: kindKeys.map(function (kindKey) {
          const condition = {
            kind: kindKey,
            ["formatUnit_" + kindKey]: token
          };
          if (spec.condition && typeof spec.condition === "object" && !Array.isArray(spec.condition)) {
            Object.assign(condition, spec.condition);
          }
          return condition;
        })
      };

      if (spec.internal === true || tokenSpec.internal === true) {
        field.internal = true;
      }

      out[baseKey + "_" + token] = field;
    });

    return out;
  }

  config.clusters.push({
    widget: "ClusterWidget",
    def: {
      name: "dyni_Speed_Instruments",
      description: "SOG/STW selection (numeric, linear, or SpeedRadialWidget radial)",
      caption: "",
      unit: "",
      default: "---",
      cluster: "speed",
      storeKeys: { sog: "nav.gps.speed", stw: "nav.gps.waterSpeed" },
      editableParameters: {
        kind: {
          type: "SELECT",
          list: [
            opt("Speed over ground (SOG)", "sog"),
            opt("Speed through water (STW)", "stw"),
            opt("SpeedLinearWidget — SOG [Linear]", "sogLinear"),
            opt("SpeedLinearWidget — STW [Linear]", "stwLinear"),
            opt("SpeedRadialWidget — SOG [Radial]", "sogRadial"),
            opt("SpeedRadialWidget — STW [Radial]", "stwRadial")
          ],
          default: "sog",
          name: "Instrument"
        },

        // ThreeValueTextWidget thresholds — only numeric kinds
        ratioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.0,
          internal: true,
          name: "3-Rows Threshold (numeric)",
          condition: [{ kind: "sog" }, { kind: "stw" }]
        },
        ratioThresholdFlat: {
          type: "FLOAT",
          min: 1.5,
          max: 6.0,
          step: 0.05,
          default: 3.0,
          internal: true,
          name: "1-Row Threshold (numeric)",
          condition: [{ kind: "sog" }, { kind: "stw" }]
        },

        // SpeedLinearWidget thresholds — only linear kinds
        speedLinearRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.1,
          internal: true,
          name: "SpeedLinearWidget: Normal Threshold",
          condition: [{ kind: "sogLinear" }, { kind: "stwLinear" }]
        },
        speedLinearRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.0,
          max: 6.0,
          step: 0.05,
          default: 3.5,
          internal: true,
          name: "SpeedLinearWidget: Flat Threshold",
          condition: [{ kind: "sogLinear" }, { kind: "stwLinear" }]
        },

        ...buildPerUnitFloatParams(SPEED_LINEAR_KIND_KEYS, "speedLinearMinValue", "Min speed", {
          kn: 0,
          ms: 0,
          kmh: 0
        }),
        ...buildPerUnitFloatParams(SPEED_LINEAR_KIND_KEYS, "speedLinearMaxValue", "Max speed", {
          kn: 30,
          ms: 15,
          kmh: 60
        }),
        ...buildPerUnitFloatParams(SPEED_LINEAR_KIND_KEYS, "speedLinearTickMajor", "Major tick step", {
          kn: 5,
          ms: 2.5,
          kmh: 10
        }),
        ...buildPerUnitFloatParams(SPEED_LINEAR_KIND_KEYS, "speedLinearTickMinor", "Minor tick step", {
          kn: 1,
          ms: 0.5,
          kmh: 2
        }),
        speedLinearShowEndLabels: {
          type: "BOOLEAN",
          default: false,
          name: "Show min/max labels",
          condition: [{ kind: "sogLinear" }, { kind: "stwLinear" }]
        },
        speedLinearWarningEnabled: {
          type: "BOOLEAN",
          default: true,
          name: "Show warning sector",
          condition: [{ kind: "sogLinear" }, { kind: "stwLinear" }]
        },
        speedLinearAlarmEnabled: {
          type: "BOOLEAN",
          default: true,
          name: "Show alarm sector",
          condition: [{ kind: "sogLinear" }, { kind: "stwLinear" }]
        },
        ...buildPerUnitFloatParams(
          SPEED_LINEAR_KIND_KEYS,
          "speedLinearWarningFrom",
          "Warning at or above",
          {
            kn: 20,
            ms: 10,
            kmh: 40
          },
          {
            condition: { speedLinearWarningEnabled: true }
          }
        ),
        ...buildPerUnitFloatParams(
          SPEED_LINEAR_KIND_KEYS,
          "speedLinearAlarmFrom",
          "Alarm at or above",
          {
            kn: 25,
            ms: 12.5,
            kmh: 50
          },
          {
            condition: { speedLinearAlarmEnabled: true }
          }
        ),

        // SpeedRadialWidget thresholds — only radial kinds
        speedRadialRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.1,
          internal: true,
          name: "SpeedRadialWidget: Normal Threshold",
          condition: [{ kind: "sogRadial" }, { kind: "stwRadial" }]
        },
        speedRadialRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.0,
          max: 6.0,
          step: 0.05,
          default: 3.5,
          internal: true,
          name: "SpeedRadialWidget: Flat Threshold",
          condition: [{ kind: "sogRadial" }, { kind: "stwRadial" }]
        },

        // SpeedRadialWidget range (arc is fixed in SpeedRadialWidget.js: 270..450)
        ...buildPerUnitFloatParams(SPEED_RADIAL_KIND_KEYS, "speedRadialMinValue", "Min speed", {
          kn: 0,
          ms: 0,
          kmh: 0
        }),
        ...buildPerUnitFloatParams(SPEED_RADIAL_KIND_KEYS, "speedRadialMaxValue", "Max speed", {
          kn: 30,
          ms: 15,
          kmh: 60
        }),

        // SpeedRadialWidget ticks (value-units)
        ...buildPerUnitFloatParams(SPEED_RADIAL_KIND_KEYS, "speedRadialTickMajor", "Major tick step", {
          kn: 5,
          ms: 2.5,
          kmh: 10
        }),
        ...buildPerUnitFloatParams(SPEED_RADIAL_KIND_KEYS, "speedRadialTickMinor", "Minor tick step", {
          kn: 1,
          ms: 0.5,
          kmh: 2
        }),
        speedRadialShowEndLabels: {
          type: "BOOLEAN",
          default: false,
          name: "Show min/max labels",
          condition: [{ kind: "sogRadial" }, { kind: "stwRadial" }]
        },

        // --- SpeedSectors toggles (default enabled) ----------------------------
        speedRadialWarningEnabled: {
          type: "BOOLEAN",
          default: true,
          name: "Show warning sector",
          condition: [{ kind: "sogRadial" }, { kind: "stwRadial" }]
        },
        speedRadialAlarmEnabled: {
          type: "BOOLEAN",
          default: true,
          name: "Show alarm sector",
          condition: [{ kind: "sogRadial" }, { kind: "stwRadial" }]
        },

        // SpeedRadialWidget sectors (only show when enabled)
        ...buildPerUnitFloatParams(
          SPEED_RADIAL_KIND_KEYS,
          "speedRadialWarningFrom",
          "Warning at or above",
          {
            kn: 20,
            ms: 10,
            kmh: 40
          },
          {
            condition: { speedRadialWarningEnabled: true }
          }
        ),
        ...buildPerUnitFloatParams(
          SPEED_RADIAL_KIND_KEYS,
          "speedRadialAlarmFrom",
          "Alarm at or above",
          {
            kn: 25,
            ms: 12.5,
            kmh: 50
          },
          {
            condition: { speedRadialAlarmEnabled: true }
          }
        ),

        // Shared caption/unit-to-value scale (used by SpeedRadialWidget + also fine for numeric)
        captionUnitScale: {
          type: "FLOAT",
          min: 0.5,
          max: 1.5,
          step: 0.05,
          default: 0.8,
          name: "Caption/Unit size"
        },
        stableDigits: {
          type: "BOOLEAN",
          default: false,
          name: "Stable digits",
          condition: [
            { kind: "sog" },
            { kind: "stw" },
            { kind: "sogLinear" },
            { kind: "stwLinear" },
            { kind: "sogRadial" },
            { kind: "stwRadial" }
          ]
        },
        easing: {
          type: "BOOLEAN",
          default: true,
          name: "Smooth motion",
          condition: [{ kind: "sogLinear" }, { kind: "stwLinear" }, { kind: "sogRadial" }, { kind: "stwRadial" }]
        },
        speedLinearHideTextualMetrics: {
          type: "BOOLEAN",
          default: false,
          name: "Hide textual metrics",
          condition: [{ kind: "sogLinear" }, { kind: "stwLinear" }]
        },
        speedRadialHideTextualMetrics: {
          type: "BOOLEAN",
          default: false,
          name: "Hide textual metrics",
          condition: [{ kind: "sogRadial" }, { kind: "stwRadial" }]
        },

        caption: false,
        unit: false,
        formatter: false,
        formatterParameters: false,
        className: true,

        ...makePerKindCaptionParams(SPEED_KIND),
        ...makeUnitAwareTextParams(SPEED_KIND, speedBindings)
      }
    }
  });
})(this);

/**
 * @file DyniPlugin Environment Cluster - Depth, temperature, and pressure config
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  /** @typedef {Record<string, unknown> & { kind?: unknown, value?: unknown, depthKey?: unknown, tempKey?: unknown, depth?: unknown, temp?: unknown, storeKeys?: Record<string, unknown> }} DyniEnvironmentValues */
  /** @typedef {DyniPluginSharedConfig & { environmentDefaultDepthKey: string, buildEnvironmentEditableParameters: () => DyniEditableParameters }} DyniEnvironmentSharedConfig */
  /** @typedef {{ DyniPlugin: DyniPluginNamespace & { config: DyniPluginConfig & { clusters: DyniWidgetDefinition[] } } }} DyniEnvironmentRoot */

  const ns = /** @type {DyniEnvironmentRoot} */ (/** @type {unknown} */ (root)).DyniPlugin;
  const config = ns.config;
  const shared = /** @type {DyniEnvironmentSharedConfig} */ (config.shared);
  const DEFAULT_DEPTH_KEY = shared.environmentDefaultDepthKey;
  const hasOwn = Object.prototype.hasOwnProperty;

  config.clusters.push({
    widget: "ClusterWidget",
    def: {
      name: "dyni_Environment_Instruments",
      description: "Depth, temperature, or SignalK pressure",
      caption: "",
      unit: "",
      default: "---",
      cluster: "environment",
      storeKeys: {
        depth: DEFAULT_DEPTH_KEY,
        temp: "nav.gps.waterTemp"
      },
      editableParameters: shared.buildEnvironmentEditableParameters(),
      /** @this {DyniEnvironmentValues} @param {DyniEnvironmentValues | null | undefined} values @returns {DyniEnvironmentValues} */
      updateFunction: function (values) {
        const out = /** @type {DyniEnvironmentValues} */ (values ? { ...values } : {});
        const source = /** @type {DyniEnvironmentValues} */ (this && typeof this === "object" ? this : {});
        const kind = (values && values.kind) || source.kind || "depth";

        if (!out.storeKeys) out.storeKeys = {};

        // pressure dynamic key
        if (kind === "pressure") {
          if (typeof out.value === "string" && out.value.trim()) {
            out.storeKeys = { ...out.storeKeys, value: out.value.trim() };
          } else if (Object.prototype.hasOwnProperty.call(out.storeKeys, "value")) {
            const sk = { ...out.storeKeys };
            delete sk.value;
            out.storeKeys = sk;
          }
        } else {
          if (Object.prototype.hasOwnProperty.call(out.storeKeys, "value")) {
            const sk = { ...out.storeKeys };
            delete sk.value;
            out.storeKeys = sk;
          }
        }

        if (kind === "depth" || kind === "depthLinear" || kind === "depthRadial") {
          if (hasOwn.call(out, "depthKey")) {
            out.depth = out.depthKey;
          }

          if (typeof out.depthKey === "string" && out.depthKey.trim()) {
            out.storeKeys = { ...out.storeKeys, depth: out.depthKey.trim() };
          } else {
            out.storeKeys = { ...out.storeKeys, depth: DEFAULT_DEPTH_KEY };
          }
        }

        // temperature dynamic key (for selecting different temperature sources)
        if (kind === "temp" || kind === "tempLinear" || kind === "tempRadial") {
          if (hasOwn.call(out, "tempKey")) {
            out.temp = out.tempKey;
          }

          if (typeof out.tempKey === "string" && out.tempKey.trim()) {
            out.storeKeys = { ...out.storeKeys, temp: out.tempKey.trim() };
          } else {
            out.storeKeys = { ...out.storeKeys, temp: "nav.gps.waterTemp" };
          }
        }

        return out;
      }
    }
  });
})(this);

/**
 * @file DyniPlugin Wind Cluster - Wind numeric and dial widget config
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  /** @typedef {DyniPluginSharedConfig & { makePerKindCaptionParams: (map: DyniPerKindTextParameterMap) => DyniEditableParameters, makePerKindTextParams: (map: DyniPerKindTextParameterMap) => DyniEditableParameters, makeUnitAwareTextParams: (map: DyniPerKindTextParameterMap, bindings: Readonly<Record<string, DyniUnitFormatBinding>>) => DyniEditableParameters, opt: (name: unknown, value: unknown) => DyniEditableOption, kindMaps: Record<string, DyniPerKindTextParameterMap>, unitFormatFamilies: DyniUnitFormatCatalog }} DyniWindSharedConfig */
  /** @typedef {{ DyniPlugin: DyniPluginNamespace & { config: DyniPluginConfig & { clusters: DyniWidgetDefinition[] } } }} DyniWindRoot */

  const ns = /** @type {DyniWindRoot} */ (/** @type {unknown} */ (root)).DyniPlugin;
  const config = ns.config;
  const shared = /** @type {DyniWindSharedConfig} */ (config.shared);

  const makePerKindCaptionParams = shared.makePerKindCaptionParams;
  const makePerKindTextParams = shared.makePerKindTextParams;
  const makeUnitAwareTextParams = shared.makeUnitAwareTextParams;
  const opt = shared.opt;
  const WIND_ANGLE_KIND = shared.kindMaps.WIND_ANGLE_KIND;
  const WIND_SPEED_KIND = shared.kindMaps.WIND_SPEED_KIND;
  const windBindings = shared.unitFormatFamilies.metricBindings;

  config.clusters.push({
    widget: "ClusterWidget",
    def: {
      name: "dyni_Wind_Instruments",
      description: "Wind (angle/speed numbers, radial dials, or linear dual gauges)",
      caption: "",
      unit: "",
      default: "---",
      cluster: "wind",
      storeKeys: {
        awa: "nav.gps.windAngle",
        twa: "nav.gps.trueWindAngle",
        twd: "nav.gps.trueWindDirection",
        aws: "nav.gps.windSpeed",
        tws: "nav.gps.trueWindSpeed"
      },
      editableParameters: {
        kind: {
          type: "SELECT",
          list: [
            opt("Angle — True (TWA)", "angleTrue"),
            opt("Angle — Apparent (AWA)", "angleApparent"),
            opt("Angle — True direction (TWD)", "angleTrueDirection"),
            opt("Speed — True (TWS)", "speedTrue"),
            opt("Speed — Apparent (AWS)", "speedApparent"),
            opt("Dial — True wind (TWA/TWS)", "angleTrueRadial"),
            opt("Dial — Apparent wind (AWA/AWS)", "angleApparentRadial"),
            opt("Linear — True wind (TWA/TWS)", "angleTrueLinear"),
            opt("Linear — Apparent wind (AWA/AWS)", "angleApparentLinear")
          ],
          default: "angleTrue",
          name: "Instrument"
        },

        leadingZero: {
          type: "BOOLEAN",
          default: true,
          name: "Leading zero for angles (e.g., 005)",
          condition: [
            { kind: "angleTrue" },
            { kind: "angleApparent" },
            { kind: "angleTrueDirection" },
            { kind: "angleTrueRadial" },
            { kind: "angleApparentRadial" },
            { kind: "angleTrueLinear" },
            { kind: "angleApparentLinear" }
          ]
        },

        // WindRadialWidget-only row thresholds
        windRadialRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 0.7,
          internal: true,
          name: "Dial 3-Rows Threshold",
          condition: [{ kind: "angleTrueRadial" }, { kind: "angleApparentRadial" }]
        },
        windRadialRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.0,
          max: 6.0,
          step: 0.05,
          default: 2.0,
          internal: true,
          name: "Dial 1-Row Threshold",
          condition: [{ kind: "angleTrueRadial" }, { kind: "angleApparentRadial" }]
        },

        // WindLinearWidget-only row thresholds
        windLinearRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 0.9,
          internal: true,
          name: "Linear split threshold",
          condition: [{ kind: "angleTrueLinear" }, { kind: "angleApparentLinear" }]
        },
        windLinearRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.0,
          max: 6.0,
          step: 0.05,
          default: 3,
          internal: true,
          name: "Linear flat threshold",
          condition: [{ kind: "angleTrueLinear" }, { kind: "angleApparentLinear" }]
        },
        windLinearTickMajor: {
          type: "FLOAT",
          min: 1,
          max: 180,
          step: 1,
          default: 30,
          name: "Major tick step",
          condition: [{ kind: "angleTrueLinear" }, { kind: "angleApparentLinear" }]
        },
        windLinearTickMinor: {
          type: "FLOAT",
          min: 1,
          max: 90,
          step: 1,
          default: 10,
          name: "Minor tick step",
          condition: [{ kind: "angleTrueLinear" }, { kind: "angleApparentLinear" }]
        },
        windLinearShowEndLabels: {
          type: "BOOLEAN",
          default: false,
          name: "Show min/max labels",
          condition: [{ kind: "angleTrueLinear" }, { kind: "angleApparentLinear" }]
        },

        // ThreeValueTextWidget thresholds — only for numeric kinds
        ratioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.0,
          internal: true,
          name: "3-Rows Threshold (numeric)",
          condition: [
            { kind: "angleTrue" },
            { kind: "angleApparent" },
            { kind: "angleTrueDirection" },
            { kind: "speedTrue" },
            { kind: "speedApparent" }
          ]
        },
        ratioThresholdFlat: {
          type: "FLOAT",
          min: 1.5,
          max: 6.0,
          step: 0.05,
          default: 3.0,
          internal: true,
          name: "1-Row Threshold (numeric)",
          condition: [
            { kind: "angleTrue" },
            { kind: "angleApparent" },
            { kind: "angleTrueDirection" },
            { kind: "speedTrue" },
            { kind: "speedApparent" }
          ]
        },

        // Symmetric layline range
        windRadialLayEnabled: {
          type: "BOOLEAN",
          default: true,
          name: "Layline sectors enabled",
          condition: [{ kind: "angleTrueRadial" }, { kind: "angleApparentRadial" }]
        },
        windRadialLayMin: {
          type: "FLOAT",
          min: 0,
          max: 180,
          step: 1,
          default: 25,
          name: "Min layline angle",
          condition: [
            { kind: "angleTrueRadial", windRadialLayEnabled: true },
            { kind: "angleApparentRadial", windRadialLayEnabled: true }
          ]
        },
        windRadialLayMax: {
          type: "FLOAT",
          min: 0,
          max: 180,
          step: 1,
          default: 45,
          name: "Max layline angle",
          condition: [
            { kind: "angleTrueRadial", windRadialLayEnabled: true },
            { kind: "angleApparentRadial", windRadialLayEnabled: true }
          ]
        },
        windLinearLayEnabled: {
          type: "BOOLEAN",
          default: true,
          name: "Layline sectors enabled",
          condition: [{ kind: "angleTrueLinear" }, { kind: "angleApparentLinear" }]
        },
        windLinearLayMin: {
          type: "FLOAT",
          min: 0,
          max: 180,
          step: 1,
          default: 25,
          name: "Min layline angle",
          condition: [
            { kind: "angleTrueLinear", windLinearLayEnabled: true },
            { kind: "angleApparentLinear", windLinearLayEnabled: true }
          ]
        },
        windLinearLayMax: {
          type: "FLOAT",
          min: 0,
          max: 180,
          step: 1,
          default: 45,
          name: "Max layline angle",
          condition: [
            { kind: "angleTrueLinear", windLinearLayEnabled: true },
            { kind: "angleApparentLinear", windLinearLayEnabled: true }
          ]
        },

        // Shared caption/unit-to-value scale applies to numeric, radial, and linear
        captionUnitScale: {
          type: "FLOAT",
          min: 0.5,
          max: 1.5,
          step: 0.05,
          default: 0.8,
          name: "Caption/Unit size"
        },
        stableDigits: {
          type: "BOOLEAN",
          default: false,
          name: "Stable digits",
          condition: [
            { kind: "angleTrue" },
            { kind: "angleApparent" },
            { kind: "angleTrueDirection" },
            { kind: "speedTrue" },
            { kind: "speedApparent" },
            { kind: "angleTrueRadial" },
            { kind: "angleApparentRadial" },
            { kind: "angleTrueLinear" },
            { kind: "angleApparentLinear" }
          ]
        },
        easing: {
          type: "BOOLEAN",
          default: true,
          name: "Smooth motion",
          condition: [
            { kind: "angleTrueRadial" },
            { kind: "angleApparentRadial" },
            { kind: "angleTrueLinear" },
            { kind: "angleApparentLinear" }
          ]
        },
        windRadialHideTextualMetrics: {
          type: "BOOLEAN",
          default: false,
          name: "Hide textual metrics",
          condition: [{ kind: "angleTrueRadial" }, { kind: "angleApparentRadial" }]
        },
        windLinearHideTextualMetrics: {
          type: "BOOLEAN",
          default: false,
          name: "Hide textual metrics",
          condition: [{ kind: "angleTrueLinear" }, { kind: "angleApparentLinear" }]
        },

        caption: false,
        unit: false,
        formatter: false,
        formatterParameters: false,
        className: true,

        ...makePerKindCaptionParams(WIND_SPEED_KIND),
        ...makeUnitAwareTextParams(WIND_SPEED_KIND, windBindings),
        ...makePerKindTextParams(WIND_ANGLE_KIND)
      }
    }
  });
})(this);

/**
 * @file DyniPlugin Nav Cluster Ratio Thresholds - shared 3-rows/1-row layout threshold fragment
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  /** @typedef {DyniPluginSharedConfig & { buildNavRatioThresholdEditableParameters?: () => DyniEditableParameters }} DyniNavRatioThresholdShared */

  const ns = /** @type {DyniPluginNamespace} */ (/** @type {unknown} */ (root.DyniPlugin));
  const config = ns.config;
  const shared = /** @type {DyniNavRatioThresholdShared} */ (config.shared);

  /** @returns {DyniEditableParameters} */
  shared.buildNavRatioThresholdEditableParameters = function () {
    return {
      xteRatioThresholdNormal: {
        type: "FLOAT",
        min: 0.5,
        max: 2.0,
        step: 0.05,
        default: 0.85,
        internal: true,
        name: "XTE 3-Rows Threshold",
        condition: { kind: "xteDisplay" }
      },
      xteRatioThresholdFlat: {
        type: "FLOAT",
        min: 1.0,
        max: 6.0,
        step: 0.05,
        default: 2.3,
        internal: true,
        name: "XTE 1-Row Threshold",
        condition: { kind: "xteDisplay" }
      },
      xteLinearRatioThresholdNormal: {
        type: "FLOAT",
        min: 0.5,
        max: 2.0,
        step: 0.05,
        default: 0.85,
        internal: true,
        name: "XTE Linear 3-Rows Threshold",
        condition: { kind: "xteDisplayLinear" }
      },
      xteLinearRatioThresholdFlat: {
        type: "FLOAT",
        min: 1.0,
        max: 6.0,
        step: 0.05,
        default: 2.3,
        internal: true,
        name: "XTE Linear 1-Row Threshold",
        condition: { kind: "xteDisplayLinear" }
      },
      activeRouteRatioThresholdNormal: {
        type: "FLOAT",
        min: 0.5,
        max: 2.0,
        step: 0.05,
        default: 1.2,
        internal: true,
        name: "ActiveRoute: 3-Rows Threshold",
        condition: { kind: "activeRoute" }
      },
      activeRouteRatioThresholdFlat: {
        type: "FLOAT",
        min: 1.5,
        max: 6.0,
        step: 0.05,
        default: 3.8,
        internal: true,
        name: "ActiveRoute: 1-Row Threshold",
        condition: { kind: "activeRoute" }
      },
      editRouteRatioThresholdNormal: {
        type: "FLOAT",
        min: 0.5,
        max: 2.0,
        step: 0.05,
        default: 1.2,
        internal: true,
        name: "EditRoute: 3-Rows Threshold",
        condition: { kind: "editRoute" }
      },
      editRouteRatioThresholdFlat: {
        type: "FLOAT",
        min: 1.5,
        max: 6.0,
        step: 0.05,
        default: 3.8,
        internal: true,
        name: "EditRoute: 1-Row Threshold",
        condition: { kind: "editRoute" }
      }
    };
  };
})(this);

/**
 * @file DyniPlugin Nav Cluster - Canonical navigation widget config (ETA, distances, positions, route points)
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  const ns = /** @type {DyniNavClusterRoot} */ (/** @type {unknown} */ (root)).DyniPlugin;
  const config = ns.config;
  const shared = config.shared;

  const makePerKindCaptionParams = shared.makePerKindCaptionParams;
  const makePerKindTextParams = shared.makePerKindTextParams;
  const makeUnitAwareTextParams = shared.makeUnitAwareTextParams;
  const makeFormatUnitSelectParam = shared.makeFormatUnitSelectParam;
  const makePerUnitStringParams = shared.makePerUnitStringParams;
  const opt = shared.opt;
  const NAV_TEXT_KIND = shared.kindMaps.NAV_TEXT_KIND;
  const NAV_UNIT_AWARE_KIND = shared.kindMaps.NAV_UNIT_AWARE_KIND;
  const commonThreeElementsEditables = shared.commonThreeElementsEditables;
  const navBindings = shared.unitFormatFamilies.metricBindings;
  const NAV_TEXT_KIND_CONDITION = [
    { kind: "wpEta" },
    { kind: "rteEta" },
    { kind: "dst" },
    { kind: "rteDistance" },
    { kind: "vmg" },
    { kind: "positionBoat" },
    { kind: "positionWp" }
  ];
  const XTE_DISPLAY_SCALE_FIELDS = /** @type {Record<string, DyniXteScaleFieldSpec>} */ ({
    nm: { default: 1, min: 0, max: 20, step: 0.1 },
    m: { default: 1852, min: 0, max: 20000, step: 10 },
    km: { default: 1.852, min: 0, max: 20, step: 0.01 },
    ft: { default: 6076, min: 0, max: 40000, step: 10 },
    yd: { default: 2025, min: 0, max: 40000, step: 1 }
  });
  const XTE_LINEAR_SCALE_FIELDS = /** @type {Record<string, DyniXteScaleFieldSpec>} */ ({
    nm: { default: 1, min: 0, max: 20, step: 0.1 },
    m: { default: 1852, min: 0, max: 20000, step: 10 },
    km: { default: 1.852, min: 0, max: 20, step: 0.01 },
    ft: { default: 6076, min: 0, max: 40000, step: 10 },
    yd: { default: 2025, min: 0, max: 40000, step: 1 }
  });

  function makeXteDisplayScaleParams() {
    const out = /** @type {DyniEditableParameters} */ ({});
    Object.keys(XTE_DISPLAY_SCALE_FIELDS).forEach(function (token) {
      const spec = XTE_DISPLAY_SCALE_FIELDS[token];
      out["xteDisplayScale_" + token] = {
        type: "FLOAT",
        min: spec.min,
        max: spec.max,
        step: spec.step,
        default: spec.default,
        name: "XTE highway scale",
        condition: {
          kind: "xteDisplay",
          formatUnit_xteDisplayXte: token
        }
      };
    });
    return out;
  }

  function makeXteLinearScaleParams() {
    const out = /** @type {DyniEditableParameters} */ ({});
    Object.keys(XTE_LINEAR_SCALE_FIELDS).forEach(function (token) {
      const spec = XTE_LINEAR_SCALE_FIELDS[token];
      out["xteLinearScale_" + token] = {
        type: "FLOAT",
        min: spec.min,
        max: spec.max,
        step: spec.step,
        default: spec.default,
        name: "XTE linear scale",
        condition: {
          kind: "xteDisplayLinear",
          formatUnit_xteDisplayLinearXte: token
        }
      };
    });
    return out;
  }

  config.clusters.push({
    widget: "ClusterWidget",
    def: {
      name: "dyni_Nav_Instruments",
      description:
        "Navigation values (ETA / Route ETA / DST / Route distance / VMG / Active route / Edit route / Route points / Positions / XTE display / XTE linear gauge)",
      caption: "",
      unit: "",
      default: "---",
      cluster: "nav",
      storeKeys: {
        wpEta: "nav.wp.eta",
        rteEta: "nav.route.eta",
        dst: "nav.wp.distance",
        dtw: "nav.wp.distance",
        xte: "nav.wp.xte",
        cog: "nav.gps.course",
        btw: "nav.wp.course",
        wpName: "nav.wp.name",
        wpServer: "nav.wp.server",
        activeRouteName: "nav.route.name",
        activeRouteRemain: "nav.route.remain",
        activeRouteEta: "nav.route.eta",
        activeRouteNextCourse: "nav.route.nextCourse",
        activeRouteApproaching: "nav.route.isApproaching",
        editingRoute: "nav.routeHandler.editingRoute",
        editingIndex: "nav.routeHandler.editingIndex",
        activeName: "nav.routeHandler.activeName",
        useRhumbLine: "nav.routeHandler.useRhumbLine",
        routeShowLL: "properties.routeShowLL",
        rteDistance: "nav.route.remain",
        vmg: "nav.wp.vmg",
        positionBoat: "nav.gps.position",
        positionWp: "nav.wp.position"
      },
      editableParameters: {
        kind: {
          type: "SELECT",
          list: [
            opt("WP ETA to waypoint", "wpEta"),
            opt("ETA for route", "rteEta"),
            opt("Distance to waypoint (DST)", "dst"),
            opt("Remaining route distance", "rteDistance"),
            opt("VMG to waypoint", "vmg"),
            opt("Active route", "activeRoute"),
            opt("Edit route", "editRoute"),
            opt("Route points list", "routePoints"),
            opt("Boat position (GPS)", "positionBoat"),
            opt("Active waypoint position", "positionWp"),
            opt("XTE highway display", "xteDisplay"),
            opt("XTE linear gauge", "xteDisplayLinear")
          ],
          default: "wpEta",
          name: "Instrument"
        },
        leadingZero: {
          type: "BOOLEAN",
          default: true,
          name: "Leading zero for headings (e.g., 005)",
          condition: { kind: "xteDisplay" }
        },
        xteLinearLeadingZero: {
          type: "BOOLEAN",
          default: true,
          name: "Leading zero for headings",
          condition: { kind: "xteDisplayLinear" }
        },
        ...shared.buildNavRatioThresholdEditableParameters(),
        caption_editRoutePts: {
          type: "STRING",
          default: "PTS",
          name: "PTS caption",
          condition: { kind: "editRoute" }
        },
        caption_editRouteDst: {
          type: "STRING",
          default: "DST",
          name: "DST caption",
          condition: { kind: "editRoute" }
        },
        ...makeFormatUnitSelectParam("editRouteDst", navBindings.editRouteDst, { kind: "editRoute" }),
        ...makePerUnitStringParams("editRouteDst", navBindings.editRouteDst, { kind: "editRoute" }),
        caption_editRouteRte: {
          type: "STRING",
          default: "RTE",
          name: "RTE caption",
          condition: { kind: "editRoute" }
        },
        ...makeFormatUnitSelectParam("editRouteRte", navBindings.editRouteRte, { kind: "editRoute" }),
        ...makePerUnitStringParams("editRouteRte", navBindings.editRouteRte, { kind: "editRoute" }),
        caption_editRouteEta: {
          type: "STRING",
          default: "RTE ETA",
          name: "RTE ETA caption",
          condition: { kind: "editRoute" }
        },
        routePointsRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.0,
          internal: true,
          name: "RoutePoints: 3-Rows Threshold",
          condition: { kind: "routePoints" }
        },
        routePointsRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.5,
          max: 6.0,
          step: 0.05,
          default: 3.5,
          internal: true,
          name: "RoutePoints: 1-Row Threshold",
          condition: { kind: "routePoints" }
        },
        showHeader: {
          type: "BOOLEAN",
          default: true,
          name: "Show header",
          condition: { kind: "routePoints" }
        },
        ...makeFormatUnitSelectParam("routePointsDistance", navBindings.routePointsDistance, { kind: "routePoints" }),
        ...makePerUnitStringParams("routePointsDistance", navBindings.routePointsDistance, { kind: "routePoints" }),
        courseUnit: {
          type: "STRING",
          default: "°",
          name: "Course unit",
          condition: { kind: "routePoints" }
        },
        waypointsText: {
          type: "STRING",
          default: "waypoints",
          name: "Waypoints label",
          condition: { kind: "routePoints" }
        },
        showWpNameXteDisplay: {
          type: "BOOLEAN",
          default: false,
          name: "Show waypoint name",
          condition: { kind: "xteDisplay" }
        },
        xteLinearShowWpName: {
          type: "BOOLEAN",
          default: false,
          name: "Show waypoint name",
          condition: { kind: "xteDisplayLinear" }
        },
        coordinatesTabular: {
          type: "BOOLEAN",
          default: true,
          name: "Tabular coordinates",
          condition: [{ kind: "routePoints" }, { kind: "positionBoat" }, { kind: "positionWp" }]
        },
        stableDigits: {
          type: "BOOLEAN",
          default: false,
          name: "Stable digits",
          condition: [
            { kind: "wpEta" },
            { kind: "rteEta" },
            { kind: "dst" },
            { kind: "rteDistance" },
            { kind: "vmg" },
            { kind: "xteDisplay" },
            { kind: "xteDisplayLinear" },
            { kind: "activeRoute" },
            { kind: "editRoute" },
            { kind: "routePoints" }
          ]
        },
        easing: {
          type: "BOOLEAN",
          default: true,
          name: "Smooth motion",
          condition: { kind: "xteDisplay" }
        },
        xteLinearEasing: {
          type: "BOOLEAN",
          default: true,
          name: "Smooth motion",
          condition: { kind: "xteDisplayLinear" }
        },
        xteHideTextualMetrics: {
          type: "BOOLEAN",
          default: false,
          name: "Hide textual metrics",
          condition: { kind: "xteDisplay" }
        },
        xteLinearHideTextualMetrics: {
          type: "BOOLEAN",
          default: false,
          name: "Hide textual metrics",
          condition: { kind: "xteDisplayLinear" }
        },
        xteLinearTickMajor: {
          type: "FLOAT",
          min: 0.1,
          max: 20,
          step: 0.1,
          default: 1.0,
          internal: true,
          name: "Major tick step",
          condition: { kind: "xteDisplayLinear" }
        },
        xteLinearTickMinor: {
          type: "FLOAT",
          min: 0.05,
          max: 10,
          step: 0.05,
          default: 0.25,
          internal: true,
          name: "Minor tick step",
          condition: { kind: "xteDisplayLinear" }
        },
        xteLinearShowEndLabels: {
          type: "BOOLEAN",
          default: true,
          name: "Show min/max labels",
          condition: { kind: "xteDisplayLinear" }
        },
        ...makeXteDisplayScaleParams(),
        ...makeXteLinearScaleParams(),
        hideSeconds: {
          type: "BOOLEAN",
          default: false,
          name: "Hide seconds",
          condition: [{ kind: "wpEta" }, { kind: "rteEta" }, { kind: "activeRoute" }, { kind: "editRoute" }]
        },
        caption: false,
        unit: false,
        formatter: false,
        formatterParameters: false,
        className: true,
        ...makePerKindCaptionParams(NAV_UNIT_AWARE_KIND),
        ...makeUnitAwareTextParams(NAV_UNIT_AWARE_KIND, navBindings),
        ...makePerKindTextParams(NAV_TEXT_KIND),
        ratioThresholdNormal: {
          .../** @type {DyniEditableParameterSpec} */ (commonThreeElementsEditables.ratioThresholdNormal),
          internal: true,
          condition: NAV_TEXT_KIND_CONDITION
        },
        ratioThresholdFlat: {
          .../** @type {DyniEditableParameterSpec} */ (commonThreeElementsEditables.ratioThresholdFlat),
          internal: true,
          condition: NAV_TEXT_KIND_CONDITION
        },
        captionUnitScale: {
          .../** @type {DyniEditableParameterSpec} */ (commonThreeElementsEditables.captionUnitScale),
          condition: NAV_TEXT_KIND_CONDITION
        }
      },
      /** @this {DyniClusterConfigValues} @param {DyniClusterConfigValues | null | undefined} values @returns {DyniClusterConfigValues} */
      updateFunction: function (values) {
        const out = /** @type {DyniClusterConfigValues} */ (values ? { ...values } : {});
        const kind = (values && values.kind) || "wpEta";
        const needsWp = kind === "dst" || kind === "positionWp" || kind === "xteDisplay" || kind === "xteDisplayLinear";
        if (needsWp && values && values.wpServer === false) out.disconnect = true;
        else if (Object.prototype.hasOwnProperty.call(out, "disconnect")) delete out.disconnect;
        if (Object.prototype.hasOwnProperty.call(out, "visible")) {
          delete out.visible;
        }
        return out;
      }
    }
  });
})(this);

/**
 * @file DyniPlugin Map Cluster - Map-focused instruments (center display, zoom action, AIS target summary)
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  /** @typedef {Record<string, unknown> & { kind?: unknown, lockPosition?: unknown, editing?: unknown, visible?: unknown }} DyniMapValues */
  /** @typedef {DyniPluginSharedConfig & { makePerKindCaptionParams: (map: DyniPerKindTextParameterMap) => DyniEditableParameters, makePerKindTextParams: (map: DyniPerKindTextParameterMap) => DyniEditableParameters, makeUnitAwareTextParams: (map: DyniPerKindTextParameterMap, bindings: Readonly<Record<string, DyniUnitFormatBinding>>) => DyniEditableParameters, opt: (name: unknown, value: unknown) => DyniEditableOption, kindMaps: Record<string, DyniPerKindTextParameterMap>, unitFormatFamilies: DyniUnitFormatCatalog }} DyniMapSharedConfig */
  /** @typedef {{ DyniPlugin: DyniPluginNamespace & { config: DyniPluginConfig & { clusters: DyniWidgetDefinition[] } } }} DyniMapRoot */

  const ns = /** @type {DyniMapRoot} */ (/** @type {unknown} */ (root)).DyniPlugin;
  const config = ns.config;
  const shared = /** @type {DyniMapSharedConfig} */ (config.shared);

  const makePerKindCaptionParams = shared.makePerKindCaptionParams;
  const makePerKindTextParams = shared.makePerKindTextParams;
  const makeUnitAwareTextParams = shared.makeUnitAwareTextParams;
  const opt = shared.opt;
  const MAP_TEXT_KIND = shared.kindMaps.MAP_TEXT_KIND;
  const MAP_UNIT_AWARE_KIND = shared.kindMaps.MAP_UNIT_AWARE_KIND;
  const mapBindings = shared.unitFormatFamilies.metricBindings;
  const CENTER_DISPLAY_CONDITION = { kind: "centerDisplay" };
  const AIS_TARGET_CONDITION = { kind: "aisTarget" };

  config.clusters.push({
    widget: "ClusterWidget",
    def: {
      name: "dyni_Map_Instruments",
      description: "Map values (Center display / Zoom / AIS target)",
      caption: "",
      unit: "",
      default: "---",
      cluster: "map",
      storeKeys: {
        zoom: "map.currentZoom",
        requiredZoom: "map.requiredZoom",
        centerCourse: "nav.center.course",
        centerDistance: "nav.center.distance",
        centerMarkerCourse: "nav.center.markerCourse",
        centerMarkerDistance: "nav.center.markerDistance",
        centerPosition: "map.centerPosition",
        activeMeasure: "map.activeMeasure",
        measureRhumbLine: "properties.measureRhumbLine",
        lockPosition: "map.lockPosition",
        target: "nav.ais.nearest",
        trackedMmsi: "nav.ais.trackedMmsi",
        aisMarkAllWarning: "properties.aisMarkAllWarning"
      },
      editableParameters: {
        kind: {
          type: "SELECT",
          list: [opt("Center display", "centerDisplay"), opt("Zoom", "zoom"), opt("AIS target", "aisTarget")],
          default: "centerDisplay",
          name: "Instrument"
        },
        centerDisplayRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.1,
          internal: true,
          name: "CenterDisplay: 3-Rows Threshold",
          condition: CENTER_DISPLAY_CONDITION
        },
        centerDisplayRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.0,
          max: 6.0,
          step: 0.05,
          default: 2.4,
          internal: true,
          name: "CenterDisplay: 1-Row Threshold",
          condition: CENTER_DISPLAY_CONDITION
        },
        aisTargetRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.2,
          internal: true,
          name: "AisTarget: 3-Rows Threshold",
          condition: AIS_TARGET_CONDITION
        },
        aisTargetRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.0,
          max: 6.0,
          step: 0.05,
          default: 3.8,
          internal: true,
          name: "AisTarget: 1-Row Threshold",
          condition: AIS_TARGET_CONDITION
        },
        coordinatesTabular: {
          type: "BOOLEAN",
          default: true,
          name: "Tabular coordinates",
          condition: CENTER_DISPLAY_CONDITION
        },
        stableDigits: {
          type: "BOOLEAN",
          default: false,
          name: "Stable digits",
          condition: [CENTER_DISPLAY_CONDITION, { kind: "zoom" }, { kind: "aisTarget" }]
        },
        caption: false,
        unit: false,
        formatter: false,
        formatterParameters: false,
        className: true,
        ...makePerKindCaptionParams(MAP_UNIT_AWARE_KIND),
        ...makeUnitAwareTextParams(MAP_UNIT_AWARE_KIND, mapBindings),
        ...makePerKindTextParams(MAP_TEXT_KIND)
      },
      /** @param {DyniMapValues | null | undefined} values @returns {DyniMapValues} */
      updateFunction: function (values) {
        const out = /** @type {DyniMapValues} */ (values ? { ...values } : {});
        const kind = (values && values.kind) || "centerDisplay";
        if (kind === "centerDisplay") {
          out.visible = !(values && values.lockPosition) || !!(values && values.editing);
        } else if (Object.prototype.hasOwnProperty.call(out, "visible")) {
          delete out.visible;
        }
        return out;
      }
    }
  });
})(this);

/**
 * @file DyniPlugin Anchor Cluster - Anchor distance/watch/bearing widget config
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  /** @typedef {DyniPluginSharedConfig & { makePerKindCaptionParams: (map: DyniPerKindTextParameterMap) => DyniEditableParameters, makePerKindTextParams: (map: DyniPerKindTextParameterMap) => DyniEditableParameters, makeUnitAwareTextParams: (map: DyniPerKindTextParameterMap, bindings: Readonly<Record<string, DyniUnitFormatBinding>>) => DyniEditableParameters, opt: (name: unknown, value: unknown) => DyniEditableOption, kindMaps: Record<string, DyniPerKindTextParameterMap>, commonThreeElementsEditables: DyniEditableParameters, unitFormatFamilies: DyniUnitFormatCatalog }} DyniAnchorSharedConfig */
  /** @typedef {{ DyniPlugin: DyniPluginNamespace & { config: DyniPluginConfig & { clusters: DyniWidgetDefinition[] }, } }} DyniAnchorRoot */

  const ns = /** @type {DyniAnchorRoot} */ (/** @type {unknown} */ (root)).DyniPlugin;
  const config = ns.config;
  const shared = /** @type {DyniAnchorSharedConfig} */ (config.shared);

  const makePerKindCaptionParams = shared.makePerKindCaptionParams;
  const makePerKindTextParams = shared.makePerKindTextParams;
  const makeUnitAwareTextParams = shared.makeUnitAwareTextParams;
  const opt = shared.opt;
  const ANCHOR_TEXT_KIND = shared.kindMaps.ANCHOR_TEXT_KIND;
  const ANCHOR_UNIT_AWARE_KIND = shared.kindMaps.ANCHOR_UNIT_AWARE_KIND;
  const commonThreeElementsEditables = shared.commonThreeElementsEditables;
  const anchorBindings = shared.unitFormatFamilies.metricBindings;

  config.clusters.push({
    widget: "ClusterWidget",
    def: {
      name: "dyni_Anchor_Instruments",
      description: "Anchor metrics (distance, watch radius, bearing)",
      caption: "",
      unit: "",
      default: "---",
      cluster: "anchor",
      storeKeys: {
        distance: "nav.anchor.distance",
        watch: "nav.anchor.watchDistance",
        bearing: "nav.anchor.direction"
      },
      editableParameters: {
        kind: {
          type: "SELECT",
          list: [
            opt("Distance from anchor", "anchorDistance"),
            opt("Anchor watch radius", "anchorWatch"),
            opt("Bearing from anchor", "anchorBearing")
          ],
          default: "anchorDistance",
          name: "Instrument"
        },
        leadingZero: {
          type: "BOOLEAN",
          default: true,
          name: "Leading zero for bearing (e.g., 005°)",
          condition: { kind: "anchorBearing" }
        },
        caption: false,
        unit: false,
        formatter: false,
        formatterParameters: false,
        className: true,
        ...makePerKindCaptionParams(ANCHOR_UNIT_AWARE_KIND),
        ...makeUnitAwareTextParams(ANCHOR_UNIT_AWARE_KIND, anchorBindings),
        ...makePerKindTextParams(ANCHOR_TEXT_KIND),
        ...commonThreeElementsEditables,
        stableDigits: {
          type: "BOOLEAN",
          default: false,
          name: "Stable digits",
          condition: [{ kind: "anchorDistance" }, { kind: "anchorWatch" }, { kind: "anchorBearing" }]
        }
      }
    }
  });
})(this);

/**
 * @file DyniPlugin Vessel Cluster - Vessel metrics widget config (voltage + alarm + clock/time)
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  const ns = /** @type {DyniVesselClusterRoot} */ (/** @type {unknown} */ (root)).DyniPlugin;
  const config = ns.config;
  const shared = config.shared;

  const makePerKindTextParams = shared.makePerKindTextParams;
  const opt = shared.opt;
  const VESSEL_KIND = shared.kindMaps.VESSEL_KIND;
  const DEFAULT_PITCH_KEY = "nav.gps.signalk.navigation.attitude.pitch";
  const DEFAULT_ROLL_KEY = "nav.gps.signalk.navigation.attitude.roll";

  config.clusters.push({
    widget: "ClusterWidget",
    def: {
      name: "dyni_Vessel_Instruments",
      description: "Vessel metrics (voltage, alarm, time/date, GPS status, SignalK attitude)",
      caption: "",
      unit: "",
      default: "---",
      cluster: "vessel",
      storeKeys: {
        alarmInfo: "nav.alarms.all",
        clock: "nav.gps.rtime",
        gpsValid: "nav.gps.valid",
        pitch: DEFAULT_PITCH_KEY,
        roll: DEFAULT_ROLL_KEY
      },

      editableParameters: {
        kind: {
          type: "SELECT",
          list: [
            opt("Voltage (SignalK)", "voltage"),
            opt("Voltage gauge (linear)", "voltageLinear"),
            opt("Voltage gauge (radial)", "voltageRadial"),
            opt("Regatta timer", "regattaTimer"),
            opt("Alarm", "alarm"),
            opt("Clock (local time)", "clock"),
            opt("Analog clock [Radial]", "clockRadial"),
            opt("Date and time", "dateTime"),
            opt("Time with GPS status", "timeStatus"),
            opt("SignalK pitch", "pitch"),
            opt("SignalK roll", "roll")
          ],
          default: "voltage",
          name: "Instrument"
        },

        // Voltage source (SignalK) for voltage kinds
        value: {
          type: "KEY",
          default: "",
          name: "Voltage store path",
          condition: [{ kind: "voltage" }, { kind: "voltageLinear" }, { kind: "voltageRadial" }]
        },
        pitchKey: {
          type: "KEY",
          default: DEFAULT_PITCH_KEY,
          name: "Pitch store path",
          condition: { kind: "pitch" }
        },
        rollKey: {
          type: "KEY",
          default: DEFAULT_ROLL_KEY,
          name: "Roll store path",
          condition: { kind: "roll" }
        },
        regattaSoundEnabled: {
          type: "BOOLEAN",
          default: true,
          name: "Acoustic signals",
          condition: { kind: "regattaTimer" }
        },
        regattaProgressBar: {
          type: "BOOLEAN",
          default: true,
          name: "Show progress bar",
          condition: { kind: "regattaTimer" }
        },
        regattaDuration: {
          type: "SELECT",
          list: [opt("5 Minutes", 5), opt("6 Minutes", 6), opt("3 Minutes", 3)],
          default: 5,
          name: "Countdown (minutes)",
          condition: { kind: "regattaTimer" }
        },
        regattaTimerRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.0,
          internal: true,
          name: "RegattaTimer: Normal Threshold",
          condition: { kind: "regattaTimer" }
        },
        regattaTimerRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.5,
          max: 6.0,
          step: 0.05,
          default: 3.0,
          internal: true,
          name: "RegattaTimer: Flat Threshold",
          condition: { kind: "regattaTimer" }
        },

        // --- Voltage gauge params (linear + radial) ---
        ...shared.buildVesselVoltageGaugeParams(),

        // Shared scale
        captionUnitScale: {
          type: "FLOAT",
          min: 0.5,
          max: 1.5,
          step: 0.05,
          default: 0.8,
          name: "Caption/Unit size",
          condition: [
            { kind: "voltage" },
            { kind: "voltageLinear" },
            { kind: "voltageRadial" },
            { kind: "alarm" },
            { kind: "clock" },
            { kind: "dateTime" },
            { kind: "timeStatus" },
            { kind: "pitch" },
            { kind: "roll" }
          ]
        },
        stableDigits: {
          type: "BOOLEAN",
          name: "Stable digits",
          condition: [
            { kind: "voltage" },
            { kind: "voltageLinear" },
            { kind: "voltageRadial" },
            { kind: "regattaTimer" },
            { kind: "clock" },
            { kind: "dateTime" },
            { kind: "timeStatus" },
            { kind: "pitch" },
            { kind: "roll" }
          ]
        },
        easing: {
          type: "BOOLEAN",
          default: true,
          name: "Smooth motion",
          condition: [{ kind: "voltageLinear" }, { kind: "voltageRadial" }]
        },
        voltageLinearHideTextualMetrics: {
          type: "BOOLEAN",
          default: false,
          name: "Hide textual metrics",
          condition: { kind: "voltageLinear" }
        },
        voltageRadialHideTextualMetrics: {
          type: "BOOLEAN",
          default: false,
          name: "Hide textual metrics",
          condition: { kind: "voltageRadial" }
        },
        clockRadialRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 0.7,
          internal: true,
          name: "ClockRadial: Normal Threshold",
          condition: { kind: "clockRadial" }
        },
        clockRadialRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.0,
          max: 6.0,
          step: 0.05,
          default: 2.0,
          internal: true,
          name: "ClockRadial: Flat Threshold",
          condition: { kind: "clockRadial" }
        },
        hideSeconds: {
          type: "BOOLEAN",
          default: false,
          name: "Hide seconds",
          condition: [{ kind: "clock" }, { kind: "clockRadial" }, { kind: "dateTime" }, { kind: "timeStatus" }]
        },
        alarmRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.0,
          internal: true,
          name: "Alarm: Normal Threshold",
          condition: { kind: "alarm" }
        },
        alarmRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.5,
          max: 6.0,
          step: 0.05,
          default: 3.0,
          internal: true,
          name: "Alarm: Flat Threshold",
          condition: { kind: "alarm" }
        },

        caption: false,
        unit: false,
        formatter: false,
        formatterParameters: false,
        className: true,

        ...makePerKindTextParams(VESSEL_KIND),
        caption_clockRadial: false,
        unit_clockRadial: false,
        caption_regattaTimer: false,
        unit_regattaTimer: false,

        // ThreeValueTextWidget thresholds (numeric only)
        ratioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.0,
          internal: true,
          name: "3-Rows Threshold (numeric)",
          condition: [
            { kind: "voltage" },
            { kind: "clock" },
            { kind: "timeStatus" },
            { kind: "pitch" },
            { kind: "roll" }
          ]
        },
        ratioThresholdFlat: {
          type: "FLOAT",
          min: 1.5,
          max: 6.0,
          step: 0.05,
          default: 3.0,
          internal: true,
          name: "1-Row Threshold (numeric)",
          condition: [
            { kind: "voltage" },
            { kind: "clock" },
            { kind: "timeStatus" },
            { kind: "pitch" },
            { kind: "roll" }
          ]
        },
        dateTimeRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.2,
          internal: true,
          name: "DateTime: 3-Rows Threshold",
          condition: { kind: "dateTime" }
        },
        dateTimeRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.5,
          max: 6.0,
          step: 0.05,
          default: 4,
          internal: true,
          name: "DateTime: 1-Row Threshold",
          condition: { kind: "dateTime" }
        }
      },

      /** @this {DyniClusterConfigValues} @param {DyniClusterConfigValues | null | undefined} values @returns {DyniClusterConfigValues} */
      updateFunction: function (values) {
        const out = /** @type {DyniClusterConfigValues} */ (values ? { ...values } : {});
        const kind = (values && values.kind) || "voltage";

        if (!out.storeKeys) out.storeKeys = {};

        // attach selected SK path into storeKeys.value (required!)
        if (kind === "voltage" || kind === "voltageLinear" || kind === "voltageRadial") {
          if (typeof out.value === "string" && out.value.trim()) {
            out.storeKeys = { .../** @type {Record<string, unknown>} */ (out.storeKeys), value: out.value.trim() };
          } else if (Object.prototype.hasOwnProperty.call(out.storeKeys, "value")) {
            const sk = { .../** @type {Record<string, unknown>} */ (out.storeKeys) };
            delete sk.value;
            out.storeKeys = sk;
          }
        } else {
          if (Object.prototype.hasOwnProperty.call(out.storeKeys, "value")) {
            const sk = { .../** @type {Record<string, unknown>} */ (out.storeKeys) };
            delete sk.value;
            out.storeKeys = sk;
          }
        }

        if (kind === "pitch") {
          if (typeof out.pitchKey === "string" && out.pitchKey.trim()) {
            out.storeKeys = { .../** @type {Record<string, unknown>} */ (out.storeKeys), pitch: out.pitchKey.trim() };
          } else {
            out.storeKeys = { .../** @type {Record<string, unknown>} */ (out.storeKeys), pitch: DEFAULT_PITCH_KEY };
          }
        }

        if (kind === "roll") {
          if (typeof out.rollKey === "string" && out.rollKey.trim()) {
            out.storeKeys = { .../** @type {Record<string, unknown>} */ (out.storeKeys), roll: out.rollKey.trim() };
          } else {
            out.storeKeys = { .../** @type {Record<string, unknown>} */ (out.storeKeys), roll: DEFAULT_ROLL_KEY };
          }
        }

        return out;
      }
    }
  });
})(this);

/**
 * @file DyniPlugin Default Cluster Radial Editables - radialGauge-mode editable parameter fragment
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  /** @typedef {DyniPluginSharedConfig & { buildDefaultRadialEditableParameters?: () => DyniEditableParameters }} DyniDefaultRadialShared */

  const ns = /** @type {DyniPluginNamespace} */ (/** @type {unknown} */ (root.DyniPlugin));
  const config = ns.config;
  const shared = /** @type {DyniDefaultRadialShared} */ (config.shared);

  /** @returns {DyniEditableParameters} */
  shared.buildDefaultRadialEditableParameters = function () {
    return {
      defaultRadialRatioThresholdNormal: {
        type: "FLOAT",
        min: 0.5,
        max: 2.0,
        step: 0.05,
        default: 1.1,
        internal: true,
        name: "DefaultRadialWidget: Normal Threshold",
        condition: { kind: "radialGauge" }
      },
      defaultRadialRatioThresholdFlat: {
        type: "FLOAT",
        min: 1.0,
        max: 6.0,
        step: 0.05,
        default: 3.5,
        internal: true,
        name: "DefaultRadialWidget: Flat Threshold",
        condition: { kind: "radialGauge" }
      },
      defaultRadialMinValue: {
        type: "FLOAT",
        min: 0,
        max: 100,
        step: 1,
        default: 0,
        name: "Min value",
        condition: { kind: "radialGauge" }
      },
      defaultRadialMaxValue: {
        type: "FLOAT",
        min: 1,
        max: 100,
        step: 1,
        default: 100,
        name: "Max value",
        condition: { kind: "radialGauge" }
      },
      defaultRadialTickMajor: {
        type: "FLOAT",
        min: 0.5,
        max: 100,
        step: 0.5,
        default: 10,
        name: "Major tick step",
        condition: { kind: "radialGauge" }
      },
      defaultRadialTickMinor: {
        type: "FLOAT",
        min: 0.1,
        max: 50,
        step: 0.1,
        default: 2,
        name: "Minor tick step",
        condition: { kind: "radialGauge" }
      },
      defaultRadialShowEndLabels: {
        type: "BOOLEAN",
        default: false,
        name: "Show min/max labels",
        condition: { kind: "radialGauge" }
      },
      defaultRadialAlarmLowEnabled: {
        type: "BOOLEAN",
        default: false,
        name: "Show low alarm sector",
        condition: { kind: "radialGauge" }
      },
      defaultRadialAlarmLowAt: {
        type: "FLOAT",
        min: 0,
        max: 100,
        step: 1,
        default: 10,
        name: "Alarm at or below",
        condition: { kind: "radialGauge", defaultRadialAlarmLowEnabled: true }
      },
      defaultRadialAlarmLowColor: {
        type: "COLOR",
        default: "#d9534a",
        name: "Alarm color",
        condition: { kind: "radialGauge", defaultRadialAlarmLowEnabled: true }
      },
      defaultRadialWarningLowEnabled: {
        type: "BOOLEAN",
        default: false,
        name: "Show low warning sector",
        condition: { kind: "radialGauge" }
      },
      defaultRadialWarningLowAt: {
        type: "FLOAT",
        min: 0,
        max: 100,
        step: 1,
        default: 25,
        name: "Warning at or below",
        condition: { kind: "radialGauge", defaultRadialWarningLowEnabled: true }
      },
      defaultRadialWarningLowColor: {
        type: "COLOR",
        default: "#e0a92e",
        name: "Warning color",
        condition: { kind: "radialGauge", defaultRadialWarningLowEnabled: true }
      },
      defaultRadialWarningHighEnabled: {
        type: "BOOLEAN",
        default: false,
        name: "Show high warning sector",
        condition: { kind: "radialGauge" }
      },
      defaultRadialWarningHighAt: {
        type: "FLOAT",
        min: 0,
        max: 100,
        step: 1,
        default: 75,
        name: "Warning at or above",
        condition: { kind: "radialGauge", defaultRadialWarningHighEnabled: true }
      },
      defaultRadialWarningHighColor: {
        type: "COLOR",
        default: "#e0a92e",
        name: "Warning color",
        condition: { kind: "radialGauge", defaultRadialWarningHighEnabled: true }
      },
      defaultRadialAlarmHighEnabled: {
        type: "BOOLEAN",
        default: false,
        name: "Show high alarm sector",
        condition: { kind: "radialGauge" }
      },
      defaultRadialAlarmHighAt: {
        type: "FLOAT",
        min: 0,
        max: 100,
        step: 1,
        default: 90,
        name: "Alarm at or above",
        condition: { kind: "radialGauge", defaultRadialAlarmHighEnabled: true }
      },
      defaultRadialAlarmHighColor: {
        type: "COLOR",
        default: "#d9534a",
        name: "Alarm color",
        condition: { kind: "radialGauge", defaultRadialAlarmHighEnabled: true }
      }
    };
  };
})(this);

/**
 * @file DyniPlugin Default Cluster - Self-configurable default instrument config
 * Documentation: documentation/guides/add-new-cluster.md
 */
(function (root) {
  "use strict";

  /** @typedef {Record<string, unknown> & { value?: unknown, storeKeys?: Record<string, unknown> }} DyniDefaultValues */
  /** @typedef {DyniPluginSharedConfig & { makePerKindTextParams: (map: DyniPerKindTextParameterMap) => DyniEditableParameters, opt: (name: unknown, value: unknown) => DyniEditableOption, kindMaps: Record<string, DyniPerKindTextParameterMap>, buildDefaultRadialEditableParameters: () => DyniEditableParameters }} DyniDefaultSharedConfig */
  /** @typedef {{ DyniPlugin: DyniPluginNamespace & { config: DyniPluginConfig & { clusters: DyniWidgetDefinition[] } } }} DyniDefaultRoot */

  const ns = /** @type {DyniDefaultRoot} */ (/** @type {unknown} */ (root)).DyniPlugin;
  const config = ns.config;
  const shared = /** @type {DyniDefaultSharedConfig} */ (config.shared);

  const makePerKindTextParams = shared.makePerKindTextParams;
  const opt = shared.opt;
  const DEFAULT_KIND = shared.kindMaps.DEFAULT_KIND;

  config.clusters.push({
    widget: "ClusterWidget",
    def: {
      name: "dyni_Default_Instruments",
      description: "Self-configurable instrument for any store value",
      caption: "",
      unit: "",
      default: "---",
      cluster: "default",
      storeKeys: {},
      editableParameters: {
        kind: {
          type: "SELECT",
          list: [opt("Text", "text"), opt("Linear gauge", "linearGauge"), opt("Radial gauge", "radialGauge")],
          default: "text",
          name: "Instrument"
        },
        value: {
          type: "KEY",
          default: "",
          name: "Value store path"
        },

        ratioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.0,
          internal: true,
          name: "3-Rows Threshold (numeric)",
          condition: { kind: "text" }
        },
        ratioThresholdFlat: {
          type: "FLOAT",
          min: 1.5,
          max: 6.0,
          step: 0.05,
          default: 3.0,
          internal: true,
          name: "1-Row Threshold (numeric)",
          condition: { kind: "text" }
        },

        captionUnitScale: {
          type: "FLOAT",
          min: 0.5,
          max: 1.5,
          step: 0.05,
          default: 0.8,
          name: "Caption/Unit size"
        },
        stableDigits: {
          type: "BOOLEAN",
          default: false,
          name: "Stable digits",
          condition: [{ kind: "text" }, { kind: "linearGauge" }, { kind: "radialGauge" }]
        },
        easing: {
          type: "BOOLEAN",
          default: true,
          name: "Smooth motion",
          condition: [{ kind: "linearGauge" }, { kind: "radialGauge" }]
        },
        defaultLinearHideTextualMetrics: {
          type: "BOOLEAN",
          default: false,
          name: "Hide textual metrics",
          condition: { kind: "linearGauge" }
        },
        defaultRadialHideTextualMetrics: {
          type: "BOOLEAN",
          default: false,
          name: "Hide textual metrics",
          condition: { kind: "radialGauge" }
        },

        caption: false,
        unit: false,
        formatter: true,
        formatterParameters: true,
        className: true,

        defaultLinearRatioThresholdNormal: {
          type: "FLOAT",
          min: 0.5,
          max: 2.0,
          step: 0.05,
          default: 1.1,
          internal: true,
          name: "DefaultLinearWidget: Normal Threshold",
          condition: { kind: "linearGauge" }
        },
        defaultLinearRatioThresholdFlat: {
          type: "FLOAT",
          min: 1.0,
          max: 6.0,
          step: 0.05,
          default: 3.5,
          internal: true,
          name: "DefaultLinearWidget: Flat Threshold",
          condition: { kind: "linearGauge" }
        },
        defaultLinearMinValue: {
          type: "FLOAT",
          min: 0,
          max: 100,
          step: 1,
          default: 0,
          name: "Min value",
          condition: { kind: "linearGauge" }
        },
        defaultLinearMaxValue: {
          type: "FLOAT",
          min: 1,
          max: 100,
          step: 1,
          default: 100,
          name: "Max value",
          condition: { kind: "linearGauge" }
        },
        defaultLinearTickMajor: {
          type: "FLOAT",
          min: 0.5,
          max: 100,
          step: 0.5,
          default: 10,
          name: "Major tick step",
          condition: { kind: "linearGauge" }
        },
        defaultLinearTickMinor: {
          type: "FLOAT",
          min: 0.1,
          max: 50,
          step: 0.1,
          default: 2,
          name: "Minor tick step",
          condition: { kind: "linearGauge" }
        },
        defaultLinearShowEndLabels: {
          type: "BOOLEAN",
          default: false,
          name: "Show min/max labels",
          condition: { kind: "linearGauge" }
        },
        defaultLinearAlarmLowEnabled: {
          type: "BOOLEAN",
          default: false,
          name: "Show low alarm sector",
          condition: { kind: "linearGauge" }
        },
        defaultLinearAlarmLowAt: {
          type: "FLOAT",
          min: 0,
          max: 100,
          step: 1,
          default: 10,
          name: "Alarm at or below",
          condition: { kind: "linearGauge", defaultLinearAlarmLowEnabled: true }
        },
        defaultLinearAlarmLowColor: {
          type: "COLOR",
          default: "#d9534a",
          name: "Alarm color",
          condition: { kind: "linearGauge", defaultLinearAlarmLowEnabled: true }
        },
        defaultLinearWarningLowEnabled: {
          type: "BOOLEAN",
          default: false,
          name: "Show low warning sector",
          condition: { kind: "linearGauge" }
        },
        defaultLinearWarningLowAt: {
          type: "FLOAT",
          min: 0,
          max: 100,
          step: 1,
          default: 25,
          name: "Warning at or below",
          condition: { kind: "linearGauge", defaultLinearWarningLowEnabled: true }
        },
        defaultLinearWarningLowColor: {
          type: "COLOR",
          default: "#e0a92e",
          name: "Warning color",
          condition: { kind: "linearGauge", defaultLinearWarningLowEnabled: true }
        },
        defaultLinearWarningHighEnabled: {
          type: "BOOLEAN",
          default: false,
          name: "Show high warning sector",
          condition: { kind: "linearGauge" }
        },
        defaultLinearWarningHighAt: {
          type: "FLOAT",
          min: 0,
          max: 100,
          step: 1,
          default: 75,
          name: "Warning at or above",
          condition: { kind: "linearGauge", defaultLinearWarningHighEnabled: true }
        },
        defaultLinearWarningHighColor: {
          type: "COLOR",
          default: "#e0a92e",
          name: "Warning color",
          condition: { kind: "linearGauge", defaultLinearWarningHighEnabled: true }
        },
        defaultLinearAlarmHighEnabled: {
          type: "BOOLEAN",
          default: false,
          name: "Show high alarm sector",
          condition: { kind: "linearGauge" }
        },
        defaultLinearAlarmHighAt: {
          type: "FLOAT",
          min: 0,
          max: 100,
          step: 1,
          default: 90,
          name: "Alarm at or above",
          condition: { kind: "linearGauge", defaultLinearAlarmHighEnabled: true }
        },
        defaultLinearAlarmHighColor: {
          type: "COLOR",
          default: "#d9534a",
          name: "Alarm color",
          condition: { kind: "linearGauge", defaultLinearAlarmHighEnabled: true }
        },

        ...shared.buildDefaultRadialEditableParameters(),

        ...makePerKindTextParams(DEFAULT_KIND)
      },
      /** @param {DyniDefaultValues | null | undefined} values @returns {DyniDefaultValues} */
      updateFunction: function (values) {
        const out = /** @type {DyniDefaultValues} */ (values ? { ...values } : {});

        if (!out.storeKeys) out.storeKeys = {};

        if (typeof out.value === "string" && out.value.trim()) {
          out.storeKeys = { ...out.storeKeys, value: out.value.trim() };
        } else if (Object.prototype.hasOwnProperty.call(out.storeKeys, "value")) {
          const sk = { ...out.storeKeys };
          delete sk.value;
          out.storeKeys = sk;
        }

        return out;
      }
    }
  });
})(this);

/**
 * @file DyniPlugin Cluster Routes - Canonical route metadata initializer
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  var ns = root.DyniPlugin;
  var config = (ns.config = ns.config || {});

  config.clusterRoutes = {
    schemaVersion: 1,
    routes: []
  };
})(this);

/**
 * @file DyniPlugin Cluster Routes CourseHeading - Route metadata for course-heading kinds
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  var routes = root.DyniPlugin.config.clusterRoutes.routes;

  routes.push(
    {
      cluster: "courseHeading",
      kind: "cog",
      mapperId: "CourseHeadingMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "courseHeading",
      kind: "hdt",
      mapperId: "CourseHeadingMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "courseHeading",
      kind: "hdm",
      mapperId: "CourseHeadingMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "courseHeading",
      kind: "brg",
      mapperId: "CourseHeadingMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "courseHeading",
      kind: "hdtRadial",
      mapperId: "CourseHeadingMapper",
      rendererId: "CompassRadialWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 1 }
    },
    {
      cluster: "courseHeading",
      kind: "hdmRadial",
      mapperId: "CourseHeadingMapper",
      rendererId: "CompassRadialWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 1 }
    },
    {
      cluster: "courseHeading",
      kind: "hdtLinear",
      mapperId: "CourseHeadingMapper",
      rendererId: "CompassLinearWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "courseHeading",
      kind: "hdmLinear",
      mapperId: "CourseHeadingMapper",
      rendererId: "CompassLinearWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    }
  );
})(this);

/**
 * @file DyniPlugin Cluster Routes Speed - Route metadata for speed kinds
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  var routes = root.DyniPlugin.config.clusterRoutes.routes;

  routes.push(
    {
      cluster: "speed",
      kind: "sog",
      mapperId: "SpeedMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "speed",
      kind: "stw",
      mapperId: "SpeedMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "speed",
      kind: "sogLinear",
      mapperId: "SpeedMapper",
      rendererId: "SpeedLinearWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "speed",
      kind: "stwLinear",
      mapperId: "SpeedMapper",
      rendererId: "SpeedLinearWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "speed",
      kind: "sogRadial",
      mapperId: "SpeedMapper",
      rendererId: "SpeedRadialWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 1 }
    },
    {
      cluster: "speed",
      kind: "stwRadial",
      mapperId: "SpeedMapper",
      rendererId: "SpeedRadialWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 1 }
    }
  );
})(this);

/**
 * @file DyniPlugin Cluster Routes Environment - Route metadata for environment kinds
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  var routes = root.DyniPlugin.config.clusterRoutes.routes;

  routes.push(
    {
      cluster: "environment",
      kind: "depth",
      mapperId: "EnvironmentMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "environment",
      kind: "depthLinear",
      mapperId: "EnvironmentMapper",
      rendererId: "DepthLinearWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "environment",
      kind: "depthRadial",
      mapperId: "EnvironmentMapper",
      rendererId: "DepthRadialWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 1 }
    },
    {
      cluster: "environment",
      kind: "temp",
      mapperId: "EnvironmentMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "environment",
      kind: "tempLinear",
      mapperId: "EnvironmentMapper",
      rendererId: "TemperatureLinearWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "environment",
      kind: "tempRadial",
      mapperId: "EnvironmentMapper",
      rendererId: "TemperatureRadialWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 1 }
    },
    {
      cluster: "environment",
      kind: "pressure",
      mapperId: "EnvironmentMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    }
  );
})(this);

/**
 * @file DyniPlugin Cluster Routes Wind - Route metadata for wind kinds
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  var routes = root.DyniPlugin.config.clusterRoutes.routes;

  routes.push(
    {
      cluster: "wind",
      kind: "angleTrue",
      mapperId: "WindMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "wind",
      kind: "angleApparent",
      mapperId: "WindMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "wind",
      kind: "angleTrueDirection",
      mapperId: "WindMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "wind",
      kind: "speedTrue",
      mapperId: "WindMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "wind",
      kind: "speedApparent",
      mapperId: "WindMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "wind",
      kind: "angleTrueRadial",
      mapperId: "WindMapper",
      rendererId: "WindRadialWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 1 }
    },
    {
      cluster: "wind",
      kind: "angleApparentRadial",
      mapperId: "WindMapper",
      rendererId: "WindRadialWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 1 }
    },
    {
      cluster: "wind",
      kind: "angleTrueLinear",
      mapperId: "WindMapper",
      rendererId: "WindLinearWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "wind",
      kind: "angleApparentLinear",
      mapperId: "WindMapper",
      rendererId: "WindLinearWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    }
  );
})(this);

/**
 * @file DyniPlugin Cluster Routes Nav - Route metadata for navigation kinds
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  const ns = /** @type {DyniPluginNamespace} */ (/** @type {unknown} */ (root.DyniPlugin));
  /** @type {DyniClusterRoute[]} */
  var routes = ns.config.clusterRoutes.routes;

  routes.push(
    {
      cluster: "nav",
      kind: "wpEta",
      mapperId: "NavMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "nav",
      kind: "rteEta",
      mapperId: "NavMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "nav",
      kind: "dst",
      mapperId: "NavMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "nav",
      kind: "rteDistance",
      mapperId: "NavMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "nav",
      kind: "vmg",
      mapperId: "NavMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "nav",
      kind: "activeRoute",
      mapperId: "NavMapper",
      viewModelId: "ActiveRouteViewModel",
      rendererId: "ActiveRouteTextHtmlWidget",
      surface: "html",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "nav",
      kind: "editRoute",
      mapperId: "NavMapper",
      viewModelId: "EditRouteViewModel",
      rendererId: "EditRouteTextHtmlWidget",
      surface: "html",
      shellSizing: { kind: "ratio", aspectRatio: 0.875 }
    },
    {
      cluster: "nav",
      kind: "routePoints",
      mapperId: "NavMapper",
      viewModelId: "RoutePointsViewModel",
      rendererId: "RoutePointsTextHtmlWidget",
      surface: "html",
      shellSizing: { kind: "natural" }
    },
    {
      cluster: "nav",
      kind: "positionBoat",
      mapperId: "NavMapper",
      rendererId: "PositionCoordinateWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "nav",
      kind: "positionWp",
      mapperId: "NavMapper",
      rendererId: "PositionCoordinateWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "nav",
      kind: "xteDisplay",
      mapperId: "NavMapper",
      rendererId: "XteDisplayWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "nav",
      kind: "xteDisplayLinear",
      mapperId: "NavMapper",
      rendererId: "XteDisplayLinearWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    }
  );
})(this);

/**
 * @file DyniPlugin Cluster Routes Map - Route metadata for map kinds
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  var routes = root.DyniPlugin.config.clusterRoutes.routes;

  routes.push(
    {
      cluster: "map",
      kind: "centerDisplay",
      mapperId: "MapMapper",
      rendererId: "CenterDisplayTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 1 }
    },
    {
      cluster: "map",
      kind: "zoom",
      mapperId: "MapMapper",
      rendererId: "MapZoomTextHtmlWidget",
      surface: "html",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "map",
      kind: "aisTarget",
      mapperId: "MapMapper",
      viewModelId: "AisTargetViewModel",
      rendererId: "AisTargetTextHtmlWidget",
      surface: "html",
      shellSizing: { kind: "ratio", aspectRatio: 0.875 }
    }
  );
})(this);

/**
 * @file DyniPlugin Cluster Routes Anchor - Route metadata for anchor kinds
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  var routes = root.DyniPlugin.config.clusterRoutes.routes;

  routes.push(
    {
      cluster: "anchor",
      kind: "anchorDistance",
      mapperId: "AnchorMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "anchor",
      kind: "anchorWatch",
      mapperId: "AnchorMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "anchor",
      kind: "anchorBearing",
      mapperId: "AnchorMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    }
  );
})(this);

/**
 * @file DyniPlugin Cluster Routes Vessel - Route metadata for vessel kinds
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  var routes = root.DyniPlugin.config.clusterRoutes.routes;

  routes.push(
    {
      cluster: "vessel",
      kind: "voltage",
      mapperId: "VesselMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "vessel",
      kind: "voltageLinear",
      mapperId: "VesselMapper",
      rendererId: "VoltageLinearWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "vessel",
      kind: "voltageRadial",
      mapperId: "VesselMapper",
      rendererId: "VoltageRadialWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 1 }
    },
    {
      cluster: "vessel",
      kind: "alarm",
      mapperId: "VesselMapper",
      viewModelId: "AlarmViewModel",
      rendererId: "AlarmTextHtmlWidget",
      surface: "html",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "vessel",
      kind: "regattaTimer",
      mapperId: "VesselMapper",
      rendererId: "RegattaTimerTextHtmlWidget",
      surface: "html",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "vessel",
      kind: "clock",
      mapperId: "VesselMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "vessel",
      kind: "clockRadial",
      mapperId: "VesselMapper",
      rendererId: "ClockRadialWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 1 }
    },
    {
      cluster: "vessel",
      kind: "dateTime",
      mapperId: "VesselMapper",
      rendererId: "PositionCoordinateWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "vessel",
      kind: "timeStatus",
      mapperId: "VesselMapper",
      rendererId: "PositionCoordinateWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "vessel",
      kind: "pitch",
      mapperId: "VesselMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "vessel",
      kind: "roll",
      mapperId: "VesselMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    }
  );
})(this);

/**
 * @file DyniPlugin Cluster Routes Default - Route metadata for default kinds
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  var routes = root.DyniPlugin.config.clusterRoutes.routes;

  routes.push(
    {
      cluster: "default",
      kind: "text",
      mapperId: "DefaultMapper",
      rendererId: "ThreeValueTextWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "default",
      kind: "linearGauge",
      mapperId: "DefaultMapper",
      rendererId: "DefaultLinearWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 2 }
    },
    {
      cluster: "default",
      kind: "radialGauge",
      mapperId: "DefaultMapper",
      rendererId: "DefaultRadialWidget",
      surface: "canvas-dom",
      shellSizing: { kind: "ratio", aspectRatio: 1 }
    }
  );
})(this);

/**
 * @file DyniPlugin Cluster Routes Finalize - Derives routeId and byRouteId index
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  var clusterRoutes = root.DyniPlugin.config.clusterRoutes;
  var routes = clusterRoutes && Array.isArray(clusterRoutes.routes) ? clusterRoutes.routes : [];
  var byRouteId = Object.create(null);

  for (var i = 0; i < routes.length; i += 1) {
    var route = routes[i];
    route.routeId = route.cluster + "/" + route.kind;
    byRouteId[route.routeId] = route;
  }

  clusterRoutes.byRouteId = byRouteId;
})(this);

/**
 * @file DyniPlugin Widget Definitions - Final widget definition assembly
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const config = /** @type {DyniPluginConfig} */ (ns.config);

  config.widgetDefinitions = /** @type {DyniWidgetDefinition[]} */ (config.clusters);
})(this);

/**
 * @file DyniPlugin Asset Preloader - Preloads declared component assets and exposes runtime asset lookup
 * Documentation: documentation/architecture/asset-system.md
 */
(function (root) {
  "use strict";

  const runtime = /** @type {DyniRuntimeNamespace} */ (root.DyniPlugin.runtime);

  /** @param {unknown} baseUrl @returns {DyniAssetPreloader} */
  function createAssetPreloader(baseUrl) {
    if (typeof baseUrl !== "string" || !baseUrl) {
      throw new Error("dyninstruments: baseUrl missing before runtime/asset-preloader.js load");
    }

    const cache = new Map();

    /** @param {string} relativePath @returns {string} */
    function resolveAssetUrl(relativePath) {
      return baseUrl + relativePath;
    }

    /** @param {unknown} asset @returns {DyniAssetDeclaration} */
    function validateAssetDeclaration(asset) {
      if (!asset || typeof asset !== "object") {
        throw new Error("dyninstruments: asset declaration must be an object");
      }
      const declaration = /** @type {Record<string, unknown>} */ (asset);

      if (typeof declaration.key !== "string" || !declaration.key) {
        throw new Error("dyninstruments: asset declaration missing key");
      }

      if (typeof declaration.path !== "string" || !declaration.path) {
        throw new Error("dyninstruments: asset declaration missing path for key " + declaration.key);
      }

      if (typeof declaration.type !== "string" || !declaration.type) {
        throw new Error("dyninstruments: asset declaration missing type for key " + declaration.key);
      }

      if (
        declaration.type !== "svg" &&
        declaration.type !== "image" &&
        declaration.type !== "audio" &&
        declaration.type !== "json" &&
        declaration.type !== "font"
      ) {
        throw new Error("dyninstruments: unsupported asset type '" + declaration.type + "' for key " + declaration.key);
      }

      return /** @type {DyniAssetDeclaration} */ (asset);
    }

    /** @param {unknown} response @param {string} url @param {DyniAssetType} type @returns {DyniAssetFetchResponse} */
    function checkResponseOk(response, url, type) {
      if (!response) {
        throw new Error("dyninstruments: empty response while loading " + type + " asset from " + url);
      }
      const candidate = /** @type {Record<string, unknown>} */ (response);

      if (typeof candidate.ok === "boolean" && !candidate.ok) {
        throw new Error("dyninstruments: failed to load " + type + " asset from " + url);
      }

      if (typeof candidate.status === "number" && (candidate.status < 200 || candidate.status >= 300)) {
        throw new Error("dyninstruments: failed to load " + type + " asset from " + url);
      }

      return /** @type {DyniAssetFetchResponse} */ (response);
    }

    /** @param {string} url @returns {Promise<unknown>} */
    function loadSvg(url) {
      const fetchFn = root.fetch;
      if (typeof fetchFn !== "function") {
        throw new Error("dyninstruments: fetch is required to preload svg assets");
      }

      return fetchFn(url).then(function (response) {
        return checkResponseOk(response, url, "svg").text();
      });
    }

    /** @param {string} url @returns {Promise<unknown>} */
    function loadAudio(url) {
      const fetchFn = root.fetch;
      if (typeof fetchFn !== "function") {
        throw new Error("dyninstruments: fetch is required to preload audio assets");
      }

      return fetchFn(url).then(function (response) {
        return checkResponseOk(response, url, "audio").arrayBuffer();
      });
    }

    /** @param {string} url @returns {Promise<unknown>} */
    function loadJson(url) {
      const fetchFn = root.fetch;
      if (typeof fetchFn !== "function") {
        throw new Error("dyninstruments: fetch is required to preload json assets");
      }

      return fetchFn(url).then(function (response) {
        return checkResponseOk(response, url, "json").json();
      });
    }

    /** @param {string} url @returns {Promise<unknown>} */
    function loadImage(url) {
      const ImageCtor = root.Image;
      if (typeof ImageCtor !== "function") {
        throw new Error("dyninstruments: Image is required to preload image assets");
      }

      return new Promise(function (resolve, reject) {
        const img = new ImageCtor();
        img.onload = function () {
          resolve(img);
        };
        img.onerror = function (error) {
          reject(error || new Error("dyninstruments: failed to load image asset from " + url));
        };
        img.src = url;
      });
    }

    /** @param {string} url @param {string} key @returns {Promise<unknown>} */
    function loadFont(url, key) {
      const fetchFn = root.fetch;
      if (typeof fetchFn !== "function") {
        throw new Error("dyninstruments: fetch is required to preload font assets");
      }

      return fetchFn(url)
        .then(function (response) {
          return checkResponseOk(response, url, "font").arrayBuffer();
        })
        .then(function (buffer) {
          const FontFaceCtor = root.FontFace;
          if (typeof FontFaceCtor !== "function") {
            throw new Error("dyninstruments: FontFace is required to preload font assets");
          }

          const face = new FontFaceCtor(key, /** @type {BufferSource} */ (buffer));
          const fonts = root.document && root.document.fonts;
          if (!fonts || typeof fonts.add !== "function") {
            throw new Error("dyninstruments: document.fonts.add is required to preload font assets");
          }

          fonts.add(face);
          return face;
        });
    }

    /** @param {DyniAssetDeclaration} asset @returns {Promise<unknown>} */
    function loadAsset(asset) {
      const url = resolveAssetUrl(asset.path);
      switch (asset.type) {
        case "svg":
          return loadSvg(url);
        case "image":
          return loadImage(url);
        case "audio":
          return loadAudio(url);
        case "json":
          return loadJson(url);
        case "font":
          return loadFont(url, asset.key);
        default:
          throw new Error("dyninstruments: unsupported asset type '" + asset.type + "' for key " + asset.key);
      }
    }

    /** @param {DyniAssetDeclaration} asset @returns {Promise<unknown>} */
    function preloadOne(asset) {
      const url = resolveAssetUrl(asset.path);
      if (cache.has(asset.key)) {
        throw new Error("dyninstruments: duplicate asset key '" + asset.key + "'");
      }

      cache.set(asset.key, {
        status: "pending",
        type: asset.type,
        value: null
      });

      return loadAsset(asset)
        .then(function (value) {
          cache.set(asset.key, {
            status: "loaded",
            type: asset.type,
            value: value
          });
          return value;
        })
        .catch(function (error) {
          cache.set(asset.key, {
            status: "failed",
            type: asset.type,
            value: null
          });
          return null;
        });
    }

    /** @param {unknown} assetDeclarations @returns {Promise<unknown[]>} */
    function preloadAssets(assetDeclarations) {
      if (!Array.isArray(assetDeclarations)) {
        throw new Error("dyninstruments: asset declarations must be an array");
      }

      return Promise.all(
        assetDeclarations.map(function (asset) {
          return preloadOne(validateAssetDeclaration(asset));
        })
      );
    }

    /** @param {string} key @returns {unknown} */
    function getAsset(key) {
      const record = cache.get(key);
      if (!record) {
        throw new Error("dyninstruments: unknown asset key '" + key + "'");
      }
      if (record.status === "failed") {
        return null;
      }
      return record.value;
    }

    return {
      preloadAssets: preloadAssets,
      getAsset: getAsset
    };
  }

  runtime.createAssetPreloader = createAssetPreloader;
})(this);

/**
 * @file DyniPlugin Component Loader - Dynamic JS/CSS loading and scoped component instantiation
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  /** @typedef {Record<string, unknown>} DyniLoaderModule */
  /** @typedef {{ create(definition: DyniWidgetDefinitionData, context: DyniLoaderComponentContext): unknown }} DyniLoaderFactoryModule */
  /** @typedef {{ require(dependencyId: string): unknown }} DyniLoaderComponentDependencies */
  /** @typedef {{ resolveForRoot(rootEl: Element): unknown }} DyniLoaderThemeTokens */
  /** @typedef {{ tokens: DyniLoaderThemeTokens }} DyniLoaderTheme */
  /** @typedef {{ components: DyniLoaderComponentDependencies, theme: DyniLoaderTheme, format: DyniRuntimeNamespace["format"], canvas: DyniRuntimeNamespace["canvas"], dom: DyniRuntimeNamespace["dom"], hostActions: DyniRuntimeNamespace["hostActions"] }} DyniLoaderComponentContext */
  /** @typedef {{ widget: string }} DyniLoaderWidgetReference */
  /** @typedef {{ loadComponent(id: string): Promise<unknown>, uniqueComponents(definitions: DyniLoaderWidgetReference[]): string[], areComponentsLoaded(ids: unknown): boolean, createInstance(id: string, definition: DyniWidgetDefinitionData): unknown }} DyniLoader */
  /** @typedef {DyniRuntimeNamespace & { createAssetPreloader: (baseUrl: string) => DyniAssetPreloader, loadScriptOnce: (assetId: string, url: string) => Promise<void>, loadCssOnce: (assetId: string, url: string | undefined) => Promise<void>, theme: { tokens: DyniLoaderThemeTokens } }} DyniLoaderRuntime */
  /** @typedef {DyniPluginNamespace & { baseUrl: string, runtime: DyniLoaderRuntime }} DyniLoaderRoot */

  const ns = /** @type {DyniLoaderRoot} */ (root.DyniPlugin);
  const runtime = ns.runtime;
  const createAssetPreloader = runtime.createAssetPreloader;
  const runtimeLoadScriptOnce = runtime.loadScriptOnce;
  const runtimeLoadCssOnce = runtime.loadCssOnce;

  if (typeof createAssetPreloader !== "function") {
    throw new Error("dyninstruments: runtime.createAssetPreloader missing before runtime/component-loader.js load");
  }
  if (typeof runtimeLoadScriptOnce !== "function") {
    throw new Error("dyninstruments: runtime.loadScriptOnce missing before runtime/component-loader.js load");
  }
  if (typeof runtimeLoadCssOnce !== "function") {
    throw new Error("dyninstruments: runtime.loadCssOnce missing before runtime/component-loader.js load");
  }

  const assetPreloader = createAssetPreloader(ns.baseUrl);

  runtime.assetUrl = function (relativePath) {
    return ns.baseUrl + relativePath;
  };
  runtime.getAsset = assetPreloader.getAsset;

  /** @param {DyniComponentRegistryGroup} registry @param {string} id @param {string} methodName @returns {DyniComponentDefinition} */
  function ensureComponent(registry, id, methodName) {
    const componentDef = registry[id];
    if (!componentDef) {
      throw new Error(methodName + ": unknown component '" + id + "'");
    }
    return componentDef;
  }

  /** @param {DyniComponentRegistryGroup} registry @param {string} id @param {string} methodName */
  function ensureNoDependencyCycle(registry, id, methodName) {
    const visiting = Object.create(null);
    const visited = Object.create(null);

    /** @param {string} nodeId @param {string[]} path */
    function walk(nodeId, path) {
      if (visiting[nodeId]) {
        const cycleStart = path.indexOf(nodeId);
        const cyclePath = cycleStart >= 0 ? path.slice(cycleStart).concat(nodeId) : path.concat(nodeId);
        throw new Error(methodName + ": dependency cycle detected (" + cyclePath.join(" -> ") + ")");
      }
      if (visited[nodeId]) {
        return;
      }
      visiting[nodeId] = true;
      const componentDef = ensureComponent(registry, nodeId, methodName);
      const deps = componentDef.deps || [];
      for (let i = 0; i < deps.length; i += 1) {
        walk(deps[i], path.concat(nodeId));
      }
      visiting[nodeId] = false;
      visited[nodeId] = true;
    }

    walk(id, []);
  }

  /** @param {DyniLoaderRuntime} runtimeRef @param {DyniWidgetDefinitionData} def @param {Record<string, unknown>} dependencyInstancesById @param {Record<string, boolean>} declaredDepsByOwner @param {string} ownerId @returns {DyniLoaderComponentContext} */
  function buildComponentContext(runtimeRef, def, dependencyInstancesById, declaredDepsByOwner, ownerId) {
    const themeTokens = Object.freeze({
      /** @param {Element} rootEl */
      resolveForRoot: function (rootEl) {
        return runtimeRef.theme.tokens.resolveForRoot(rootEl);
      }
    });

    return {
      components: {
        require: function (dependencyId) {
          if (!declaredDepsByOwner[dependencyId]) {
            throw new Error(
              "componentContext.components.require: '" +
                ownerId +
                "' requested undeclared dependency '" +
                dependencyId +
                "'"
            );
          }
          return dependencyInstancesById[dependencyId];
        }
      },
      theme: {
        tokens: themeTokens
      },
      format: runtimeRef.format,
      canvas: runtimeRef.canvas,
      dom: runtimeRef.dom,
      // Pass the runtime.hostActions function reference through unchanged so components can snapshot on demand.
      hostActions: runtimeRef.hostActions
    };
  }

  /** @param {DyniComponentRegistryGroup} components @returns {DyniLoader} */
  function createComponentLoader(components) {
    const registry = components;
    const loadCache = new Map();
    const loadedComponents = Object.create(null);

    /** @param {string} componentId @param {DyniComponentDefinition} componentDef @param {unknown} mod @returns {DyniLoaderModule} */
    function validateComponentApi(componentId, componentDef, mod) {
      const apiShape = componentDef.apiShape || "factory";
      if (apiShape === "factory") {
        const factoryModule = /** @type {DyniLoaderFactoryModule | null} */ (mod);
        if (!factoryModule || typeof factoryModule.create !== "function") {
          throw new Error("Component not found or invalid: " + componentDef.globalKey);
        }
        return factoryModule;
      }
      if (apiShape === "module") {
        if (!mod || typeof mod !== "object") {
          throw new Error("Component not found or invalid: " + componentDef.globalKey);
        }
        return /** @type {DyniLoaderModule} */ (mod);
      }
      throw new Error("Unsupported apiShape '" + apiShape + "' for component: " + componentId);
    }

    /** @param {string} id @returns {Promise<unknown>} */
    function loadComponent(id) {
      ensureNoDependencyCycle(registry, id, "loadComponent");

      if (loadCache.has(id)) {
        return loadCache.get(id);
      }

      const componentDef = registry[id];
      if (!componentDef) {
        return Promise.reject(new Error("Unknown component: " + id));
      }

      const deps = componentDef.deps || [];
      const promise = Promise.all(deps.map(loadComponent))
        .then(function () {
          return Promise.all([
            runtimeLoadCssOnce("dyni-css-" + id, componentDef.css),
            runtimeLoadScriptOnce("dyni-js-" + id, componentDef.js)
          ]);
        })
        .then(function () {
          const assetDecls = componentDef.assets || [];
          if (!assetDecls.length) {
            return null;
          }
          return assetPreloader.preloadAssets(assetDecls);
        })
        .then(function () {
          const componentRegistry = root.DyniComponents || {};
          const mod = componentRegistry[componentDef.globalKey];
          const validated = validateComponentApi(id, componentDef, mod);
          loadedComponents[id] = validated;
          return validated;
        })
        .catch(function (error) {
          loadCache.delete(id);
          delete loadedComponents[id];
          throw error;
        });

      loadCache.set(id, promise);
      return promise;
    }

    /** @param {unknown} ids @returns {boolean} */
    function areComponentsLoaded(ids) {
      if (!Array.isArray(ids)) {
        return false;
      }
      for (let i = 0; i < ids.length; i += 1) {
        if (!loadedComponents[ids[i]]) {
          return false;
        }
      }
      return true;
    }

    /** @param {DyniLoaderWidgetReference[]} list @returns {string[]} */
    function uniqueComponents(list) {
      const result = new Set();

      /** @param {string} id */
      function addWithDeps(id) {
        if (!registry[id] || result.has(id)) {
          return;
        }
        result.add(id);
        const deps = registry[id].deps || [];
        for (let i = 0; i < deps.length; i += 1) {
          addWithDeps(deps[i]);
        }
      }

      for (let i = 0; i < list.length; i += 1) {
        addWithDeps(list[i].widget);
      }

      return Array.from(result);
    }

    /** @param {string} id @param {Record<string, boolean>} visited */
    function assertLoadedClosure(id, visited) {
      const componentDef = ensureComponent(registry, id, "createInstance");
      if (!loadedComponents[id]) {
        throw new Error("createInstance: component '" + id + "' is not loaded; call loadComponent('" + id + "') first");
      }
      if (visited[id]) {
        return;
      }
      visited[id] = true;
      const deps = componentDef.deps || [];
      for (let i = 0; i < deps.length; i += 1) {
        assertLoadedClosure(deps[i], visited);
      }
    }

    /** @param {string} id @param {DyniWidgetDefinitionData} def @returns {unknown} */
    function createInstance(id, def) {
      ensureNoDependencyCycle(registry, id, "createInstance");
      assertLoadedClosure(id, Object.create(null));

      const building = Object.create(null);
      const built = Object.create(null);

      /** @param {string} componentId @param {string[]} path @returns {unknown} */
      function instantiate(componentId, path) {
        if (Object.prototype.hasOwnProperty.call(built, componentId)) {
          return built[componentId];
        }
        if (building[componentId]) {
          const cycleStart = path.indexOf(componentId);
          const cyclePath = cycleStart >= 0 ? path.slice(cycleStart).concat(componentId) : path.concat(componentId);
          throw new Error("createInstance: dependency cycle detected (" + cyclePath.join(" -> ") + ")");
        }

        const componentDef = ensureComponent(registry, componentId, "createInstance");
        const moduleApi = loadedComponents[componentId];
        if (!moduleApi) {
          throw new Error(
            "createInstance: component '" +
              componentId +
              "' is not loaded; call loadComponent('" +
              componentId +
              "') first"
          );
        }

        building[componentId] = true;
        const deps = componentDef.deps || [];
        const dependencyInstancesById = Object.create(null);
        const declaredDepsByOwner = Object.create(null);

        for (let i = 0; i < deps.length; i += 1) {
          const depId = deps[i];
          declaredDepsByOwner[depId] = true;
          dependencyInstancesById[depId] = instantiate(depId, path.concat(componentId));
        }

        const apiShape = componentDef.apiShape || "factory";
        let instance;
        if (apiShape === "module") {
          instance = moduleApi;
        } else {
          const componentContext = buildComponentContext(
            runtime,
            def,
            dependencyInstancesById,
            declaredDepsByOwner,
            componentId
          );
          instance = /** @type {DyniLoaderFactoryModule} */ (moduleApi).create(def, componentContext);
        }

        built[componentId] = instance;
        building[componentId] = false;
        return instance;
      }

      return instantiate(id, []);
    }

    return {
      loadComponent: loadComponent,
      uniqueComponents: uniqueComponents,
      areComponentsLoaded: areComponentsLoaded,
      createInstance: createInstance
    };
  }

  runtime.createComponentLoader = createComponentLoader;
})(this);

/**
 * @file DyniPlugin Widget Registrar - Widget definition composition and registration
 * Documentation: documentation/avnav-api/plugin-lifecycle.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const runtime = /** @type {DyniRuntimeNamespace & { getAvnavApi(rootRef: unknown): unknown }} */ (ns.runtime);
  const hasOwn = Object.prototype.hasOwnProperty;
  const LAYOUT_EDITING_HINT_KEY = "dyniLayoutEditing";

  /**
   * @param {unknown} sourceValues
   * @param {unknown} candidate
   * @returns {unknown}
   */
  function applyLayoutEditingHint(sourceValues, candidate) {
    if (!sourceValues || typeof sourceValues !== "object") {
      return candidate;
    }
    if (!hasOwn.call(sourceValues, "editing")) {
      return candidate;
    }
    const source = /** @type {DyniWidgetValues} */ (sourceValues);
    const out = /** @type {DyniWidgetValues} */ (candidate && typeof candidate === "object" ? candidate : {});
    out[LAYOUT_EDITING_HINT_KEY] = source.editing === true;
    return out;
  }

  /**
   * @param {...unknown} updates
   * @returns {DyniWidgetUpdate|undefined}
   */
  function composeUpdates(...updates) {
    const fns = /** @type {DyniWidgetUpdate[]} */ (
      updates.filter(function (fn) {
        return typeof fn === "function";
      })
    );

    if (!fns.length) {
      return undefined;
    }

    return /** @type {DyniWidgetUpdate} */ (
      function (values) {
        const ctx = this;
        const next = fns.reduce(function (acc, fn) {
          const r = fn.call(ctx, acc);
          return r && typeof r === "object" ? /** @type {DyniWidgetValues} */ (r) : acc;
        }, values);
        return applyLayoutEditingHint(values, next);
      }
    );
  }

  /**
   * @param {DyniWidgetComponentSpec} componentSpec
   * @param {DyniWidgetDefinition} widgetDef
   */
  function registerWidget(componentSpec, widgetDef) {
    const spec = componentSpec || {};

    const defaultClass = "dyniplugin";
    const wantsHide = !!spec.wantsHideNativeHead;
    const mergedClassName = Array.from(
      new Set(
        [
          defaultClass,
          "dyni-host-html",
          widgetDef.def.className,
          spec.className,
          wantsHide ? "dyni-hide-native-head" : null
        ].filter(Boolean)
      )
    ).join(" ");

    const storeKeys =
      spec.storeKeys ||
      widgetDef.def.storeKeys ||
      (widgetDef.def.storeKey ? { value: widgetDef.def.storeKey } : undefined);

    const renderHtml = typeof spec.renderHtml === "function" ? spec.renderHtml : undefined;
    const initFunction = typeof spec.initFunction === "function" ? spec.initFunction : undefined;
    const finalizeFunction = typeof spec.finalizeFunction === "function" ? spec.finalizeFunction : undefined;
    const translateFunction = typeof spec.translateFunction === "function" ? spec.translateFunction : undefined;

    const updateFunction = composeUpdates(spec.updateFunction, widgetDef.def.updateFunction);

    /** @param {DyniWidgetValues} ctx */
    function attachHostActions(ctx) {
      // Snapshot the current host action facade for this wrapped lifecycle call.
      ctx.hostActions = typeof runtime.hostActions === "function" ? runtime.hostActions() : null;
    }

    /** @param {unknown} fn @returns {DyniWidgetLifecycle|undefined} */
    function wrapWidgetContext(fn) {
      if (!fn) {
        return undefined;
      }
      const lifecycle = /** @type {DyniWidgetLifecycle} */ (fn);
      /**
       * @this {DyniWidgetValues}
       * @param {...unknown} args
       * @returns {unknown}
       */
      return function (...args) {
        attachHostActions(this);
        return lifecycle.apply(this, args);
      };
    }

    const defaultsFn = runtime.defaultsFromEditableParams;
    const perInstrumentDefaults = typeof defaultsFn === "function" ? defaultsFn(widgetDef.def.editableParameters) : {};
    const editableFn = runtime.editableParamsForRegistration;

    const baseDef = /** @type {Record<string, unknown>} */ ({
      name: widgetDef.def.name,
      description: hasOwn.call(widgetDef.def, "description") ? widgetDef.def.description : widgetDef.def.name,
      caption: hasOwn.call(widgetDef.def, "caption") ? widgetDef.def.caption : "",
      unit: hasOwn.call(widgetDef.def, "unit") ? widgetDef.def.unit : "",
      default: widgetDef.def.default,
      storeKeys: storeKeys,
      className: mergedClassName,

      cluster: widgetDef.def.cluster,
      ...perInstrumentDefaults,

      renderHtml: wrapWidgetContext(renderHtml),
      initFunction: wrapWidgetContext(initFunction),
      finalizeFunction: wrapWidgetContext(finalizeFunction),
      translateFunction: translateFunction,
      updateFunction: updateFunction
    });

    const editable =
      typeof editableFn === "function"
        ? editableFn(widgetDef.def.editableParameters)
        : widgetDef.def.editableParameters || {};
    const avnavApi =
      /** @type {DyniAvnavApi & { registerWidget(definition: Record<string, unknown>, editable: Record<string, unknown>): void }} */ (
        runtime.getAvnavApi(root)
      );
    avnavApi.registerWidget(baseDef, editable);
  }

  runtime.registerWidget = registerWidget;
})(this);

/**
 * @file DyniPlugin HostCommitController - Deferred host commit scheduling for HTML shell mounting
 * Documentation: documentation/architecture/component-system.md
 */
(function (root) {
  "use strict";

  const ns = /** @type {DyniPluginNamespace & { runtime: DyniHostRuntime }} */ (root.DyniPlugin);
  const runtime = ns.runtime;
  const hasOwn = Object.prototype.hasOwnProperty;
  const MAX_RAF_ATTEMPTS = 4;
  const OBSERVER_TIMEOUT_MS = 2000;

  let instanceCounter = 0;

  /** @param {string} prefix @returns {string} */
  function nextInstanceId(prefix) {
    instanceCounter += 1;
    return prefix + String(instanceCounter);
  }

  /** @param {string} instanceId @returns {DyniHostCommitState} */
  function createState(instanceId) {
    return {
      instanceId: instanceId,
      renderRevision: 0,
      mountedRevision: 0,
      lastProps: undefined,
      rootEl: null,
      shellEl: null,
      scheduledRevision: null,
      rafHandle: null,
      observer: null,
      timeoutHandle: null,
      commitPending: false
    };
  }

  /** @param {DyniHostCommitControllerOptions} options @returns {DyniHostCommitControllerApi} */
  function createHostCommitController(options) {
    const opts = /** @type {DyniHostCommitControllerOptions} */ (options || {});
    const instancePrefix =
      typeof opts.instancePrefix === "string" && opts.instancePrefix ? opts.instancePrefix : "dyni-host-";
    const doc = opts.document || root.document || null;
    const requestFrame =
      typeof opts.requestAnimationFrame === "function"
        ? opts.requestAnimationFrame
        : typeof root.requestAnimationFrame === "function"
          ? root.requestAnimationFrame.bind(root)
          : function (/** @type {() => void} */ cb) {
              return root.setTimeout(cb, 16);
            };
    const cancelFrame =
      typeof opts.cancelAnimationFrame === "function"
        ? opts.cancelAnimationFrame
        : typeof root.cancelAnimationFrame === "function"
          ? root.cancelAnimationFrame.bind(root)
          : function (/** @type {number} */ handle) {
              root.clearTimeout(handle);
            };
    const setTimer = typeof opts.setTimeout === "function" ? opts.setTimeout : root.setTimeout.bind(root);
    const clearTimer = typeof opts.clearTimeout === "function" ? opts.clearTimeout : root.clearTimeout.bind(root);
    const MutationObserverCtor = hasOwn.call(opts, "MutationObserver") ? opts.MutationObserver : root.MutationObserver;

    /** @type {DyniHostCommitState} */
    let state = createState(nextInstanceId(instancePrefix));
    /** @type {DyniHostCommitState | null} */
    let stateSnapshot = null;
    let stateSnapshotDirty = true;
    function markStateSnapshotDirty() {
      stateSnapshotDirty = true;
    }

    /** @param {keyof DyniHostCommitState} key @param {unknown} value */
    function setStateField(key, value) {
      if (state[key] === value) {
        return;
      }
      /** @type {Record<string, unknown>} */ (/** @type {unknown} */ (state))[key] = value;
      markStateSnapshotDirty();
    }

    /** @returns {DyniHostCommitState} */
    function getState() {
      if (!stateSnapshotDirty && stateSnapshot) {
        return stateSnapshot;
      }
      stateSnapshot = {
        instanceId: state.instanceId,
        renderRevision: state.renderRevision,
        mountedRevision: state.mountedRevision,
        lastProps: state.lastProps,
        rootEl: state.rootEl,
        shellEl: state.shellEl,
        scheduledRevision: state.scheduledRevision,
        rafHandle: state.rafHandle,
        observer: state.observer,
        timeoutHandle: state.timeoutHandle,
        commitPending: state.commitPending
      };
      stateSnapshotDirty = false;
      return stateSnapshot;
    }

    function clearRafHandle() {
      if (state.rafHandle === null || state.rafHandle === undefined) {
        return;
      }
      cancelFrame(state.rafHandle);
      setStateField("rafHandle", null);
    }

    function clearObserver() {
      if (!state.observer) {
        return;
      }
      state.observer.disconnect();
      setStateField("observer", null);
    }

    function clearTimeoutHandle() {
      if (state.timeoutHandle === null || state.timeoutHandle === undefined) {
        return;
      }
      clearTimer(state.timeoutHandle);
      setStateField("timeoutHandle", null);
    }

    function clearAsyncHandles() {
      clearRafHandle();
      clearObserver();
      clearTimeoutHandle();
    }

    function clearPendingState() {
      setStateField("commitPending", false);
      setStateField("scheduledRevision", null);
    }

    /** @returns {Element | null} */
    function resolveShellElement() {
      if (!doc || typeof doc.querySelector !== "function") {
        return null;
      }
      const selector = '.widgetData.dyni-shell[data-dyni-instance="' + state.instanceId + '"]';
      return doc.querySelector(selector);
    }

    /** @param {Element | null} shellEl @returns {Element | null} */
    function resolveRootElement(shellEl) {
      if (!shellEl || typeof shellEl.closest !== "function") {
        return null;
      }
      const rootEl = shellEl.closest(".widget.dyniplugin");
      if (!rootEl || !rootEl.classList) {
        return null;
      }
      if (!rootEl.classList.contains("dyniplugin")) {
        return null;
      }
      if (!rootEl.classList.contains("dyni-host-html")) {
        return null;
      }
      return rootEl;
    }

    /** @param {number} targetRevision @param {DyniHostCommitCallbacks} callbacks @returns {boolean} */
    function commitIfReady(targetRevision, callbacks) {
      if (targetRevision !== state.renderRevision) {
        clearAsyncHandles();
        clearPendingState();
        return true;
      }

      const shellEl = resolveShellElement();
      if (!shellEl) {
        return false;
      }

      const rootEl = resolveRootElement(shellEl);
      if (!rootEl) {
        return false;
      }

      clearAsyncHandles();
      setStateField("shellEl", shellEl);
      setStateField("rootEl", rootEl);
      setStateField("mountedRevision", targetRevision);
      clearPendingState();

      if (callbacks && typeof callbacks.onCommit === "function") {
        callbacks.onCommit({
          instanceId: state.instanceId,
          revision: targetRevision,
          props: state.lastProps,
          rootEl: rootEl,
          shellEl: shellEl,
          state: getState()
        });
      }
      return true;
    }

    /** @param {number} targetRevision @param {DyniHostCommitCallbacks} callbacks */
    function installDeferredObservers(targetRevision, callbacks) {
      if (!MutationObserverCtor || typeof MutationObserverCtor !== "function") {
        setStateField(
          "timeoutHandle",
          setTimer(function () {
            commitIfReady(targetRevision, callbacks);
          }, 0)
        );
        return;
      }

      if (!state.observer) {
        const observer = new MutationObserverCtor(function () {
          commitIfReady(targetRevision, callbacks);
        });
        setStateField("observer", observer);
        if (doc && doc.body) {
          observer.observe(doc.body, { childList: true, subtree: true });
        }
      }

      if (state.timeoutHandle === null || state.timeoutHandle === undefined) {
        setStateField(
          "timeoutHandle",
          setTimer(function () {
            if (commitIfReady(targetRevision, callbacks)) {
              return;
            }
            clearAsyncHandles();
            clearPendingState();
          }, OBSERVER_TIMEOUT_MS)
        );
      }
    }

    /** @param {number} targetRevision @param {DyniHostCommitCallbacks} callbacks @param {number} attempt */
    function scheduleRafAttempt(targetRevision, callbacks, attempt) {
      setStateField(
        "rafHandle",
        requestFrame(function () {
          setStateField("rafHandle", null);

          if (commitIfReady(targetRevision, callbacks)) {
            return;
          }

          if (attempt < MAX_RAF_ATTEMPTS) {
            scheduleRafAttempt(targetRevision, callbacks, attempt + 1);
            return;
          }

          installDeferredObservers(targetRevision, callbacks);
        })
      );
    }

    function initState() {
      clearAsyncHandles();
      clearPendingState();
      state = createState(nextInstanceId(instancePrefix));
      markStateSnapshotDirty();
      return getState();
    }

    /** @param {unknown} props @returns {number} */
    function recordRender(props) {
      setStateField("lastProps", props);
      setStateField("renderRevision", state.renderRevision + 1);
      return state.renderRevision;
    }

    /** @param {DyniHostCommitCallbacks} callbacks @returns {boolean} */
    function scheduleCommit(callbacks) {
      const targetRevision = state.renderRevision;

      if (state.commitPending && state.scheduledRevision === targetRevision) {
        return false;
      }

      if (state.commitPending) {
        clearAsyncHandles();
        clearPendingState();
      }

      setStateField("commitPending", true);
      setStateField("scheduledRevision", targetRevision);
      scheduleRafAttempt(targetRevision, callbacks || {}, 1);
      return true;
    }

    function cleanup() {
      clearAsyncHandles();
      clearPendingState();
      setStateField("rootEl", null);
      setStateField("shellEl", null);
    }

    return {
      initState: initState,
      recordRender: recordRender,
      scheduleCommit: scheduleCommit,
      cleanup: cleanup,
      getState: getState
    };
  }

  runtime.createHostCommitController = createHostCommitController;
})(this);

/**
 * @file DyniPlugin SurfaceSessionController - Surface lifecycle state machine for attach/update/detach transitions
 * Documentation: documentation/architecture/surface-session-controller.md
 */
(function (root) {
  "use strict";

  /** @typedef {"html" | "canvas-dom"} DyniSessionSurface */
  /** @typedef {{ surface: DyniSessionSurface, revision: number, rootEl: unknown, shellEl: unknown, routeId: string, rendererId: string, rendererSpec: Record<string, unknown>, hostContext: Record<string, unknown>, props: Record<string, unknown>, shadowCssUrls?: unknown }} DyniSessionPayload */
  /** @typedef {{ attach: (payload: DyniSessionPayload) => void, update: (payload: DyniSessionPayload) => void, detach: (reason: string) => void, destroy: () => void }} DyniSessionSurfaceController */
  /** @typedef {{ createController: (options: DyniSurfaceControllerOptions) => DyniSessionSurfaceController }} DyniSessionSurfaces */
  /** @typedef {{ mountedRouteId: string | null, mountedRendererId: string | null, mountedSurface: DyniSessionSurface | null, mountedRevision: number, committedRevisionFloor: number, activeController: DyniSessionSurfaceController | null, shellEl: unknown }} DyniSessionState */
  /** @typedef {{ surfaces: DyniSessionSurfaces }} DyniSessionControllerOptions */

  const ns = /** @type {DyniPluginNamespace} */ (root.DyniPlugin);
  const runtime = /** @type {DyniRuntimeNamespace} */ (ns.runtime);
  const SUPPORTED_SURFACES = {
    html: true,
    "canvas-dom": true
  };

  /** @param {unknown} surfaces @returns {asserts surfaces is DyniSessionSurfaces} */
  function ensureSurfacesService(surfaces) {
    if (!surfaces || typeof surfaces !== "object") {
      throw new Error("SurfaceSessionController: surfaces service must be an object");
    }
    const service = /** @type {DyniSessionSurfaces} */ (surfaces);
    if (typeof service.createController !== "function") {
      throw new Error("SurfaceSessionController: surfaces.createController must be a function");
    }
  }

  /** @param {unknown} surface @returns {asserts surface is DyniSessionSurface} */
  function ensureSurface(surface) {
    const surfaceName = /** @type {string} */ (surface);
    if (!Object.prototype.hasOwnProperty.call(SUPPORTED_SURFACES, surfaceName)) {
      throw new Error("SurfaceSessionController: unsupported surface '" + String(surface) + "'");
    }
  }

  /** @param {unknown} payload @returns {asserts payload is DyniSessionPayload} */
  function ensurePayload(payload) {
    if (!payload || typeof payload !== "object") {
      throw new Error("SurfaceSessionController: reconcileSession requires a payload object");
    }
    const sessionPayload = /** @type {DyniSessionPayload} */ (payload);
    if (!Number.isFinite(sessionPayload.revision)) {
      throw new Error("SurfaceSessionController: reconcileSession payload requires a finite revision");
    }
    if (!sessionPayload.rootEl) {
      throw new Error("SurfaceSessionController: reconcileSession payload requires rootEl");
    }
    if (!sessionPayload.shellEl) {
      throw new Error("SurfaceSessionController: reconcileSession payload requires shellEl");
    }
    if (typeof sessionPayload.routeId !== "string" || !sessionPayload.routeId) {
      throw new Error("SurfaceSessionController: reconcileSession payload requires routeId");
    }
    if (typeof sessionPayload.rendererId !== "string" || !sessionPayload.rendererId) {
      throw new Error("SurfaceSessionController: reconcileSession payload requires rendererId");
    }
    if (!sessionPayload.rendererSpec || typeof sessionPayload.rendererSpec !== "object") {
      throw new Error("SurfaceSessionController: reconcileSession payload requires rendererSpec");
    }
    if (!sessionPayload.hostContext || typeof sessionPayload.hostContext !== "object") {
      throw new Error("SurfaceSessionController: reconcileSession payload requires hostContext");
    }
    if (!sessionPayload.props || typeof sessionPayload.props !== "object") {
      throw new Error("SurfaceSessionController: reconcileSession payload requires props object");
    }
  }

  /** @param {unknown} controller @param {DyniSessionSurface} surface @returns {asserts controller is DyniSessionSurfaceController} */
  function ensureController(controller, surface) {
    if (!controller || typeof controller !== "object") {
      throw new Error(
        "SurfaceSessionController: runtime.surfaces.createController('" + surface + "') returned an invalid controller"
      );
    }

    const surfaceController = /** @type {Record<string, unknown>} */ (controller);
    const requiredMethods = ["attach", "update", "detach", "destroy"];
    for (let i = 0; i < requiredMethods.length; i++) {
      const methodName = requiredMethods[i];
      if (typeof surfaceController[methodName] !== "function") {
        throw new Error("SurfaceSessionController: controller '" + surface + "' must implement " + methodName + "()");
      }
    }
  }

  /** @returns {DyniSessionState} */
  function createInitialState() {
    return {
      mountedRouteId: null,
      mountedRendererId: null,
      mountedSurface: null,
      mountedRevision: 0,
      committedRevisionFloor: 0,
      activeController: null,
      shellEl: null
    };
  }

  /** @param {DyniSessionControllerOptions | undefined} options */
  function createSurfaceSessionController(options) {
    const opts = /** @type {DyniSessionControllerOptions} */ (options || {});
    const surfaces = opts.surfaces;
    ensureSurfacesService(surfaces);

    let state = createInitialState();

    /** @returns {DyniSessionState} */
    function getState() {
      return {
        mountedRouteId: state.mountedRouteId,
        mountedRendererId: state.mountedRendererId,
        mountedSurface: state.mountedSurface,
        mountedRevision: state.mountedRevision,
        committedRevisionFloor: state.committedRevisionFloor,
        activeController: state.activeController,
        shellEl: state.shellEl
      };
    }

    /** @returns {DyniSessionState} */
    function initState() {
      state = createInitialState();
      return getState();
    }

    /** @param {unknown} revision @returns {boolean} */
    function isCurrentRevision(revision) {
      return Number.isFinite(revision) && revision === state.mountedRevision;
    }

    /** @param {unknown} revision @returns {number} */
    function recordCommittedRevision(revision) {
      if (!Number.isFinite(revision)) {
        throw new Error("SurfaceSessionController: recordCommittedRevision requires a finite revision");
      }
      const numericRevision = /** @type {number} */ (revision);
      if (numericRevision > state.committedRevisionFloor) {
        state.committedRevisionFloor = numericRevision;
      }
      return state.committedRevisionFloor;
    }

    /** @param {DyniSessionPayload} payload @returns {DyniSessionSurfaceController} */
    function createControllerForPayload(payload) {
      const controller = surfaces.createController({
        surface: payload.surface,
        rendererSpec: payload.rendererSpec,
        hostContext: payload.hostContext,
        shadowCssUrls: payload.shadowCssUrls
      });
      ensureController(controller, payload.surface);
      return controller;
    }

    /** @param {DyniSessionPayload} payload */
    function applyMountedState(payload) {
      state.mountedRouteId = payload.routeId;
      state.mountedRendererId = payload.rendererId;
      state.mountedSurface = payload.surface;
      state.mountedRevision = payload.revision;
      state.shellEl = payload.shellEl;
    }

    /** @returns {void} */
    function detachForShellReplacement() {
      if (!state.activeController) {
        return;
      }
      state.activeController.detach("shell-replacement");
      state.shellEl = null;
    }

    /** @param {unknown} payload @returns {boolean} */
    function reconcileSession(payload) {
      ensurePayload(payload);
      if (payload.revision < state.committedRevisionFloor || payload.revision < state.mountedRevision) {
        return false;
      }

      ensureSurface(payload.surface);

      const mountedController = state.activeController;
      const sameSurface = !!mountedController && state.mountedSurface === payload.surface;
      const sameRoute = sameSurface && state.mountedRouteId === payload.routeId;
      const sameRenderer = sameSurface && state.mountedRendererId === payload.rendererId;
      const sameShell = sameSurface && state.shellEl === payload.shellEl;

      if (!mountedController) {
        const firstController = createControllerForPayload(payload);
        firstController.attach(payload);
        state.activeController = firstController;
        applyMountedState(payload);
        return true;
      }

      if (sameSurface && sameRoute && sameRenderer && sameShell) {
        mountedController.update(payload);
        applyMountedState(payload);
        return true;
      }

      if (sameSurface && sameRoute && sameRenderer) {
        mountedController.detach("remount");
        mountedController.attach(payload);
        applyMountedState(payload);
        return true;
      }

      if (sameSurface) {
        mountedController.destroy();

        const nextController = createControllerForPayload(payload);
        nextController.attach(payload);
        state.activeController = nextController;
        applyMountedState(payload);
        return true;
      }

      mountedController.detach("surface-switch");
      mountedController.destroy();

      const nextController = createControllerForPayload(payload);
      nextController.attach(payload);
      state.activeController = nextController;
      applyMountedState(payload);
      return true;
    }

    /** @returns {DyniSessionState} */
    function destroy() {
      if (state.activeController) {
        state.activeController.destroy();
      }
      state = createInitialState();
      return getState();
    }

    return {
      initState: initState,
      recordCommittedRevision: recordCommittedRevision,
      reconcileSession: reconcileSession,
      detachForShellReplacement: detachForShellReplacement,
      isCurrentRevision: isCurrentRevision,
      destroy: destroy,
      getState: getState
    };
  }

  /** @type {DyniRuntimeNamespace & Record<string, unknown>} */ (runtime).createSurfaceSessionController =
    createSurfaceSessionController;
})(this);

/**
 * @file DyniPlugin TemporaryHostActionBridgeDiscovery - React-fiber lookup helpers for bridge dispatch
 * Documentation: documentation/avnav-api/plugin-lifecycle.md
 */
(function (root) {
  "use strict";

  /** @typedef {(event: unknown) => unknown} DyniHostDispatchHandler */
  /** @typedef {{ memoizedProps?: Record<string, unknown>, pendingProps?: Record<string, unknown>, return?: DyniHostReactFiber | null }} DyniHostReactFiber */
  /** @typedef {{ type: "click", avnav: Record<string, unknown>, stopPropagation: () => void, preventDefault: () => void }} DyniHostSyntheticEvent */
  /** @typedef {{ detectPageId: () => string, findPageDispatchHandler: (pageId: string, propNames?: string[]) => DyniHostDispatchHandler | null, dispatchPageAction: (actionName: string, pageId: string, avnavData: Record<string, unknown>, propNames: string[], missingLabel: string) => boolean, hasAlarmDispatch: () => boolean, dispatchAlarmStopAll: () => boolean }} DyniHostActionDiscoveryApi */

  const ns = /** @type {DyniPluginNamespace} */ (root.DyniPlugin);
  const runtime = /** @type {DyniRuntimeNamespace} */ (ns.runtime);
  const PAGE_IDS = ["editroutepage", "gpspage", "navpage"];

  /** @param {unknown} obj @param {string} key @returns {boolean} */
  function hasOwn(obj, key) {
    return !!obj && Object.prototype.hasOwnProperty.call(obj, key);
  }

  /** @param {unknown} obj @returns {string[]} */
  function getOwnPropertyNamesSafe(obj) {
    if (!obj || (typeof obj !== "object" && typeof obj !== "function")) {
      return [];
    }
    try {
      return Object.getOwnPropertyNames(obj);
    } catch (err) {
      return [];
    }
  }

  /** @param {unknown} obj @param {string} prefix @returns {string | null} */
  function findObjectKeyByPrefix(obj, prefix) {
    const keys = getOwnPropertyNamesSafe(obj);
    for (let i = 0; i < keys.length; i += 1) {
      if (keys[i].indexOf(prefix) === 0) {
        return keys[i];
      }
    }
    return null;
  }

  /** @param {Element|null|undefined} element @returns {DyniHostReactFiber | null} */
  function getReactFiber(element) {
    if (!element) {
      return null;
    }
    const fiberKey = findObjectKeyByPrefix(element, "__reactFiber$");
    const dynamicElement = /** @type {Record<string, unknown>} */ (/** @type {unknown} */ (element));
    if (fiberKey && dynamicElement[fiberKey]) {
      return /** @type {DyniHostReactFiber} */ (dynamicElement[fiberKey]);
    }
    const containerKey = findObjectKeyByPrefix(element, "__reactContainer$");
    return containerKey ? /** @type {DyniHostReactFiber} */ (dynamicElement[containerKey]) : null;
  }

  /** @param {Element|null|undefined} element @param {string[]|undefined} propNameList @returns {DyniHostDispatchHandler | null} */
  function findFiberProp(element, propNameList) {
    let currentElement = element;
    const propNames = Array.isArray(propNameList) && propNameList.length > 0 ? propNameList : ["onItemClick"];

    while (currentElement) {
      let fiber = getReactFiber(currentElement);
      while (fiber) {
        const props = fiber.memoizedProps || fiber.pendingProps;
        if (props) {
          for (let i = 0; i < propNames.length; i += 1) {
            const propName = propNames[i];
            if (hasOwn(props, propName) && typeof props[propName] === "function") {
              return /** @type {DyniHostDispatchHandler} */ (props[propName]);
            }
          }
        }
        fiber = fiber.return || null;
      }
      currentElement = currentElement.parentElement || null;
    }
    return null;
  }

  /** @param {Element|null|undefined} pageRoot @returns {Element[]} */
  function collectDispatchTargets(pageRoot) {
    const targets = [];
    if (pageRoot) {
      targets.push(pageRoot);
      if (typeof pageRoot.querySelectorAll === "function") {
        const descendants = pageRoot.querySelectorAll(".widgetContainer, .listContainer");
        for (let i = 0; i < descendants.length; i += 1) {
          targets.push(descendants[i]);
        }
      }
    }
    return targets;
  }

  /** @param {Record<string, unknown>|undefined} avnavData @returns {DyniHostSyntheticEvent} */
  function createSyntheticEvent(avnavData) {
    return {
      type: "click",
      avnav: avnavData || {},
      stopPropagation: function () {},
      preventDefault: function () {}
    };
  }

  /** @param {string} pageId @param {Document|null|undefined} doc @returns {HTMLElement | null} */
  function getPageRoot(pageId, doc) {
    if (!doc || typeof doc.getElementById !== "function" || pageId === "other") {
      return null;
    }
    return doc.getElementById(pageId);
  }

  /** @param {Document|null|undefined} doc @returns {string} */
  function detectPageId(doc) {
    for (let i = 0; i < PAGE_IDS.length; i += 1) {
      if (getPageRoot(PAGE_IDS[i], doc)) {
        return PAGE_IDS[i];
      }
    }
    return "other";
  }

  /** @param {string} pageId @param {Document|null|undefined} doc @param {string[]|undefined} propNames @returns {DyniHostDispatchHandler | null} */
  function findPageDispatchHandler(pageId, doc, propNames) {
    const pageRoot = getPageRoot(pageId, doc);
    const targets = collectDispatchTargets(pageRoot);
    for (let i = 0; i < targets.length; i += 1) {
      const handler = findFiberProp(targets[i], propNames);
      if (typeof handler === "function") {
        return handler;
      }
    }
    return null;
  }

  /** @param {Element|null|undefined} element @returns {boolean} */
  function isVisibleElement(element) {
    if (!element) {
      return false;
    }
    if (typeof element.getClientRects === "function") {
      const rects = element.getClientRects();
      if (rects && typeof rects.length === "number") {
        return rects.length > 0;
      }
    }
    const htmlElement = /** @type {HTMLElement} */ (element);
    if (typeof htmlElement.offsetWidth === "number" && typeof htmlElement.offsetHeight === "number") {
      return htmlElement.offsetWidth > 0 || htmlElement.offsetHeight > 0;
    }
    return true;
  }

  /** @param {Document|null|undefined} doc @returns {Element[]} */
  function collectAlarmCandidates(doc) {
    if (!doc || typeof doc.querySelectorAll !== "function") {
      return [];
    }
    try {
      const found = doc.querySelectorAll(".alarmWidget");
      return /** @type {Element[]} */ (Array.prototype.slice.call(found));
    } catch (err) {
      return [];
    }
  }

  /** @param {Document|null|undefined} doc @returns {DyniHostDispatchHandler | null} */
  function findAlarmClickHandler(doc) {
    const candidates = collectAlarmCandidates(doc);
    for (let i = 0; i < candidates.length; i += 1) {
      if (!isVisibleElement(candidates[i])) {
        continue;
      }
      const handler = findFiberProp(candidates[i], ["onClick", "widgetClick"]);
      if (typeof handler === "function") {
        return handler;
      }
    }
    for (let i = 0; i < candidates.length; i += 1) {
      const handler = findFiberProp(candidates[i], ["onClick", "widgetClick"]);
      if (typeof handler === "function") {
        return handler;
      }
    }
    return null;
  }

  /** @param {unknown} rootRef @param {(message: string) => Error} createBridgeError @returns {DyniHostActionDiscoveryApi} */
  function create(rootRef, createBridgeError) {
    const rootWithDocument = /** @type {{ document?: Document } | null | undefined} */ (rootRef);
    const doc =
      rootWithDocument && rootWithDocument.document
        ? rootWithDocument.document
        : /** @type {Document | null} */ (rootRef);

    /** @param {string} actionName @param {string} pageId @param {Record<string, unknown>} avnavData @param {string[]} propNames @param {string} missingLabel @returns {true} */
    function dispatchPageAction(actionName, pageId, avnavData, propNames, missingLabel) {
      const handler = findPageDispatchHandler(pageId, doc, propNames);
      if (typeof handler !== "function") {
        throw createBridgeError(actionName + " missing host " + missingLabel + " handler on " + pageId);
      }
      handler(createSyntheticEvent(avnavData));
      return true;
    }

    function dispatchAlarmStopAll() {
      const handler = findAlarmClickHandler(doc);
      if (typeof handler !== "function") {
        throw createBridgeError("alarm.stopAll missing native .alarmWidget click path");
      }
      handler(createSyntheticEvent({}));
      return true;
    }

    return {
      detectPageId: function () {
        return detectPageId(doc);
      },
      findPageDispatchHandler: function (pageId, propNames) {
        return findPageDispatchHandler(pageId, doc, propNames);
      },
      dispatchPageAction: dispatchPageAction,
      hasAlarmDispatch: function () {
        return typeof findAlarmClickHandler(doc) === "function";
      },
      dispatchAlarmStopAll: dispatchAlarmStopAll
    };
  }

  /** @type {DyniRuntimeNamespace & Record<string, unknown>} */ (runtime).createTemporaryHostActionBridgeDiscovery =
    /** @type {(rootRef: unknown, createBridgeError: (message: string) => Error) => DyniHostActionDiscoveryApi} */ (
      function (rootRef, createBridgeError) {
        return create(rootRef, createBridgeError);
      }
    );
})(this);

/**
 * @file DyniPlugin TemporaryHostActionBridge - Temporary runtime facade for host-owned workflow dispatch
 * Documentation: documentation/avnav-api/plugin-lifecycle.md
 */
(function (root) {
  "use strict";

  const ns = /** @type {DyniPluginNamespace & { runtime: DyniTemporaryBridgeRuntime }} */ (root.DyniPlugin);
  const runtime = ns.runtime;
  const valueMathModule = /** @type {{ create(): DyniValueMathApi }} */ (
    /** @type {unknown} */ (root.DyniComponents && root.DyniComponents.DyniValueMath)
  );
  const valueMath = valueMathModule.create();
  const isNullish = valueMath.isNullish;

  /** @param {string} message @returns {Error} */
  function createBridgeError(message) {
    const error = new Error("TemporaryHostActionBridge: " + message);
    error.name = "TemporaryHostActionBridgeError";
    return error;
  }

  const toOptionalFiniteNumber = valueMath.toOptionalFiniteNumber;

  /** @param {unknown} index @returns {number} */
  function normalizeRoutePointIndex(index) {
    const normalized = toOptionalFiniteNumber(index);
    if (typeof normalized !== "number" || !Number.isInteger(normalized) || normalized < 0) {
      throw createBridgeError("routePoints.activate requires a non-negative integer index");
    }
    return normalized;
  }

  /** @param {unknown} payload @returns {{ index: number, pointSnapshot: Record<string, unknown> }} */
  function normalizeRoutePointActivationPayload(payload) {
    if (!payload || typeof payload !== "object") {
      throw createBridgeError("routePoints.activate requires payload { index, pointSnapshot }");
    }
    const input = /** @type {Record<string, unknown>} */ (payload);
    if (!input.pointSnapshot || typeof input.pointSnapshot !== "object") {
      throw createBridgeError("routePoints.activate requires pointSnapshot payload");
    }
    return {
      index: normalizeRoutePointIndex(input.index),
      pointSnapshot: /** @type {Record<string, unknown>} */ (input.pointSnapshot)
    };
  }

  /** @param {unknown} pointSnapshot @returns {DyniTemporaryRoutePointSnapshot} */
  function buildEditRoutePointPayload(pointSnapshot) {
    if (!pointSnapshot || typeof pointSnapshot !== "object") {
      throw createBridgeError("routePoints.activate requires pointSnapshot on editroutepage");
    }
    const input = /** @type {Record<string, unknown>} */ (pointSnapshot);
    if (!Object.prototype.hasOwnProperty.call(input, "idx")) {
      throw createBridgeError("routePoints.activate requires pointSnapshot.idx on editroutepage");
    }

    const idx = normalizeRoutePointIndex(input.idx);
    const lat = toOptionalFiniteNumber(input.lat);
    const lon = toOptionalFiniteNumber(input.lon);

    if (typeof lat !== "number" || typeof lon !== "number") {
      throw createBridgeError("routePoints.activate requires finite pointSnapshot.lat/lon on editroutepage");
    }

    if (!Object.prototype.hasOwnProperty.call(input, "routeName")) {
      throw createBridgeError("routePoints.activate requires pointSnapshot.routeName on editroutepage");
    }

    const hostPoint = /** @type {DyniTemporaryRoutePointSnapshot} */ ({
      idx: idx,
      name: isNullish(input.name) ? "" : String(input.name).trim(),
      lat: lat,
      lon: lon,
      routeName: isNullish(input.routeName) ? "" : String(input.routeName).trim()
    });

    if (Object.prototype.hasOwnProperty.call(input, "course")) {
      const course = toOptionalFiniteNumber(input.course);
      if (typeof course === "number") {
        hostPoint.course = course;
      }
    }
    if (Object.prototype.hasOwnProperty.call(input, "distance")) {
      const distance = toOptionalFiniteNumber(input.distance);
      if (typeof distance === "number") {
        hostPoint.distance = distance;
      }
    }
    if (Object.prototype.hasOwnProperty.call(input, "selected")) {
      hostPoint.selected = input.selected === true;
    }

    return hostPoint;
  }

  /** @param {unknown} mmsi @returns {string} */
  function normalizeMmsi(mmsi) {
    if (typeof mmsi === "number" && Number.isFinite(mmsi)) {
      return String(Math.trunc(mmsi));
    }
    if (typeof mmsi === "string" && mmsi.trim()) {
      return mmsi.trim();
    }
    throw createBridgeError("ais.showInfo requires a target mmsi");
  }

  /** @param {unknown} rootRef */
  function create(rootRef) {
    const discovery = runtime.createTemporaryHostActionBridgeDiscovery(rootRef, createBridgeError);
    let destroyed = false;
    /** @type {DyniTemporaryHostActions | null} */
    let cachedFacade = null;
    /** @type {string | null} */
    let cachedCapabilitiesKey = null;
    /** @type {DyniTemporaryCapabilities | null} */
    let cachedCapabilitiesSnapshot = null;

    function ensureActive() {
      if (destroyed) {
        throw createBridgeError("bridge was destroyed");
      }
    }

    /** @returns {DyniTemporaryRoutePointsApi | null | undefined} */
    function getRoutePointsApi() {
      const avnavApi = /** @type {DyniTemporaryAvnavApi | null} */ (
        /** @type {unknown} */ (runtime.getAvnavApi(rootRef))
      );
      return avnavApi && avnavApi.routePoints;
    }

    /** @param {DyniTemporaryCapabilities} snapshot @returns {DyniTemporaryCapabilities} */
    function freezeCapabilitiesSnapshot(snapshot) {
      if (!snapshot || typeof snapshot !== "object") {
        return snapshot;
      }
      if (snapshot.routePoints) {
        Object.freeze(snapshot.routePoints);
      }
      if (snapshot.map) {
        Object.freeze(snapshot.map);
      }
      if (snapshot.routeEditor) {
        Object.freeze(snapshot.routeEditor);
      }
      if (snapshot.ais) {
        Object.freeze(snapshot.ais);
      }
      if (snapshot.alarm) {
        Object.freeze(snapshot.alarm);
      }
      return Object.freeze(snapshot);
    }

    /** @param {string} pageId @param {boolean} hasRoutePointsRelay @param {boolean} hasEditRouteParityDispatch @param {boolean} hasAlarmDispatch @returns {DyniTemporaryCapabilities} */
    function buildCapabilitiesSnapshot(pageId, hasRoutePointsRelay, hasEditRouteParityDispatch, hasAlarmDispatch) {
      let openActiveRoute;
      if (pageId === "navpage") {
        openActiveRoute = "dispatch";
      } else if (pageId === "gpspage") {
        openActiveRoute = "passive";
      } else {
        openActiveRoute = "unsupported";
      }

      return freezeCapabilitiesSnapshot({
        pageId: pageId,
        routePoints: {
          activate:
            pageId === "gpspage"
              ? hasRoutePointsRelay
                ? "dispatch"
                : "unsupported"
              : pageId === "editroutepage" && hasEditRouteParityDispatch
                ? "dispatch"
                : "unsupported"
        },
        map: {
          checkAutoZoom: pageId === "navpage" ? "dispatch" : "unsupported"
        },
        routeEditor: {
          openActiveRoute: openActiveRoute,
          openEditRoute: pageId === "editroutepage" ? "dispatch" : "unsupported"
        },
        ais: {
          showInfo: pageId === "navpage" || pageId === "gpspage" ? "dispatch" : "unsupported"
        },
        alarm: {
          stopAll: hasAlarmDispatch ? "dispatch" : "unsupported"
        }
      });
    }

    /** @returns {DyniTemporaryCapabilities} */
    function resolveCapabilities() {
      const pageId = discovery.detectPageId();
      const routePointsApi = getRoutePointsApi();
      const hasRoutePointsRelay = !!(routePointsApi && typeof routePointsApi.activate === "function");
      const hasEditRouteParityDispatch =
        pageId === "editroutepage" &&
        typeof discovery.findPageDispatchHandler(pageId, ["onItemClick", "widgetClick"]) === "function";
      const hasAlarmDispatch = discovery.hasAlarmDispatch();
      const cacheKey =
        pageId +
        "|" +
        (hasRoutePointsRelay ? "1" : "0") +
        "|" +
        (hasEditRouteParityDispatch ? "1" : "0") +
        "|" +
        (hasAlarmDispatch ? "1" : "0");
      if (cacheKey === cachedCapabilitiesKey && cachedCapabilitiesSnapshot) {
        return cachedCapabilitiesSnapshot;
      }
      cachedCapabilitiesKey = cacheKey;
      cachedCapabilitiesSnapshot = buildCapabilitiesSnapshot(
        pageId,
        hasRoutePointsRelay,
        hasEditRouteParityDispatch,
        hasAlarmDispatch
      );
      return cachedCapabilitiesSnapshot;
    }

    cachedFacade = {
      getCapabilities: function () {
        ensureActive();
        return resolveCapabilities();
      },
      routePoints: {
        activate: function (payload) {
          ensureActive();
          const capabilities = resolveCapabilities();
          if (capabilities.routePoints.activate !== "dispatch") {
            if (capabilities.pageId === "editroutepage") {
              throw createBridgeError("routePoints.activate parity dispatch unavailable on editroutepage");
            }
            return false;
          }
          const activation = normalizeRoutePointActivationPayload(payload);
          if (capabilities.pageId === "editroutepage") {
            const parityPoint = buildEditRoutePointPayload(activation.pointSnapshot);
            // dyni-workaround(avnav-plugin-actions) -- keep RoutePoints parity in EditRoutePage via host click wiring until core exposes a stable plugin host-action API.
            return discovery.dispatchPageAction(
              "routePoints.activate",
              capabilities.pageId,
              {
                item: { name: "RoutePoints" },
                point: parityPoint
              },
              ["onItemClick", "widgetClick"],
              "onItemClick/widgetClick"
            );
          }
          const routePointsApi = getRoutePointsApi();
          if (!routePointsApi || typeof routePointsApi.activate !== "function") {
            throw createBridgeError("routePoints.activate relay missing on " + capabilities.pageId);
          }
          // dyni-workaround(avnav-plugin-actions) -- routePoints is runtime-exposed but not yet a documented plugin host-action API.
          const dispatched = routePointsApi.activate(activation.index);
          if (dispatched === false) {
            throw createBridgeError("routePoints.activate returned false on " + capabilities.pageId);
          }
          return true;
        }
      },
      map: {
        checkAutoZoom: function () {
          ensureActive();
          const capabilities = resolveCapabilities();
          if (capabilities.map.checkAutoZoom !== "dispatch") {
            return false;
          }
          // dyni-workaround(avnav-plugin-actions) -- use current page item-click wiring to reproduce native Zoom dispatch until core exposes map actions.
          return discovery.dispatchPageAction(
            "map.checkAutoZoom",
            capabilities.pageId,
            {
              item: { name: "Zoom" }
            },
            ["onItemClick"],
            "onItemClick"
          );
        }
      },
      routeEditor: {
        openActiveRoute: function () {
          ensureActive();
          const capabilities = resolveCapabilities();
          if (capabilities.routeEditor.openActiveRoute !== "dispatch") {
            return false;
          }
          // dyni-workaround(avnav-plugin-actions) -- use current page item-click wiring to reproduce native ActiveRoute dispatch until core exposes routeEditor actions.
          return discovery.dispatchPageAction(
            "routeEditor.openActiveRoute",
            capabilities.pageId,
            {
              item: { name: "ActiveRoute" }
            },
            ["onItemClick"],
            "onItemClick"
          );
        },
        openEditRoute: function () {
          ensureActive();
          const capabilities = resolveCapabilities();
          if (capabilities.routeEditor.openEditRoute !== "dispatch") {
            return false;
          }
          // dyni-workaround(avnav-plugin-actions) -- use current page item-click wiring to reproduce native EditRoute dialog dispatch until core exposes routeEditor actions.
          return discovery.dispatchPageAction(
            "routeEditor.openEditRoute",
            capabilities.pageId,
            {
              item: { name: "EditRoute" }
            },
            ["onItemClick"],
            "onItemClick"
          );
        }
      },
      ais: {
        showInfo: function (mmsi) {
          ensureActive();
          const capabilities = resolveCapabilities();
          if (capabilities.ais.showInfo !== "dispatch") {
            return false;
          }
          const normalizedMmsi = normalizeMmsi(mmsi);
          // dyni-workaround(avnav-plugin-actions) -- use current page item-click wiring to reproduce native AIS info dispatch until core exposes AIS actions.
          return discovery.dispatchPageAction(
            "ais.showInfo",
            capabilities.pageId,
            {
              item: { name: "AisTarget" },
              mmsi: normalizedMmsi
            },
            ["onItemClick"],
            "onItemClick"
          );
        }
      },
      alarm: {
        stopAll: function () {
          ensureActive();
          const previousCapabilities = cachedCapabilitiesSnapshot;
          const capabilities = resolveCapabilities();
          if (capabilities.alarm.stopAll !== "dispatch") {
            if (
              previousCapabilities &&
              previousCapabilities.alarm &&
              previousCapabilities.alarm.stopAll === "dispatch"
            ) {
              throw createBridgeError("alarm.stopAll missing native .alarmWidget click path");
            }
            return false;
          }
          return discovery.dispatchAlarmStopAll();
        }
      }
    };

    return {
      getHostActions: function () {
        ensureActive();
        return cachedFacade;
      },
      destroy: function () {
        destroyed = true;
        cachedCapabilitiesKey = null;
        cachedCapabilitiesSnapshot = null;
        cachedFacade = null;
      }
    };
  }

  runtime.createTemporaryHostActionBridge = function () {
    return create(root);
  };
})(this);

/**
 * @file DyniPlugin Cluster Surface Policy Runtime - Surface policy resolver for cluster routing
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  /** @typedef {Record<string, unknown>} DyniSurfaceRecord */
  /**
   * @typedef {{
   *   pageId: string,
   *   alarm: { stopAll: string },
   *   routeEditor?: { openActiveRoute?: unknown, openEditRoute?: unknown },
   *   map?: { checkAutoZoom?: unknown },
   *   ais?: { showInfo?: unknown },
   *   routePoints?: { activate?: unknown },
   *   [key: string]: unknown
   * }} DyniSurfaceCapabilities
   */
  /** @typedef {{ route: { rendererId: string }, rendererSpec: unknown, props: DyniSurfaceRecord }} DyniSurfaceRouteState */
  /** @typedef {{ routePoints: { activate(payload: unknown): boolean }, map: { checkAutoZoom(): boolean }, routeEditor: { openActiveRoute(): boolean, openEditRoute(): boolean }, ais: { showInfo(mmsi: unknown): boolean }, alarm: { stopAll(): boolean } }} DyniSurfaceActions */
  /** @typedef {{ pageId: string, containerOrientation: "vertical" | "default", interaction: { mode: "dispatch" | "passive" }, actions: DyniSurfaceActions, hostFacts: { viewportHeight: number } }} DyniResolvedSurfacePolicy */
  /** @typedef {{ hostActions: DyniSurfaceRecord | null, rawCapabilities: unknown, normalizedCapabilities: DyniSurfaceCapabilities, normalizedActions: DyniSurfaceActions }} DyniHostContextCache */
  /** @typedef {{ toFiniteNumber(value: unknown): number }} DyniSurfaceValueMath */
  /** @typedef {DyniRuntimeNamespace & { _createClusterSurfacePolicy?: () => DyniSurfacePolicy }} DyniSurfaceRuntime */
  /** @typedef {{ DyniPlugin: DyniPluginNamespace & { runtime: DyniSurfaceRuntime }, DyniComponents: { DyniValueMath: { create(): DyniSurfaceValueMath } } }} DyniSurfaceRoot */

  const typedRoot = /** @type {DyniSurfaceRoot} */ (/** @type {unknown} */ (root));
  const ns = typedRoot.DyniPlugin;
  const runtime = ns.runtime;
  const valueMath = typedRoot.DyniComponents.DyniValueMath.create();

  const globalRootCandidate =
    (typeof globalThis !== "undefined" && globalThis) || (typeof self !== "undefined" && self) || {};
  const GLOBAL_ROOT = /** @type {DyniSurfaceRecord} */ (globalRootCandidate);
  const DEFAULT_CAPABILITIES = Object.freeze({
    pageId: "other",
    alarm: Object.freeze({ stopAll: "unsupported" })
  });

  const toFiniteNumber = valueMath.toFiniteNumber;

  /** @param {unknown} props @returns {boolean} */
  function isEditingMode(props) {
    const p = /** @type {DyniSurfaceRecord} */ (props && typeof props === "object" ? props : {});
    return p.editing === true || p.dyniLayoutEditing === true;
  }

  /** @param {unknown} hostContext @returns {DyniSurfaceRecord | null} */
  function resolveHostActions(hostContext) {
    const ctx = /** @type {DyniSurfaceRecord | null} */ (
      hostContext && typeof hostContext === "object" ? hostContext : null
    );
    const hostActions = ctx && ctx.hostActions ? ctx.hostActions : null;
    return /** @type {DyniSurfaceRecord | null} */ (
      hostActions && typeof hostActions === "object" ? hostActions : null
    );
  }

  /** @param {unknown} capabilities @returns {DyniSurfaceCapabilities} */
  function normalizeHostCapabilities(capabilities) {
    if (!capabilities || typeof capabilities !== "object") {
      return DEFAULT_CAPABILITIES;
    }
    const capabilityRecord = /** @type {DyniSurfaceRecord} */ (capabilities);
    const hasPageId = typeof capabilityRecord.pageId === "string" && capabilityRecord.pageId;
    const alarmGroup = /** @type {DyniSurfaceRecord | null} */ (
      capabilityRecord.alarm && typeof capabilityRecord.alarm === "object" ? capabilityRecord.alarm : null
    );
    const hasAlarmGroup = alarmGroup && typeof alarmGroup.stopAll === "string";
    if (hasPageId && hasAlarmGroup) {
      return /** @type {DyniSurfaceCapabilities} */ (capabilityRecord);
    }
    const out = /** @type {DyniSurfaceCapabilities} */ (
      hasPageId ? Object.assign({}, capabilityRecord) : Object.assign({}, capabilityRecord, { pageId: "other" })
    );
    if (!hasAlarmGroup) {
      out.alarm = { stopAll: "unsupported" };
    }
    return out;
  }

  /** @param {DyniSurfaceRecord | null} hostActions @returns {DyniSurfaceActions} */
  function createNormalizedActions(hostActions) {
    /** @param {string} ownerKey @param {string} actionKey @param {unknown[]} args @returns {boolean} */
    function callAction(ownerKey, actionKey, args) {
      const owner = hostActions && hostActions[ownerKey];
      if (!owner || typeof owner !== "object") {
        return false;
      }
      const action = /** @type {DyniSurfaceRecord} */ (owner)[actionKey];
      if (typeof action !== "function") {
        return false;
      }
      return action.apply(owner, args) !== false;
    }
    return {
      routePoints: {
        activate: function (payload) {
          return callAction("routePoints", "activate", [payload]);
        }
      },
      map: {
        checkAutoZoom: function () {
          return callAction("map", "checkAutoZoom", []);
        }
      },
      routeEditor: {
        openActiveRoute: function () {
          return callAction("routeEditor", "openActiveRoute", []);
        },
        openEditRoute: function () {
          return callAction("routeEditor", "openEditRoute", []);
        }
      },
      ais: {
        showInfo: function (mmsi) {
          return callAction("ais", "showInfo", [mmsi]);
        }
      },
      alarm: {
        stopAll: function () {
          return callAction("alarm", "stopAll", []);
        }
      }
    };
  }

  /** @returns {DyniHostContextCache} */
  function createHostContextCache() {
    return {
      hostActions: null,
      rawCapabilities: null,
      normalizedCapabilities: DEFAULT_CAPABILITIES,
      normalizedActions: createNormalizedActions(null)
    };
  }

  /** @param {unknown} hostContext @param {WeakMap<object, DyniHostContextCache>} cacheByHostContext @returns {DyniHostContextCache | null} */
  function resolveHostContextCache(hostContext, cacheByHostContext) {
    const ctx = hostContext && typeof hostContext === "object" ? hostContext : null;
    if (!ctx) {
      return null;
    }
    let cached = cacheByHostContext.get(ctx);
    if (!cached) {
      cached = createHostContextCache();
      cacheByHostContext.set(ctx, cached);
    }
    return cached;
  }

  /** @param {unknown} hostContext @param {WeakMap<object, DyniHostContextCache>} cacheByHostContext @returns {DyniSurfaceCapabilities} */
  function resolveHostCapabilities(hostContext, cacheByHostContext) {
    const hostActions = resolveHostActions(hostContext);
    const hostCache = resolveHostContextCache(hostContext, cacheByHostContext);
    if (hostCache && hostCache.hostActions !== hostActions) {
      hostCache.hostActions = hostActions;
      hostCache.rawCapabilities = null;
      hostCache.normalizedCapabilities = DEFAULT_CAPABILITIES;
      hostCache.normalizedActions = createNormalizedActions(hostActions);
    }
    const getCapabilities = hostActions && hostActions.getCapabilities;
    if (typeof getCapabilities !== "function") {
      return DEFAULT_CAPABILITIES;
    }
    const rawCapabilities = getCapabilities.call(hostActions);
    if (!hostCache) {
      return normalizeHostCapabilities(rawCapabilities);
    }
    if (hostCache.rawCapabilities === rawCapabilities) {
      return hostCache.normalizedCapabilities;
    }
    const normalizedCapabilities = normalizeHostCapabilities(rawCapabilities);
    hostCache.rawCapabilities = rawCapabilities;
    hostCache.normalizedCapabilities = normalizedCapabilities;
    return normalizedCapabilities;
  }

  /** @param {unknown} hostContext @param {WeakMap<object, DyniHostContextCache>} cacheByHostContext @returns {DyniSurfaceActions} */
  function resolveNormalizedActions(hostContext, cacheByHostContext) {
    const hostActions = resolveHostActions(hostContext);
    const hostCache = resolveHostContextCache(hostContext, cacheByHostContext);
    if (!hostCache) {
      return createNormalizedActions(hostActions);
    }
    if (hostCache.hostActions !== hostActions) {
      hostCache.hostActions = hostActions;
      hostCache.rawCapabilities = null;
      hostCache.normalizedCapabilities = DEFAULT_CAPABILITIES;
      hostCache.normalizedActions = createNormalizedActions(hostActions);
    }
    return hostCache.normalizedActions;
  }

  /** @param {DyniSurfaceRecord} props @returns {"vertical" | "default"} */
  function resolveContainerOrientation(props) {
    return props && props.mode === "vertical" ? "vertical" : "default";
  }

  /** @param {DyniSurfaceRouteState} routeState @param {DyniSurfaceCapabilities} capabilities @returns {"dispatch" | "passive"} */
  function resolveInteractionMode(routeState, capabilities) {
    const rendererId = routeState.route.rendererId;
    const props = routeState.props || {};
    const domain = /** @type {DyniSurfaceRecord | null} */ (
      props.domain && typeof props.domain === "object" ? props.domain : null
    );
    if (isEditingMode(props)) {
      return "passive";
    }
    if (rendererId === "RegattaTimerTextHtmlWidget") {
      return "dispatch";
    }
    if (rendererId === "ActiveRouteTextHtmlWidget") {
      return capabilities && capabilities.routeEditor && capabilities.routeEditor.openActiveRoute === "dispatch"
        ? "dispatch"
        : "passive";
    }
    if (rendererId === "EditRouteTextHtmlWidget") {
      return capabilities && capabilities.routeEditor && capabilities.routeEditor.openEditRoute === "dispatch"
        ? "dispatch"
        : "passive";
    }
    if (rendererId === "MapZoomTextHtmlWidget") {
      return capabilities && capabilities.map && capabilities.map.checkAutoZoom === "dispatch" ? "dispatch" : "passive";
    }
    if (rendererId === "AisTargetTextHtmlWidget") {
      return capabilities &&
        capabilities.ais &&
        capabilities.ais.showInfo === "dispatch" &&
        domain &&
        domain.hasDispatchMmsi === true
        ? "dispatch"
        : "passive";
    }
    if (rendererId === "AlarmTextHtmlWidget") {
      return capabilities &&
        capabilities.alarm &&
        capabilities.alarm.stopAll === "dispatch" &&
        domain &&
        domain.state === "active"
        ? "dispatch"
        : "passive";
    }
    if (rendererId === "RoutePointsTextHtmlWidget") {
      return capabilities && capabilities.routePoints && capabilities.routePoints.activate === "dispatch"
        ? "dispatch"
        : "passive";
    }
    return "passive";
  }

  /** @returns {number} */
  function resolveViewportHeight() {
    const viewport = toFiniteNumber(GLOBAL_ROOT && GLOBAL_ROOT.innerHeight);
    return typeof viewport === "number" && viewport > 0 ? Math.floor(viewport) : 0;
  }

  /** @param {DyniSurfaceRouteState} routeState @param {unknown} hostContext @param {WeakMap<object, DyniHostContextCache>} cacheByHostContext @returns {DyniResolvedSurfacePolicy} */
  function buildSurfacePolicy(routeState, hostContext, cacheByHostContext) {
    const capabilities = resolveHostCapabilities(hostContext, cacheByHostContext);
    return {
      pageId: capabilities.pageId || "other",
      containerOrientation: resolveContainerOrientation(routeState.props),
      interaction: {
        mode: resolveInteractionMode(routeState, capabilities)
      },
      actions: resolveNormalizedActions(hostContext, cacheByHostContext),
      hostFacts: {
        viewportHeight: resolveViewportHeight()
      }
    };
  }

  /** @param {DyniSurfaceRecord} props @param {string} key @param {unknown} value */
  function materializeRuntimeField(props, key, value) {
    const descriptor = Object.getOwnPropertyDescriptor(props, key);
    if (
      descriptor &&
      descriptor.enumerable === false &&
      descriptor.configurable === true &&
      descriptor.writable === true
    ) {
      props[key] = value;
      return;
    }
    Object.defineProperty(props, key, {
      configurable: true,
      enumerable: false,
      writable: true,
      value: value
    });
  }

  /** @param {DyniSurfaceRouteState} routeState @param {unknown} hostContext @param {WeakMap<object, DyniHostContextCache>} cacheByHostContext @returns {DyniSurfaceRecord} */
  function withSurfacePolicyProps(routeState, hostContext, cacheByHostContext) {
    const surfacePolicy = buildSurfacePolicy(routeState, hostContext, cacheByHostContext);
    const routedProps = routeState.props;
    materializeRuntimeField(routedProps, "surfacePolicy", surfacePolicy);
    materializeRuntimeField(
      routedProps,
      "viewportHeight",
      surfacePolicy.hostFacts && surfacePolicy.hostFacts.viewportHeight
    );
    return routedProps;
  }

  /** @param {DyniSurfaceRouteState} routeState @param {unknown} hostContext @param {WeakMap<object, DyniHostContextCache>} cacheByHostContext @returns {DyniSurfaceRouteState} */
  function resolveRouteStateWithPolicy(routeState, hostContext, cacheByHostContext) {
    const routedProps = withSurfacePolicyProps(routeState, hostContext, cacheByHostContext);
    return {
      route: routeState.route,
      rendererSpec: routeState.rendererSpec,
      props: routedProps
    };
  }

  /** @param {unknown} shellEl @returns {number | undefined} */
  function resolveShellWidth(shellEl) {
    const element = /** @type {{ getBoundingClientRect?: () => { width: unknown } } | null} */ (
      shellEl && typeof shellEl === "object" ? shellEl : null
    );
    if (!element || typeof element.getBoundingClientRect !== "function") {
      return undefined;
    }
    const width = toFiniteNumber(element.getBoundingClientRect().width);
    return width > 0 ? Math.round(width) : undefined;
  }
  /** @returns {DyniSurfacePolicy} */
  function createClusterSurfacePolicy() {
    /** @type {WeakMap<object, DyniHostContextCache>} */
    const cacheByHostContext = new WeakMap();
    return {
      resolveRouteStateWithPolicy: function (routeState, hostContext) {
        return resolveRouteStateWithPolicy(
          /** @type {DyniSurfaceRouteState} */ (routeState),
          hostContext,
          cacheByHostContext
        );
      },
      resolveShellWidth: resolveShellWidth
    };
  }

  runtime._createClusterSurfacePolicy = createClusterSurfacePolicy;
})(this);

/**
 * @file DyniPlugin CanvasDom Surface Runtime - Canvas surface controller for internal canvas lifecycle
 * Documentation: documentation/architecture/canvas-dom-surface-adapter.md
 */
(function (root) {
  "use strict";

  /** @typedef {{ id?: unknown, renderCanvas(canvas: HTMLCanvasElement, props: Record<string, unknown> | undefined): { wantsFollowUpFrame?: boolean } | void }} DyniCanvasSurfaceRendererSpec */
  /** @typedef {{ revision: number, rootEl: Element, shellEl: HTMLElement, props?: Record<string, unknown>, surface?: unknown }} DyniCanvasSurfacePayload */
  /** @typedef {{ rendererSpec: DyniCanvasSurfaceRendererSpec, requestAnimationFrame?: (callback: () => void) => number, cancelAnimationFrame?: (handle: number) => void, ResizeObserver?: typeof ResizeObserver, hostContext?: unknown }} DyniCanvasSurfaceOptions */
  /** @typedef {{ _createCanvasDomSurfaceAdapter: () => DyniSurfaceControllerFactory }} DyniCanvasRuntime */

  const ns = /** @type {DyniPluginNamespace & { runtime: DyniCanvasRuntime }} */ (root.DyniPlugin);
  const runtime = ns.runtime;

  const hasOwn = Object.prototype.hasOwnProperty;
  const SURFACE_SELECTOR = ".dyni-surface-canvas";
  const MOUNT_SELECTOR = ".dyni-surface-canvas-mount";
  const CANVAS_CLASS = "dyni-surface-canvas-node";
  const RENDER_NOT_READY = { updated: false, changed: false };
  let globalRoot = {};
  if (typeof globalThis !== "undefined") {
    globalRoot = globalThis;
  } else if (typeof self !== "undefined") {
    globalRoot = self;
  }
  const GLOBAL_ROOT = /** @type {Window & typeof globalThis} */ (globalRoot);

  /** @param {Element | null | undefined} el @param {string} className @returns {boolean} */
  function hasClass(el, className) {
    return !!(el && el.classList && typeof el.classList.contains === "function" && el.classList.contains(className));
  }

  /** @param {Element | null | undefined} rootEl @param {string} className @returns {HTMLElement | null} */
  function findDescendantByClass(rootEl, className) {
    if (!rootEl || !rootEl.children || !rootEl.children.length) {
      return null;
    }
    for (let i = 0; i < rootEl.children.length; i += 1) {
      const child = /** @type {HTMLElement} */ (rootEl.children[i]);
      if (hasClass(child, className)) {
        return child;
      }
      const nested = findDescendantByClass(child, className);
      if (nested) {
        return nested;
      }
    }
    return null;
  }

  /** @param {string} methodName @param {DyniCanvasSurfacePayload} payload */
  function ensurePayload(methodName, payload) {
    if (!payload || typeof payload !== "object") {
      throw new Error("CanvasDomSurfaceAdapter: " + methodName + "() requires a payload object");
    }
    if (!Number.isFinite(payload.revision)) {
      throw new Error("CanvasDomSurfaceAdapter: " + methodName + "() requires finite payload.revision");
    }
    if (!payload.rootEl) {
      throw new Error("CanvasDomSurfaceAdapter: " + methodName + "() requires payload.rootEl");
    }
    if (!payload.shellEl) {
      throw new Error("CanvasDomSurfaceAdapter: " + methodName + "() requires payload.shellEl");
    }
  }

  /** @param {Record<string, unknown> | undefined} a @param {Record<string, unknown> | undefined} b @returns {boolean} */
  function shallowEqual(a, b) {
    if (a === b) {
      return true;
    }
    if (!a || !b || typeof a !== "object" || typeof b !== "object") {
      return false;
    }

    const keysA = Object.keys(a);
    const keysB = Object.keys(b);
    if (keysA.length !== keysB.length) {
      return false;
    }

    for (let i = 0; i < keysA.length; i += 1) {
      const key = keysA[i];
      if (!hasOwn.call(b, key) || a[key] !== b[key]) {
        return false;
      }
    }
    return true;
  }

  /** @returns {DyniSurfaceControllerFactory} */
  function createCanvasDomSurfaceAdapter() {
    /** @param {DyniCanvasSurfaceOptions} options */
    function createSurfaceController(options) {
      const opts = /** @type {DyniCanvasSurfaceOptions} */ (options || {});
      const rendererSpec = opts.rendererSpec;
      if (!rendererSpec || typeof rendererSpec.renderCanvas !== "function") {
        throw new Error("CanvasDomSurfaceAdapter: rendererSpec.renderCanvas is required");
      }

      const requestFrame =
        typeof opts.requestAnimationFrame === "function"
          ? opts.requestAnimationFrame
          : typeof GLOBAL_ROOT.requestAnimationFrame === "function"
            ? GLOBAL_ROOT.requestAnimationFrame.bind(GLOBAL_ROOT)
            : function (/** @type {() => void} */ cb) {
                return GLOBAL_ROOT.setTimeout(cb, 16);
              };

      const cancelFrame =
        typeof opts.cancelAnimationFrame === "function"
          ? opts.cancelAnimationFrame
          : typeof GLOBAL_ROOT.cancelAnimationFrame === "function"
            ? GLOBAL_ROOT.cancelAnimationFrame.bind(GLOBAL_ROOT)
            : function (/** @type {number} */ handle) {
                GLOBAL_ROOT.clearTimeout(handle);
              };

      const ResizeObserverCtor = hasOwn.call(opts, "ResizeObserver") ? opts.ResizeObserver : GLOBAL_ROOT.ResizeObserver;

      if (typeof ResizeObserverCtor !== "function") {
        throw new Error("CanvasDomSurfaceAdapter: ResizeObserver is required");
      }

      const hostContext = hasOwn.call(opts, "hostContext") ? opts.hostContext : null;

      /** @type {Element | null} */
      let rootEl = null;
      /** @type {HTMLElement | null} */
      let shellEl = null;
      /** @type {HTMLElement | null} */
      let surfaceEl = null;
      /** @type {HTMLElement | null} */
      let mountEl = null;
      /** @type {HTMLCanvasElement | null} */
      let canvasEl = null;
      /** @type {ResizeObserver | null} */
      let observer = null;
      /** @type {number | null} */
      let rafHandle = null;

      /** @type {Record<string, unknown> | undefined} */
      let props = undefined;
      let revision = 0;
      let attached = false;
      let destroyed = false;
      let paintDirty = false;
      let sizeDirty = false;
      let consecutiveAnimateFrames = 0;

      function cancelPendingFrame() {
        if (rafHandle === null || rafHandle === undefined) {
          return;
        }
        cancelFrame(rafHandle);
        rafHandle = null;
      }

      function disconnectObserver() {
        if (!observer) {
          return;
        }
        observer.disconnect();
        observer = null;
      }

      function clearDomRefs() {
        rootEl = null;
        shellEl = null;
        surfaceEl = null;
        mountEl = null;
        canvasEl = null;
      }

      function clearRenderFlags() {
        paintDirty = false;
        sizeDirty = false;
      }

      /** @param {unknown} reason */
      function markDirty(reason) {
        if (reason !== "animate") {
          consecutiveAnimateFrames = 0;
        }
        if (reason === "size") {
          sizeDirty = true;
          return;
        }
        paintDirty = true;
      }

      /** @param {HTMLElement | null} hostShellEl @returns {HTMLElement | null} */
      function findSurfaceElement(hostShellEl) {
        if (!hostShellEl) {
          return null;
        }
        const nestedFromChildren = findDescendantByClass(hostShellEl, "dyni-surface-canvas");
        if (nestedFromChildren) {
          return nestedFromChildren;
        }
        if (typeof hostShellEl.querySelector === "function") {
          const nestedSurfaceEl = /** @type {HTMLElement | null} */ (hostShellEl.querySelector(SURFACE_SELECTOR));
          if (nestedSurfaceEl) {
            return nestedSurfaceEl;
          }
        }
        if (hasClass(hostShellEl, "dyni-surface-canvas")) {
          return hostShellEl;
        }
        return null;
      }

      /** @param {HTMLElement} hostSurfaceEl @returns {HTMLElement | null} */
      function findMountElement(hostSurfaceEl) {
        if (hasClass(hostSurfaceEl, "dyni-surface-canvas-mount")) {
          return hostSurfaceEl;
        }
        if (typeof hostSurfaceEl.querySelector !== "function") {
          return null;
        }
        return /** @type {HTMLElement | null} */ (hostSurfaceEl.querySelector(MOUNT_SELECTOR));
      }

      function removeCanvasNode() {
        if (!mountEl || !canvasEl || typeof mountEl.removeChild !== "function") {
          return;
        }
        if (canvasEl.parentElement !== mountEl) {
          return;
        }
        mountEl.removeChild(canvasEl);
      }

      /** @returns {HTMLCanvasElement} */
      function createCanvasNode() {
        const doc = shellEl && shellEl.ownerDocument;
        if (!doc || typeof doc.createElement !== "function") {
          throw new Error("CanvasDomSurfaceAdapter: attach() requires shellEl.ownerDocument.createElement");
        }
        const canvas = doc.createElement("canvas");
        canvas.className = CANVAS_CLASS;
        return canvas;
      }

      function applySurfaceContractStyles() {
        if (!surfaceEl || !mountEl || !canvasEl) {
          throw new Error("CanvasDomSurfaceAdapter: surface DOM references are required before styling");
        }
        surfaceEl.style.fontSize = "initial";
        surfaceEl.style.width = "100%";
        surfaceEl.style.height = "100%";
        surfaceEl.style.display = "block";

        mountEl.style.width = "100%";
        mountEl.style.height = "100%";
        mountEl.style.display = "block";

        canvasEl.style.width = "100%";
        canvasEl.style.height = "100%";
        canvasEl.style.display = "block";
      }

      function paintNow() {
        if (!attached || !canvasEl || (!paintDirty && !sizeDirty)) {
          return;
        }

        let paintResult;
        if (hostContext) {
          paintResult = rendererSpec.renderCanvas.call(hostContext, canvasEl, props);
        } else {
          paintResult = rendererSpec.renderCanvas(canvasEl, props);
        }
        clearRenderFlags();
        if (paintResult && paintResult.wantsFollowUpFrame === true && consecutiveAnimateFrames < 600) {
          if (schedulePaint("animate")) {
            consecutiveAnimateFrames += 1;
          }
        }
      }

      /** @param {unknown} reason @returns {boolean} */
      function schedulePaint(reason) {
        if (!attached || destroyed || !canvasEl) {
          return false;
        }
        markDirty(reason);

        if (rafHandle !== null && rafHandle !== undefined) {
          return false;
        }

        rafHandle = requestFrame(function () {
          rafHandle = null;
          paintNow();
        });
        return true;
      }

      function bindResizeObserver() {
        const ResizeObserverClass = /** @type {typeof ResizeObserver} */ (ResizeObserverCtor);
        if (!surfaceEl) {
          throw new Error("CanvasDomSurfaceAdapter: surface element is required before observing resize");
        }
        observer = new ResizeObserverClass(function () {
          if (!attached || destroyed) {
            return;
          }
          schedulePaint("size");
        });
        observer.observe(surfaceEl);
      }

      /** @param {DyniCanvasSurfacePayload} payload */
      function setPayloadState(payload) {
        rootEl = payload.rootEl;
        shellEl = payload.shellEl;
        props = payload.props;
        revision = payload.revision;
      }

      /** @param {DyniCanvasSurfacePayload} payload */
      function attach(payload) {
        if (destroyed) {
          throw new Error("CanvasDomSurfaceAdapter: attach() after destroy()");
        }
        ensurePayload("attach", payload);
        if (payload.surface && payload.surface !== "canvas-dom") {
          throw new Error("CanvasDomSurfaceAdapter: attach() requires payload.surface === 'canvas-dom'");
        }

        if (attached) {
          detach("remount");
        }

        setPayloadState(payload);
        surfaceEl = findSurfaceElement(shellEl);
        if (!surfaceEl) {
          throw new Error("CanvasDomSurfaceAdapter: attach() missing .dyni-surface-canvas in shellEl");
        }

        mountEl = findMountElement(surfaceEl);
        if (!mountEl) {
          throw new Error("CanvasDomSurfaceAdapter: attach() missing .dyni-surface-canvas-mount in shellEl");
        }

        canvasEl = createCanvasNode();
        applySurfaceContractStyles();
        mountEl.appendChild(canvasEl);

        attached = true;
        bindResizeObserver();
        schedulePaint("attach");
      }

      /** @param {DyniCanvasSurfacePayload} payload */
      function update(payload) {
        ensurePayload("update", payload);
        if (!attached) {
          throw new Error("CanvasDomSurfaceAdapter: update() requires an attached surface");
        }
        if (payload.shellEl !== shellEl) {
          throw new Error("CanvasDomSurfaceAdapter: update() received a different shellEl; remount required");
        }

        const changed = !shallowEqual(props, payload.props);
        setPayloadState(payload);
        if (!changed) {
          return RENDER_NOT_READY;
        }
        schedulePaint("update");
        return { updated: true, changed: true };
      }

      /** @param {unknown} reason */
      function detach(reason) {
        cancelPendingFrame();
        disconnectObserver();
        removeCanvasNode();
        clearRenderFlags();
        clearDomRefs();
        props = undefined;
        revision = 0;
        attached = false;
      }

      function destroy() {
        if (destroyed) {
          return;
        }
        detach("destroy");
        destroyed = true;
      }

      return {
        attach: attach,
        update: update,
        detach: detach,
        destroy: destroy
      };
    }

    return {
      createSurfaceController: createSurfaceController
    };
  }

  runtime._createCanvasDomSurfaceAdapter = createCanvasDomSurfaceAdapter;
})(this);

/**
 * @file DyniPlugin Html Surface Runtime - Committed html-surface lifecycle owner
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  const ns = /** @type {DyniPluginNamespace & { runtime: DyniHtmlRuntime }} */ (root.DyniPlugin);
  const runtime = ns.runtime;

  const SURFACE_ID = "html";
  const MOUNT_CLASS = "dyni-surface-html-mount";
  const BASE_SHADOW_STYLE_ATTR = "data-dyni-shadow-base";
  const BASE_SHADOW_STYLE_ID = "html-surface-box-contract";
  const BASE_SHADOW_STYLE_CSS = [
    ":host {",
    "  display: block;",
    "  width: 100%;",
    "  height: 100%;",
    "  min-width: 0;",
    "  min-height: 0;",
    "  box-sizing: border-box;",
    "}",
    ".dyni-html-root {",
    "  display: block;",
    "  width: 100%;",
    "  height: 100%;",
    "  min-width: 0;",
    "  min-height: 0;",
    "  box-sizing: border-box;",
    "}"
  ].join("\n");

  /** @param {string} methodName @param {DyniHtmlSurfacePayload} payload */
  function ensurePayload(methodName, payload) {
    if (!payload || typeof payload !== "object") {
      throw new Error("HtmlSurfaceController: " + methodName + "() requires a payload object");
    }
    if (!Number.isFinite(payload.revision)) {
      throw new Error("HtmlSurfaceController: " + methodName + "() requires finite payload.revision");
    }
    if (!payload.rootEl) {
      throw new Error("HtmlSurfaceController: " + methodName + "() requires payload.rootEl");
    }
    if (!payload.shellEl) {
      throw new Error("HtmlSurfaceController: " + methodName + "() requires payload.shellEl");
    }
    if (payload.surface && payload.surface !== SURFACE_ID) {
      throw new Error("HtmlSurfaceController: " + methodName + "() requires payload.surface === 'html'");
    }
  }

  /** @param {string} methodName @param {unknown} hostContext */
  function ensureHostContext(methodName, hostContext) {
    if (!hostContext || typeof hostContext !== "object") {
      throw new Error("HtmlSurfaceController: " + methodName + "() requires hostContext object");
    }
  }

  /** @param {string} methodName @param {DyniHtmlSurfaceRendererSpec | null} rendererSpec */
  function ensureRendererSpec(methodName, rendererSpec) {
    if (!rendererSpec || typeof rendererSpec !== "object") {
      throw new Error("HtmlSurfaceController: " + methodName + "() requires rendererSpec object");
    }
    if (typeof rendererSpec.createCommittedRenderer !== "function") {
      throw new Error("HtmlSurfaceController: " + methodName + "() requires rendererSpec.createCommittedRenderer()");
    }
  }

  /** @param {string} methodName @param {DyniHtmlSurfaceRendererInstance} instance */
  function ensureRendererInstance(methodName, instance) {
    if (!instance || typeof instance !== "object") {
      throw new Error("HtmlSurfaceController: " + methodName + "() renderer factory must return an object instance");
    }
    const methods = ["mount", "update", "postPatch", "detach", "destroy"];
    for (let i = 0; i < methods.length; i += 1) {
      const method = methods[i];
      const dynamicInstance = /** @type {Record<string, unknown>} */ (/** @type {unknown} */ (instance));
      if (typeof dynamicInstance[method] !== "function") {
        throw new Error(
          "HtmlSurfaceController: " + methodName + "() committed renderer must implement " + method + "()"
        );
      }
    }
  }

  /** @param {unknown} signature @param {string} methodName @returns {string} */
  function normalizeSignature(signature, methodName) {
    if (signature === null || signature === undefined) {
      return "null";
    }
    const type = typeof signature;
    if (type === "string" || type === "number" || type === "boolean") {
      return type + ":" + String(signature);
    }
    throw new Error("HtmlSurfaceController: " + methodName + "() layoutSignature() must return primitive signature");
  }

  /** @param {DyniHtmlSurfaceRendererInstance} rendererInstance @param {DyniHtmlSurfacePayload} rendererPayload @param {string} methodName @returns {string} */
  function resolveLayoutSignature(rendererInstance, rendererPayload, methodName) {
    if (typeof rendererInstance.layoutSignature !== "function") {
      return "none";
    }
    return normalizeSignature(rendererInstance.layoutSignature(rendererPayload), methodName);
  }

  /** @param {HTMLElement} shellEl @returns {HTMLElement} */
  function ensureMountHost(shellEl) {
    if (!shellEl || typeof shellEl.querySelector !== "function") {
      throw new Error("HtmlSurfaceController: shell element does not support querySelector()");
    }
    const mountEl = shellEl.querySelector("." + MOUNT_CLASS);
    if (!mountEl) {
      throw new Error("HtmlSurfaceController: shell is missing ." + MOUNT_CLASS + " mount host");
    }
    return /** @type {HTMLElement} */ (mountEl);
  }

  /** @param {HTMLElement} mountEl @returns {ShadowRoot} */
  function ensureShadowRoot(mountEl) {
    if (mountEl.shadowRoot) {
      return mountEl.shadowRoot;
    }
    if (typeof mountEl.attachShadow !== "function") {
      throw new Error("HtmlSurfaceController: mount host does not support attachShadow()");
    }
    return mountEl.attachShadow({ mode: "open" });
  }

  /** @param {HTMLElement} mountEl @param {Record<string, unknown> | null | undefined} route @returns {DyniHtmlShellRect | null} */
  function measureShellRect(mountEl, route) {
    if (!mountEl || typeof mountEl.getBoundingClientRect !== "function") {
      return null;
    }
    const rect = mountEl.getBoundingClientRect();
    const width = Number(rect && rect.width);
    const height = Number(rect && rect.height);
    const shellSizing =
      route && route.shellSizing && typeof route.shellSizing === "object"
        ? /** @type {Record<string, unknown>} */ (route.shellSizing)
        : null;
    const shellSizingKind = shellSizing ? shellSizing.kind : null;

    if (shellSizingKind === "natural") {
      if (!(width > 0)) {
        return null;
      }
      return {
        width: width,
        height: height > 0 ? height : 0
      };
    }

    if (!(width > 0) || !(height > 0)) {
      return null;
    }
    return {
      width: width,
      height: height
    };
  }

  /** @param {DyniHtmlSurfaceState} state @param {DyniHtmlSurfacePayload} payload @param {boolean} layoutChanged @param {number} relayoutPass @returns {DyniHtmlSurfacePayload} */
  function createRendererPayload(state, payload, layoutChanged, relayoutPass) {
    return {
      props: payload.props,
      revision: payload.revision,
      rootEl: payload.rootEl,
      shellEl: payload.shellEl,
      mountEl: state.mountEl,
      shadowRoot: state.shadowRoot,
      route: payload.route || null,
      shellRect: state.mountEl ? measureShellRect(state.mountEl, payload.route) : null,
      hostContext: state.hostContext,
      layoutChanged: layoutChanged === true,
      relayoutPass: relayoutPass || 0,
      fontMetricsEpoch: state.fontMetricsEpoch
    };
  }

  /** @param {unknown} result @returns {boolean} */
  function shouldRelayout(result) {
    if (result === true) {
      return true;
    }
    const resultRecord = result && typeof result === "object" ? /** @type {Record<string, unknown>} */ (result) : null;
    return !!(resultRecord && resultRecord.relayout === true);
  }

  /** @param {DyniThemeRuntime | null} themeRuntime @param {string} url @returns {string} */
  function ensureShadowCssCached(themeRuntime, url) {
    if (!themeRuntime || typeof themeRuntime.getShadowCssText !== "function") {
      throw new Error("HtmlSurfaceController: runtime.theme.getShadowCssText() is required for shadow CSS injection");
    }
    const cssText = themeRuntime.getShadowCssText(url);
    if (typeof cssText !== "string") {
      throw new Error("HtmlSurfaceController: missing preloaded shadow CSS text for '" + url + "'");
    }
    return cssText;
  }

  /** @param {ShadowRoot} shadowRoot */
  function injectBaseShadowStyle(shadowRoot) {
    const selector = "style[" + BASE_SHADOW_STYLE_ATTR + '="' + BASE_SHADOW_STYLE_ID + '"]';
    if (typeof shadowRoot.querySelector === "function" && shadowRoot.querySelector(selector)) {
      return;
    }
    const styleEl = shadowRoot.ownerDocument.createElement("style");
    styleEl.setAttribute(BASE_SHADOW_STYLE_ATTR, BASE_SHADOW_STYLE_ID);
    styleEl.textContent = BASE_SHADOW_STYLE_CSS;
    shadowRoot.appendChild(styleEl);
  }

  /** @param {ShadowRoot} shadowRoot @param {string[]} shadowCssUrls @param {DyniThemeRuntime | null} themeRuntime */
  function injectShadowStyles(shadowRoot, shadowCssUrls, themeRuntime) {
    if (!Array.isArray(shadowCssUrls) || !shadowCssUrls.length) {
      return;
    }
    for (let i = 0; i < shadowCssUrls.length; i += 1) {
      const url = shadowCssUrls[i];
      if (typeof url !== "string" || !url) {
        continue;
      }
      const selector = 'style[data-dyni-shadow-css="' + url.replace(new RegExp('"', "g"), '\\"') + '"]';
      if (typeof shadowRoot.querySelector === "function" && shadowRoot.querySelector(selector)) {
        continue;
      }
      const cssText = ensureShadowCssCached(themeRuntime, url);
      const styleEl = shadowRoot.ownerDocument.createElement("style");
      styleEl.setAttribute("data-dyni-shadow-css", url);
      styleEl.textContent = cssText;
      shadowRoot.appendChild(styleEl);
    }
  }

  /** @returns {DyniSurfaceControllerFactory} */
  function createHtmlSurfaceController() {
    const runtimeApi = runtime;
    const themeRuntime = runtimeApi && runtimeApi.theme ? runtimeApi.theme : null;

    /** @param {DyniHtmlSurfaceOptions} options */
    function createSurfaceController(options) {
      const opts = /** @type {DyniHtmlSurfaceOptions} */ (options || {});
      const rendererSpec = /** @type {DyniHtmlSurfaceRendererSpec} */ (opts.rendererSpec);
      const hostContext = Object.prototype.hasOwnProperty.call(opts, "hostContext") ? opts.hostContext : null;
      const shadowCssUrls = Array.isArray(opts.shadowCssUrls) ? opts.shadowCssUrls.slice() : [];

      ensureRendererSpec("createSurfaceController", rendererSpec);
      ensureHostContext("createSurfaceController", hostContext);

      let attached = false;
      let destroyed = false;
      let lastLayoutSignature = "none";

      const state = /** @type {DyniHtmlSurfaceState} */ ({
        hostContext: hostContext,
        shellEl: null,
        mountEl: null,
        shadowRoot: null,
        renderer: null,
        latestPayload: null,
        fontMetricsEpoch: 0,
        fontMetricsRefreshToken: 0
      });

      /** @param {DyniHtmlSurfacePayload} payload @param {DyniHtmlSurfacePayload} rendererPayload */
      function runPostPatch(payload, rendererPayload) {
        if (!state.renderer) {
          return;
        }
        const postPatchResult = state.renderer.postPatch(rendererPayload);
        if (!shouldRelayout(postPatchResult)) {
          return;
        }

        const relayoutPayload = createRendererPayload(state, payload, true, 1);
        state.renderer.update(relayoutPayload);
        state.renderer.postPatch(relayoutPayload);
      }

      function scheduleFontMetricsRefresh() {
        if (!state.mountEl || !state.renderer || !state.latestPayload) {
          return;
        }
        const ownerDocument = state.mountEl.ownerDocument || null;
        const fonts = ownerDocument && ownerDocument.fonts ? ownerDocument.fonts : null;
        if (!fonts || fonts.status === "loaded" || !fonts.ready || typeof fonts.ready.then !== "function") {
          return;
        }

        const refreshToken = state.fontMetricsRefreshToken + 1;
        state.fontMetricsRefreshToken = refreshToken;
        fonts.ready.then(
          function () {
            if (destroyed || !attached || refreshToken !== state.fontMetricsRefreshToken) {
              return;
            }
            if (!state.renderer || !state.mountEl || !state.latestPayload) {
              return;
            }
            state.fontMetricsEpoch += 1;
            const latestPayload = state.latestPayload;
            const rendererPayload = createRendererPayload(state, latestPayload, false, 0);
            state.renderer.update(rendererPayload);
            runPostPatch(latestPayload, rendererPayload);
          },
          function () {}
        );
      }

      /** @param {DyniHtmlSurfacePayload} payload */
      function attach(payload) {
        if (destroyed) {
          throw new Error("HtmlSurfaceController: attach() after destroy()");
        }
        ensurePayload("attach", payload);
        state.mountEl = ensureMountHost(payload.shellEl);
        state.shadowRoot = ensureShadowRoot(state.mountEl);
        state.shellEl = payload.shellEl;
        injectBaseShadowStyle(state.shadowRoot);
        injectShadowStyles(state.shadowRoot, shadowCssUrls, themeRuntime);

        const rendererInstance = rendererSpec.createCommittedRenderer({
          hostContext: hostContext,
          shadowRoot: state.shadowRoot,
          mountEl: state.mountEl
        });
        ensureRendererInstance("attach", rendererInstance);
        state.renderer = rendererInstance;
        state.latestPayload = payload;

        const rendererPayload = createRendererPayload(state, payload, true, 0);
        lastLayoutSignature = resolveLayoutSignature(rendererInstance, rendererPayload, "attach");
        rendererInstance.mount(state.shadowRoot, rendererPayload);
        runPostPatch(payload, rendererPayload);
        scheduleFontMetricsRefresh();

        attached = true;
      }

      /** @param {DyniHtmlSurfacePayload} payload */
      function update(payload) {
        ensurePayload("update", payload);
        if (!attached || !state.renderer) {
          throw new Error("HtmlSurfaceController: update() requires an attached surface");
        }
        if (payload.shellEl !== state.shellEl) {
          throw new Error("HtmlSurfaceController: update() received a different shellEl; remount required");
        }
        const signaturePayload = createRendererPayload(state, payload, false, 0);
        const nextLayoutSignature = resolveLayoutSignature(state.renderer, signaturePayload, "update");
        const layoutChanged = nextLayoutSignature !== lastLayoutSignature;
        lastLayoutSignature = nextLayoutSignature;

        const rendererPayload = createRendererPayload(state, payload, layoutChanged, 0);
        state.latestPayload = payload;
        state.renderer.update(rendererPayload);
        runPostPatch(payload, rendererPayload);

        return {
          updated: true,
          changed: true,
          layoutChanged: layoutChanged
        };
      }

      /** @param {string} reason */
      function detach(reason) {
        if (!state.renderer) {
          attached = false;
          return;
        }
        state.fontMetricsRefreshToken += 1;
        state.renderer.detach(reason || "detach");
        if (state.shadowRoot && state.shadowRoot.textContent !== undefined) {
          state.shadowRoot.textContent = "";
        }
        state.renderer = null;
        state.shellEl = null;
        state.mountEl = null;
        state.shadowRoot = null;
        state.latestPayload = null;
        lastLayoutSignature = "none";
        attached = false;
      }

      function destroy() {
        if (destroyed) {
          return;
        }
        if (state.renderer) {
          state.renderer.destroy();
        }
        detach("destroy");
        destroyed = true;
      }

      return {
        attach: attach,
        update: update,
        detach: detach,
        destroy: destroy
      };
    }

    return {
      createSurfaceController: createSurfaceController
    };
  }

  runtime._createHtmlSurfaceController = createHtmlSurfaceController;
})(this);

/**
 * @file DyniPlugin Surface Runtime Index - Runtime-owned surface policy and controller infrastructure
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const runtime = /** @type {DyniRuntimeNamespace} */ (ns.runtime);

  if (typeof runtime._createClusterSurfacePolicy !== "function") {
    throw new Error("dyninstruments: runtime._createClusterSurfacePolicy missing before runtime/surface/index.js load");
  }
  if (typeof runtime._createCanvasDomSurfaceAdapter !== "function") {
    throw new Error(
      "dyninstruments: runtime._createCanvasDomSurfaceAdapter missing before runtime/surface/index.js load"
    );
  }
  if (typeof runtime._createHtmlSurfaceController !== "function") {
    throw new Error(
      "dyninstruments: runtime._createHtmlSurfaceController missing before runtime/surface/index.js load"
    );
  }

  const policy = /** @type {DyniSurfacePolicy} */ (runtime._createClusterSurfacePolicy());
  const canvasDom = /** @type {DyniSurfaceControllerFactory} */ (runtime._createCanvasDomSurfaceAdapter());
  const html = /** @type {DyniSurfaceControllerFactory} */ (runtime._createHtmlSurfaceController());

  /** @param {DyniSurfaceControllerOptions|null|undefined} options @returns {unknown} */
  function createController(options) {
    const opts = /** @type {DyniSurfaceControllerOptions} */ (options || {});
    const surface = opts.surface;
    if (surface === "canvas-dom") {
      return canvasDom.createSurfaceController(opts);
    }
    if (surface === "html") {
      return html.createSurfaceController(opts);
    }
    throw new Error("runtime.surfaces.createController: unsupported surface '" + String(surface) + "'");
  }

  /**
   * @param {DyniSurfaceControllerOptions|null|undefined} options
   * @returns {Record<string, unknown>}
   */
  function materializeSurfacePolicyProps(options) {
    const opts = /** @type {DyniSurfaceControllerOptions} */ (options || {});
    const hostContext = Object.prototype.hasOwnProperty.call(opts, "hostContext") ? opts.hostContext : null;
    const rendererId = typeof opts.rendererId === "string" ? opts.rendererId : "";
    const props = opts.props;
    if (!props || typeof props !== "object") {
      throw new Error("runtime.surfaces.materializeSurfacePolicyProps: props object is required");
    }

    const routeState = /** @type {DyniSurfacePolicyRouteState} */ ({
      route: {
        rendererId: rendererId
      },
      props: /** @type {Record<string, unknown>} */ (props)
    });

    return policy.resolveRouteStateWithPolicy(routeState, hostContext).props;
  }

  /** @returns {string} */
  function getCommonShadowCssUrl() {
    if (typeof ns.baseUrl !== "string" || !ns.baseUrl) {
      throw new Error("runtime.surfaces.getCommonShadowCssUrl: baseUrl is required");
    }
    return ns.baseUrl + "shared/html/HtmlShadowCommon.css";
  }

  runtime.surfaces = /** @type {DyniSurfaceRuntimeApi} */ (
    Object.freeze({
      createController: createController,
      materializeSurfacePolicyProps: materializeSurfacePolicyProps,
      getCommonShadowCssUrl: getCommonShadowCssUrl
    })
  );
})(this);

/**
 * @file DyniPlugin Cluster Shell Renderer - Startup-safe route-frame normalization and shell markup
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  const ns = root.DyniPlugin;
  const runtime = /** @type {DyniRuntimeNamespace} */ (ns.runtime);
  const components = /** @type {Record<string, { create(): DyniValueMathApi }>} */ (root.DyniComponents);
  const valueMath = components.DyniValueMath.create();
  const CANVAS_INNER_HTML = '<div class="dyni-surface-canvas"><div class="dyni-surface-canvas-mount"></div></div>';
  const HTML_INNER_HTML =
    '<div class="dyni-surface-html"><div class="dyni-surface-html-mount" data-dyni-html-mount="1"></div></div>';
  const trimText = valueMath.trimText;

  /** @param {unknown} rawProps @param {unknown} def @param {unknown} clusterRoutes @returns {string} */
  function resolveCluster(rawProps, def, clusterRoutes) {
    const props = /** @type {DyniMapperProps} */ (rawProps && typeof rawProps === "object" ? rawProps : {});
    const cluster = trimText(props.cluster);
    if (cluster) {
      return cluster;
    }
    const definition = /** @type {DyniMapperProps} */ (def && typeof def === "object" ? def : {});
    return trimText(definition.cluster);
  }

  /** @param {unknown} rawProps @returns {string} */
  function resolveKind(rawProps) {
    const props = /** @type {DyniMapperProps} */ (rawProps && typeof rawProps === "object" ? rawProps : {});
    return trimText(props.kind);
  }

  /** @param {DyniRouteFrame|null|undefined} routeFrame @returns {boolean} */
  function isVerticalShell(routeFrame) {
    return !!(routeFrame && routeFrame.__dyniRawProps && routeFrame.__dyniRawProps.mode === "vertical");
  }

  /** @param {unknown} instanceId @param {DyniClusterShellHostContext|null|undefined} hostContext @returns {string} */
  function resolveInstanceId(instanceId, hostContext) {
    const direct = trimText(instanceId);
    if (direct) {
      return direct;
    }
    if (hostContext && typeof hostContext === "object" && hostContext.__dyniHostCommitState) {
      return trimText(hostContext.__dyniHostCommitState.instanceId);
    }
    return "";
  }

  /** @param {unknown} surface @returns {string} */
  function resolveInnerHtml(surface) {
    if (surface === "canvas-dom") {
      return CANVAS_INNER_HTML;
    }
    if (surface === "html") {
      return HTML_INNER_HTML;
    }
    return '<div class="dyni-shell-mount" data-dyni-shell-mount="1"></div>';
  }

  /** @param {DyniClusterRoute|null|undefined} routeMeta @param {DyniRouteFrame|null|undefined} routeFrame @returns {string} */
  function resolveShellStyle(routeMeta, routeFrame) {
    if (!routeMeta || !routeMeta.shellSizing || !isVerticalShell(routeFrame)) {
      return "";
    }
    if (routeMeta.shellSizing.kind === "ratio") {
      return ' style="aspect-ratio:' + String(routeMeta.shellSizing.aspectRatio) + ';"';
    }
    return "";
  }

  runtime.clusterShellRenderer = /** @type {DyniClusterShellRendererApi} */ ({
    normalizeRouteFrame: function (rawProps, def, clusterRoutes) {
      const source = /** @type {DyniMapperProps} */ (rawProps && typeof rawProps === "object" ? rawProps : {});
      const routeFrame = /** @type {DyniRouteFrame} */ (Object.assign({}, source));
      const cluster = resolveCluster(source, def, clusterRoutes);
      const kind = resolveKind(source);

      routeFrame.cluster = cluster;
      routeFrame.kind = kind;
      routeFrame.__dyniRouteId = cluster + "/" + kind;
      routeFrame.__dyniRawProps = source;

      return routeFrame;
    },
    renderRouteShell: function (routeFrame, routeMeta, instanceId, hostContext) {
      const frame = /** @type {DyniRouteFrame} */ (routeFrame && typeof routeFrame === "object" ? routeFrame : {});
      const routeId = trimText(frame.__dyniRouteId);
      const surface = routeMeta && typeof routeMeta.surface === "string" ? routeMeta.surface : "unknown";
      const clusterToken = trimText(frame.cluster)
        .replace(/[^a-zA-Z0-9_-]/g, "-")
        .replace(/-{2,}/g, "-")
        .replace(/^-+|-+$/g, "");
      const kindToken = trimText(frame.kind)
        .replace(/[^a-zA-Z0-9_-]/g, "-")
        .replace(/-{2,}/g, "-")
        .replace(/^-+|-+$/g, "");
      const surfaceToken =
        surface === "canvas-dom"
          ? "canvas"
          : surface === "html"
            ? "html"
            : trimText(surface)
                .replace(/[^a-zA-Z0-9_-]/g, "-")
                .replace(/-{2,}/g, "-")
                .replace(/^-+|-+$/g, "") || "unknown";
      const shellClasses = [
        "widgetData",
        "dyni-shell",
        "dyni-surface-" + surfaceToken,
        "dyni-kind-" + (kindToken || "unknown")
      ];
      const shellStyle = resolveShellStyle(routeMeta, frame);
      const shellInner = resolveInnerHtml(surface);
      const resolvedInstanceId = resolveInstanceId(instanceId, hostContext);

      if (!routeMeta) {
        shellClasses.push("dyni-shell-unknown");
      } else if (clusterToken) {
        shellClasses.push("dyni-cluster-" + clusterToken);
      }

      const instanceIdAttr = String(resolvedInstanceId)
        .replace(/&/g, "&amp;")
        .replace(/"/g, "&quot;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
      const routeIdAttr = String(routeId)
        .replace(/&/g, "&amp;")
        .replace(/"/g, "&quot;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
      const surfaceAttr = String(surface)
        .replace(/&/g, "&amp;")
        .replace(/"/g, "&quot;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");

      return (
        '<div class="' +
        shellClasses.join(" ") +
        '"' +
        ' data-dyni-instance="' +
        instanceIdAttr +
        '"' +
        ' data-dyni-route="' +
        routeIdAttr +
        '"' +
        ' data-dyni-surface="' +
        surfaceAttr +
        '"' +
        shellStyle +
        ">" +
        shellInner +
        "</div>"
      );
    }
  });
})(this);

/**
 * @file DyniPlugin Route Activation Payload Builder - Route metadata and payload assembly helpers
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  /** @typedef {DyniClusterRoute & { routeId: string }} DyniActivationRouteMeta */
  /** @typedef {{ translate: (props: DyniMapperProps, routeContext: DyniMapperRouteContextWithViewModel) => Record<string, unknown> }} DyniActivationMapper */
  /** @typedef {{ createToolkit: (props?: DyniMapperProps) => DyniMapperToolkit }} DyniActivationToolkitSpec */
  /** @typedef {{ mapper: DyniActivationMapper, viewModel: DyniMapperViewModel | null, rendererSpec: unknown }} DyniActivationRouteCache */
  /** @typedef {DyniMapperRouteContextWithViewModel & { routeId: string, cluster: string, kind: string }} DyniActivationRouteContext */
  /** @typedef {{ routeFrame: DyniRouteFrame, revision: unknown, rootEl: unknown, shellEl: unknown, hostContext: unknown }} DyniActivationSnapshot */
  /** @typedef {{ snapshot: DyniActivationSnapshot, routeMeta: DyniActivationRouteMeta, routeCache: DyniActivationRouteCache, toolkitSpec: DyniActivationToolkitSpec, surfaces: DyniSurfaceRuntimeApi }} DyniActivatedPayloadOptions */
  /** @typedef {{ areComponentsLoaded: (ids: string[]) => boolean }} DyniActivationLoader */
  /** @typedef {{ hasShadowCssText: (url: string) => boolean }} DyniActivationThemeRuntime */
  /** @typedef {{ snapshot: DyniActivationSnapshot, routeMeta: DyniActivationRouteMeta, routeCache: DyniActivationRouteCache, toolkitSpec: DyniActivationToolkitSpec }} DyniPayloadBuildRequest */

  const ns = /** @type {DyniPluginNamespace} */ (root.DyniPlugin);
  const runtime = /** @type {DyniRuntimeNamespace} */ (ns.runtime);
  const components = /** @type {{ DyniValueMath: { create: () => DyniValueMathApi } }} */ (root.DyniComponents);
  const valueMath = components.DyniValueMath.create();

  /** @param {unknown} value @param {string} name @returns {Record<string, unknown>} */
  const ensureObject = function (value, name) {
    return /** @type {Record<string, unknown>} */ (
      valueMath.ensureObject(value, "RouteActivationPayloadBuilder: " + name)
    );
  };
  const trimText = valueMath.trimText;

  /** @param {unknown} routeMeta @param {string} routeId @returns {asserts routeMeta is DyniActivationRouteMeta} */
  function ensureRouteMeta(routeMeta, routeId) {
    if (!routeMeta || typeof routeMeta !== "object") {
      throw new Error("RouteActivationController: unknown route '" + routeId + "'");
    }
    const meta = /** @type {Record<string, unknown>} */ (routeMeta);
    if (typeof meta.mapperId !== "string" || !meta.mapperId) {
      throw new Error("RouteActivationController: route '" + routeId + "' requires mapperId");
    }
    if (typeof meta.rendererId !== "string" || !meta.rendererId) {
      throw new Error("RouteActivationController: route '" + routeId + "' requires rendererId");
    }
    if (meta.surface !== "html" && meta.surface !== "canvas-dom") {
      throw new Error("RouteActivationController: route '" + routeId + "' requires surface 'html' or 'canvas-dom'");
    }
  }

  /** @param {DyniRouteFrame|null|undefined} routeFrame @returns {DyniMapperProps} */
  function cloneRouteProps(routeFrame) {
    const props = routeFrame && typeof routeFrame === "object" ? routeFrame : {};
    const cleanProps = Object.assign({}, props);
    delete cleanProps.__dyniRouteId;
    delete cleanProps.__dyniRawProps;
    return /** @type {DyniMapperProps} */ (cleanProps);
  }

  /** @param {DyniRouteFrame|null|undefined} routeFrame @param {unknown} defaultCluster @returns {string} */
  function resolveRouteId(routeFrame, defaultCluster) {
    const props = routeFrame && typeof routeFrame === "object" ? routeFrame : {};
    const cluster = trimText(props.cluster || defaultCluster);
    const kind = trimText(props.kind);
    if (!cluster) {
      throw new Error("RouteActivationController: routeFrame.cluster must be a non-empty string");
    }
    if (!kind) {
      throw new Error("RouteActivationController: routeFrame.kind must be a non-empty string");
    }
    return cluster + "/" + kind;
  }

  /** @param {DyniActivationRouteMeta} routeMeta @returns {string[]} */
  function resolveRouteRoots(routeMeta) {
    const roots = [routeMeta.mapperId];
    if (routeMeta.viewModelId) {
      roots.push(routeMeta.viewModelId);
    }
    roots.push(routeMeta.rendererId);
    return roots;
  }

  /** @param {string} rendererId @returns {string[]} */
  function resolveShadowCssUrls(rendererId) {
    const components = ns.config && ns.config.components ? ns.config.components : null;
    const componentDef = components && components[rendererId] ? components[rendererId] : null;
    return componentDef && Array.isArray(componentDef.shadowCss)
      ? componentDef.shadowCss.filter(function (url) {
          return typeof url === "string" && !!url;
        })
      : [];
  }

  /** @param {DyniActivationRouteMeta} routeMeta @param {DyniActivationRouteCache} routeCache @param {DyniMapperProps} mapperProps @param {DyniActivationToolkitSpec} toolkitSpec @returns {DyniActivationRouteContext} */
  function createRouteContext(routeMeta, routeCache, mapperProps, toolkitSpec) {
    return {
      routeId: routeMeta.routeId,
      cluster: routeMeta.cluster,
      kind: routeMeta.kind,
      viewModel: routeMeta.viewModelId ? routeCache.viewModel : null,
      toolkit: toolkitSpec.createToolkit(mapperProps)
    };
  }

  /** @param {Record<string, unknown>} finalProps @param {Record<string, unknown>} mappedProps @returns {Record<string, unknown>} */
  function mergeRendererProps(finalProps, mappedProps) {
    if (
      mappedProps.rendererProps &&
      typeof mappedProps.rendererProps === "object" &&
      !Array.isArray(mappedProps.rendererProps)
    ) {
      Object.assign(finalProps, mappedProps.rendererProps);
    }

    if (Object.prototype.hasOwnProperty.call(finalProps, "renderer")) {
      delete finalProps.renderer;
    }
    if (Object.prototype.hasOwnProperty.call(finalProps, "rendererProps")) {
      delete finalProps.rendererProps;
    }

    return finalProps;
  }

  /** @param {DyniActivatedPayloadOptions} options */
  function buildActivatedPayload(options) {
    const snapshot = /** @type {DyniActivationSnapshot} */ (ensureObject(options.snapshot, "snapshot"));
    const routeMeta = /** @type {DyniActivationRouteMeta} */ (
      /** @type {unknown} */ (ensureObject(options.routeMeta, "routeMeta"))
    );
    const routeCache = /** @type {DyniActivationRouteCache} */ (ensureObject(options.routeCache, "routeCache"));
    const toolkitSpec = /** @type {DyniActivationToolkitSpec} */ (ensureObject(options.toolkitSpec, "toolkitSpec"));
    const surfaces = /** @type {DyniSurfaceRuntimeApi} */ (
      /** @type {unknown} */ (ensureObject(options.surfaces, "surfaces"))
    );
    const routeFrame = snapshot.routeFrame;
    const mapperProps = cloneRouteProps(routeFrame);
    const routeContext = createRouteContext(routeMeta, routeCache, mapperProps, toolkitSpec);
    const mappedProps = routeCache.mapper.translate(mapperProps, routeContext) || {};
    var mappedSignature = JSON.stringify(mappedProps);
    const finalProps = mergeRendererProps(Object.assign({}, mapperProps, mappedProps), mappedProps);

    if (routeMeta.surface === "html") {
      surfaces.materializeSurfacePolicyProps({
        hostContext: snapshot.hostContext,
        rendererId: routeMeta.rendererId,
        props: finalProps
      });
    }

    return {
      routeId: routeMeta.routeId,
      route: routeMeta,
      surface: routeMeta.surface,
      rendererId: routeMeta.rendererId,
      rendererSpec: routeCache.rendererSpec,
      rootEl: snapshot.rootEl,
      shellEl: snapshot.shellEl,
      hostContext: snapshot.hostContext,
      props: finalProps,
      rawProps: mapperProps,
      revision: snapshot.revision,
      shadowCssUrls: routeMeta.surface === "html" ? resolveShadowCssUrls(routeMeta.rendererId) : [],
      __mappedSignature: mappedSignature
    };
  }

  /** @param {DyniActivationRouteMeta} routeMeta @param {DyniActivationLoader} loader @param {DyniActivationThemeRuntime} themeRuntime @returns {boolean} */
  function resolveWarmReady(routeMeta, loader, themeRuntime) {
    const routeRoots = resolveRouteRoots(routeMeta);
    if (!loader.areComponentsLoaded(routeRoots)) {
      return false;
    }
    if (routeMeta.surface !== "html") {
      return true;
    }
    const shadowCssUrls = resolveShadowCssUrls(routeMeta.rendererId);
    for (let i = 0; i < shadowCssUrls.length; i += 1) {
      if (!themeRuntime.hasShadowCssText(shadowCssUrls[i])) {
        return false;
      }
    }
    return true;
  }

  /** @param {{ loader: DyniActivationLoader, themeRuntime: DyniActivationThemeRuntime, surfaces: DyniSurfaceRuntimeApi }} options */
  function createPayloadBuilder(options) {
    const loader = /** @type {DyniActivationLoader} */ (ensureObject(options.loader, "loader"));
    const themeRuntime = /** @type {DyniActivationThemeRuntime} */ (ensureObject(options.themeRuntime, "themeRuntime"));
    const surfaces = /** @type {DyniSurfaceRuntimeApi} */ (
      /** @type {unknown} */ (ensureObject(options.surfaces, "surfaces"))
    );

    if (typeof loader.areComponentsLoaded !== "function") {
      throw new Error("RouteActivationPayloadBuilder: loader.areComponentsLoaded must be a function");
    }
    if (typeof themeRuntime.hasShadowCssText !== "function") {
      throw new Error("RouteActivationPayloadBuilder: themeRuntime.hasShadowCssText must be a function");
    }
    if (typeof surfaces.materializeSurfacePolicyProps !== "function") {
      throw new Error("RouteActivationPayloadBuilder: surfaces.materializeSurfacePolicyProps must be a function");
    }

    return Object.freeze({
      ensureRouteMeta: ensureRouteMeta,
      cloneRouteProps: cloneRouteProps,
      resolveRouteId: resolveRouteId,
      resolveRouteRoots: resolveRouteRoots,
      resolveShadowCssUrls: resolveShadowCssUrls,
      /** @param {DyniActivationRouteMeta} routeMeta @returns {boolean} */
      resolveWarmReady: function (routeMeta) {
        return resolveWarmReady(routeMeta, loader, themeRuntime);
      },
      /** @param {DyniPayloadBuildRequest} options */
      buildActivatedPayload: function (options) {
        return buildActivatedPayload({
          snapshot: options.snapshot,
          routeMeta: options.routeMeta,
          routeCache: options.routeCache,
          toolkitSpec: options.toolkitSpec,
          surfaces: surfaces
        });
      }
    });
  }

  /** @type {DyniRuntimeNamespace & Record<string, unknown>} */ (runtime).routeActivationPayloadBuilder = Object.freeze(
    {
      createPayloadBuilder: createPayloadBuilder
    }
  );
})(this);

/**
 * @file DyniPlugin Route Activation Latest Wins - Pending activation state and cancellation handling
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  /** @typedef {{ rendererId: string, surface: "html" | "canvas-dom" }} DyniLatestWinsRouteMeta */
  /** @typedef {(value: unknown | PromiseLike<unknown>) => void} DyniLatestWinsResolve */
  /** @typedef {(reason?: unknown) => void} DyniLatestWinsReject */
  /** @typedef {{ routeId: string, latestSnapshot: unknown, latestRouteMeta: DyniLatestWinsRouteMeta, promise: Promise<unknown>, loadStarted: boolean, settled: boolean, resolve: (value: unknown) => void, reject: (error: unknown) => void }} DyniLatestWinsEntry */
  /** @typedef {{ loader: { loadComponent: (id: string) => Promise<unknown> }, themeRuntime: { preloadShadowCssUrls: (urls: string[]) => Promise<unknown> }, resolveRouteRoots: (routeMeta: DyniLatestWinsRouteMeta) => string[], resolveShadowCssUrls: (rendererId: string) => string[], buildPayload: (snapshot: unknown, routeMeta: DyniLatestWinsRouteMeta) => unknown }} DyniLatestWinsDependencies */

  const ns = /** @type {DyniPluginNamespace} */ (root.DyniPlugin);
  const runtime = /** @type {DyniRuntimeNamespace} */ (ns.runtime);

  /** @param {{ discardedActivation: unknown }} options */
  function createLatestWinsState(options) {
    const discardedActivation = options.discardedActivation;
    if (!discardedActivation) {
      throw new Error("RouteActivationLatestWins: discardedActivation must be provided");
    }

    let destroyed = false;
    /** @type {DyniLatestWinsEntry | null} */
    let currentEntry = null;

    /** @returns {void} */
    function ensureNotDestroyed() {
      if (destroyed) {
        throw new Error("RouteActivationError: controller destroyed");
      }
    }

    /** @returns {DyniLatestWinsEntry | null} */
    function getPendingEntry() {
      return currentEntry && !currentEntry.settled ? currentEntry : null;
    }

    /** @param {DyniLatestWinsEntry} entry */
    function clearCurrentEntry(entry) {
      if (currentEntry === entry) {
        currentEntry = null;
      }
    }

    /** @param {string} routeId @param {unknown} snapshot @param {DyniLatestWinsRouteMeta} routeMeta @returns {DyniLatestWinsEntry} */
    function createPendingEntry(routeId, snapshot, routeMeta) {
      /** @type {DyniLatestWinsResolve} */
      let resolveFn = function () {
        throw new Error("RouteActivationLatestWins: activation promise resolver is unavailable");
      };
      /** @type {DyniLatestWinsReject} */
      let rejectFn = function () {
        throw new Error("RouteActivationLatestWins: activation promise rejecter is unavailable");
      };
      /** @type {DyniLatestWinsEntry} */
      const entry = {
        routeId: routeId,
        latestSnapshot: snapshot,
        latestRouteMeta: routeMeta,
        promise: /** @type {Promise<unknown>} */ (/** @type {unknown} */ (null)),
        loadStarted: false,
        settled: false,
        resolve: /** @type {(value: unknown) => void} */ (/** @type {unknown} */ (null)),
        reject: /** @type {(error: unknown) => void} */ (/** @type {unknown} */ (null))
      };

      entry.promise = new Promise(function (resolve, reject) {
        resolveFn = resolve;
        rejectFn = reject;
      });

      entry.resolve = function (value) {
        if (entry.settled) {
          return;
        }
        entry.settled = true;
        clearCurrentEntry(entry);
        resolveFn(value);
      };
      entry.reject = function (error) {
        if (entry.settled) {
          return;
        }
        entry.settled = true;
        clearCurrentEntry(entry);
        rejectFn(error);
      };

      currentEntry = entry;
      return entry;
    }

    /** @param {DyniLatestWinsEntry} entry @param {DyniLatestWinsDependencies} deps @returns {Promise<unknown>} */
    function activateCold(entry, deps) {
      if (entry.loadStarted) {
        return entry.promise;
      }
      entry.loadStarted = true;

      /** @returns {Promise<unknown>} */
      function runLoadCycle() {
        if (destroyed) {
          entry.resolve(discardedActivation);
          return Promise.resolve();
        }

        const routeMeta = entry.latestRouteMeta;
        const routeRoots = deps.resolveRouteRoots(routeMeta).concat("ClusterMapperToolkit");
        const uniqueLoadIds = Array.from(new Set(routeRoots));
        const shadowCssUrls = deps.resolveShadowCssUrls(routeMeta.rendererId);

        return Promise.all(
          uniqueLoadIds.map(function (id) {
            return deps.loader.loadComponent(id);
          })
        ).then(function () {
          if (destroyed) {
            entry.resolve(discardedActivation);
            return null;
          }
          if (entry.latestRouteMeta !== routeMeta) {
            return runLoadCycle();
          }
          if (routeMeta.surface !== "html") {
            const payload = deps.buildPayload(entry.latestSnapshot, routeMeta);
            entry.resolve(payload);
            return null;
          }
          return deps.themeRuntime.preloadShadowCssUrls(shadowCssUrls).then(function () {
            if (destroyed) {
              entry.resolve(discardedActivation);
              return null;
            }
            if (entry.latestRouteMeta !== routeMeta) {
              return runLoadCycle();
            }
            const payload = deps.buildPayload(entry.latestSnapshot, routeMeta);
            entry.resolve(payload);
            return null;
          });
        });
      }

      runLoadCycle().catch(function (error) {
        if (entry.settled) {
          return;
        }
        entry.reject(error);
      });

      return entry.promise;
    }

    /** @returns {void} */
    function destroy() {
      if (destroyed) {
        return;
      }
      destroyed = true;

      const pending = currentEntry;
      if (pending && !pending.settled) {
        pending.resolve(discardedActivation);
      }
    }

    return {
      ensureNotDestroyed: ensureNotDestroyed,
      getPendingEntry: getPendingEntry,
      createPendingEntry: createPendingEntry,
      activateCold: activateCold,
      destroy: destroy
    };
  }

  /** @type {DyniRuntimeNamespace & Record<string, unknown>} */ (runtime).routeActivationLatestWins = Object.freeze({
    createLatestWinsState: createLatestWinsState
  });
})(this);

/**
 * @file DyniPlugin Route Activation Controller - Lazy route activation service composition
 * Documentation: documentation/architecture/cluster-widget-system.md
 */
(function (root) {
  "use strict";

  /** @typedef {DyniClusterRoute & { routeId: string }} DyniControllerRouteMeta */
  /** @typedef {{ translate: (props: DyniMapperProps, routeContext: DyniMapperRouteContextWithViewModel) => Record<string, unknown> }} DyniControllerMapper */
  /** @typedef {{ build: (props: DyniMapperProps, toolkit?: DyniMapperToolkit) => unknown }} DyniControllerViewModel */
  /** @typedef {{ createCommittedRenderer?: unknown, renderCanvas?: unknown }} DyniControllerRendererSpec */
  /** @typedef {{ mapper: DyniControllerMapper | null, viewModel: DyniControllerViewModel | null, rendererSpec: DyniControllerRendererSpec | null, lastMemoKey: unknown, lastRootEl: unknown, lastShellEl: unknown }} DyniControllerRouteCache */
  /** @typedef {{ createToolkit: (props?: DyniMapperProps) => DyniMapperToolkit }} DyniControllerToolkitSpec */
  /** @typedef {{ routeFrame: DyniRouteFrame, revision: number, rootEl: unknown, shellEl: unknown, hostContext: unknown, routeId: string, routeMeta: DyniControllerRouteMeta }} DyniControllerSnapshot */
  /** @typedef {{ surface: "html" | "canvas-dom", props: Record<string, unknown>, rootEl: unknown, shellEl: unknown, __mappedSignature: unknown }} DyniControllerPayload */
  /** @typedef {{ loadComponent: (id: string) => Promise<unknown>, createInstance: (id: string, def: unknown) => unknown, areComponentsLoaded: (ids: string[]) => boolean }} DyniControllerLoader */
  /** @typedef {{ preloadShadowCssUrls: (urls: string[]) => Promise<unknown>, hasShadowCssText: (url: string) => boolean }} DyniControllerThemeRuntime */
  /** @typedef {{ ensureRouteMeta: (routeMeta: unknown, routeId: string) => void, resolveRouteId: (routeFrame: DyniRouteFrame, defaultCluster: unknown) => string, resolveWarmReady: (routeMeta: DyniControllerRouteMeta) => boolean, resolveRouteRoots: (routeMeta: DyniControllerRouteMeta) => string[], resolveShadowCssUrls: (rendererId: string) => string[], buildActivatedPayload: (options: { snapshot: DyniControllerSnapshot, routeMeta: DyniControllerRouteMeta, routeCache: DyniControllerRouteCache, toolkitSpec: DyniControllerToolkitSpec }) => DyniControllerPayload }} DyniControllerPayloadBuilder */
  /** @typedef {{ settled: boolean, latestSnapshot: DyniControllerSnapshot, latestRouteMeta: DyniControllerRouteMeta, promise: Promise<unknown> }} DyniControllerPendingEntry */
  /** @typedef {{ ensureNotDestroyed: () => void, getPendingEntry: () => DyniControllerPendingEntry | null, createPendingEntry: (routeId: string, snapshot: DyniControllerSnapshot, routeMeta: DyniControllerRouteMeta) => DyniControllerPendingEntry, activateCold: (entry: DyniControllerPendingEntry, dependencies: unknown) => Promise<unknown>, destroy: () => void }} DyniControllerLatestWins */
  /** @typedef {{ createPayloadBuilder: (options: { loader: DyniControllerLoader, themeRuntime: DyniControllerThemeRuntime, surfaces: DyniSurfaceRuntimeApi }) => DyniControllerPayloadBuilder }} DyniControllerPayloadBuilderFactory */
  /** @typedef {{ createLatestWinsState: (options: { discardedActivation: object }) => DyniControllerLatestWins }} DyniControllerLatestWinsFactory */
  /** @typedef {DyniRuntimeNamespace & { componentLoader?: DyniControllerLoader, theme?: DyniControllerThemeRuntime, routeActivationPayloadBuilder?: DyniControllerPayloadBuilderFactory, routeActivationLatestWins?: DyniControllerLatestWinsFactory }} DyniControllerRuntime */

  const ns = /** @type {DyniPluginNamespace} */ (root.DyniPlugin);
  const runtime = /** @type {DyniControllerRuntime} */ (ns.runtime);
  const DISCARDED_ACTIVATION = Object.freeze({ discarded: true });
  const components = /** @type {{ DyniValueMath: { create: () => DyniValueMathApi } }} */ (root.DyniComponents);
  const valueMath = components.DyniValueMath.create();

  /** @param {unknown} value @param {string} name @returns {Record<string, unknown>} */
  const ensureObject = function (value, name) {
    return /** @type {Record<string, unknown>} */ (valueMath.ensureObject(value, "RouteActivationController: " + name));
  };

  /** @param {unknown} def */
  function createWidgetController(def) {
    const widgetDef = ensureObject(def || {}, "def");
    const loader = /** @type {DyniControllerLoader} */ (runtime.componentLoader);
    const themeRuntime = runtime.theme;
    const surfaces = runtime.surfaces;
    const payloadBuilderFactory = runtime.routeActivationPayloadBuilder;
    const latestWinsFactory = runtime.routeActivationLatestWins;

    if (!loader || typeof loader.loadComponent !== "function" || typeof loader.createInstance !== "function") {
      throw new Error("RouteActivationController: runtime.componentLoader must be available");
    }
    if (
      !themeRuntime ||
      typeof themeRuntime.preloadShadowCssUrls !== "function" ||
      typeof themeRuntime.hasShadowCssText !== "function"
    ) {
      throw new Error("RouteActivationController: runtime.theme must be available");
    }
    if (!surfaces || typeof surfaces.materializeSurfacePolicyProps !== "function") {
      throw new Error("RouteActivationController: runtime.surfaces.materializeSurfacePolicyProps must be available");
    }
    if (!payloadBuilderFactory || typeof payloadBuilderFactory.createPayloadBuilder !== "function") {
      throw new Error("RouteActivationController: runtime.routeActivationPayloadBuilder must be available");
    }
    if (!latestWinsFactory || typeof latestWinsFactory.createLatestWinsState !== "function") {
      throw new Error("RouteActivationController: runtime.routeActivationLatestWins must be available");
    }

    /** @type {DyniControllerToolkitSpec | null} */
    let toolkitSpec = null;
    /** @type {Record<string, DyniControllerRouteCache>} */
    const routeCacheById = Object.create(null);
    const payloadBuilder = payloadBuilderFactory.createPayloadBuilder({
      loader: loader,
      themeRuntime: themeRuntime,
      surfaces: surfaces
    });
    const latestWins = latestWinsFactory.createLatestWinsState({
      discardedActivation: DISCARDED_ACTIVATION
    });

    /** @returns {DyniControllerToolkitSpec} */
    function ensureToolkit() {
      if (toolkitSpec) {
        return toolkitSpec;
      }
      if (!loader.areComponentsLoaded(["ClusterMapperToolkit"])) {
        throw new Error("RouteActivationError: ClusterMapperToolkit is not loaded");
      }
      toolkitSpec = /** @type {DyniControllerToolkitSpec} */ (loader.createInstance("ClusterMapperToolkit", widgetDef));
      return toolkitSpec;
    }

    /** @param {DyniControllerRouteMeta} routeMeta @returns {DyniControllerRouteCache} */
    function ensureRouteInstance(routeMeta) {
      const routeId = routeMeta.routeId;
      let cache = routeCacheById[routeId];
      if (!cache) {
        cache = {
          mapper: null,
          viewModel: null,
          rendererSpec: null,
          lastMemoKey: null,
          lastRootEl: null,
          lastShellEl: null
        };
        routeCacheById[routeId] = cache;
      }
      if (cache.mapper && cache.rendererSpec && (routeMeta.viewModelId ? !!cache.viewModel : true)) {
        return cache;
      }

      cache.mapper = /** @type {DyniControllerMapper} */ (loader.createInstance(routeMeta.mapperId, widgetDef));
      cache.viewModel = routeMeta.viewModelId
        ? /** @type {DyniControllerViewModel} */ (loader.createInstance(routeMeta.viewModelId, widgetDef))
        : null;
      cache.rendererSpec = /** @type {DyniControllerRendererSpec} */ (
        loader.createInstance(routeMeta.rendererId, widgetDef)
      );

      if (!cache.mapper || typeof cache.mapper.translate !== "function") {
        throw new Error("RouteActivationController: mapper '" + routeMeta.mapperId + "' must implement translate()");
      }
      if (routeMeta.viewModelId && (!cache.viewModel || typeof cache.viewModel.build !== "function")) {
        throw new Error("RouteActivationController: view model '" + routeMeta.viewModelId + "' must implement build()");
      }
      if (
        routeMeta.surface === "html" &&
        (!cache.rendererSpec || typeof cache.rendererSpec.createCommittedRenderer !== "function")
      ) {
        throw new Error(
          "RouteActivationController: renderer '" +
            routeMeta.rendererId +
            "' must implement createCommittedRenderer() for surface 'html'"
        );
      }
      if (
        routeMeta.surface === "canvas-dom" &&
        (!cache.rendererSpec || typeof cache.rendererSpec.renderCanvas !== "function")
      ) {
        throw new Error(
          "RouteActivationController: renderer '" +
            routeMeta.rendererId +
            "' must implement renderCanvas() for surface 'canvas-dom'"
        );
      }

      return cache;
    }

    /** @returns {void} */
    function invalidateMemoState() {
      Object.keys(routeCacheById).forEach(function (routeId) {
        const routeCache = routeCacheById[routeId];
        if (!routeCache) {
          return;
        }
        routeCache.lastMemoKey = null;
        routeCache.lastRootEl = null;
        routeCache.lastShellEl = null;
      });
    }

    /** @param {DyniControllerSnapshot} snapshot @param {DyniControllerRouteMeta} routeMeta @returns {DyniControllerPayload | typeof DISCARDED_ACTIVATION} */
    function buildPayload(snapshot, routeMeta) {
      const routeCache = ensureRouteInstance(routeMeta);
      const toolkit = ensureToolkit();
      var payload = payloadBuilder.buildActivatedPayload({
        snapshot: snapshot,
        routeMeta: routeMeta,
        routeCache: routeCache,
        toolkitSpec: toolkit
      });

      if (payload.surface !== "canvas-dom") {
        return payload;
      }

      var memoKey =
        payload.__mappedSignature +
        "|" +
        (payload.props.nightMode ? "1" : "0") +
        "|" +
        (payload.props.editing ? "1" : "0");
      var sameRootEl = routeCache.lastRootEl === payload.rootEl;
      var sameShellEl = routeCache.lastShellEl === payload.shellEl;
      if (routeCache.lastMemoKey === memoKey && sameRootEl && sameShellEl) {
        return DISCARDED_ACTIVATION;
      }
      routeCache.lastMemoKey = memoKey;
      routeCache.lastRootEl = payload.rootEl;
      routeCache.lastShellEl = payload.shellEl;
      return payload;
    }

    /** @param {unknown} options @returns {DyniControllerPayload | typeof DISCARDED_ACTIVATION | Promise<unknown>} */
    function activateCommittedRoute(options) {
      latestWins.ensureNotDestroyed();

      const input = ensureObject(options, "options");
      const routeFrame = /** @type {DyniRouteFrame} */ (ensureObject(input.routeFrame, "options.routeFrame"));
      const revision = input.revision;
      const rootEl = input.rootEl;
      const shellEl = input.shellEl;
      const hostContext = input.hostContext;

      if (typeof revision !== "number" || !Number.isFinite(revision)) {
        throw new Error("RouteActivationController: options.revision must be finite");
      }
      if (!rootEl) {
        throw new Error("RouteActivationController: options.rootEl must be provided");
      }
      if (!shellEl) {
        throw new Error("RouteActivationController: options.shellEl must be provided");
      }

      const routeId = payloadBuilder.resolveRouteId(routeFrame, widgetDef.cluster);
      const config = ns.config || {};
      const clusterRoutes =
        config.clusterRoutes && config.clusterRoutes.byRouteId ? config.clusterRoutes.byRouteId : null;
      const routeMeta = /** @type {DyniControllerRouteMeta | null} */ (clusterRoutes ? clusterRoutes[routeId] : null);
      payloadBuilder.ensureRouteMeta(routeMeta, routeId);
      const checkedRouteMeta = /** @type {DyniControllerRouteMeta} */ (routeMeta);

      /** @type {DyniControllerSnapshot} */
      const snapshot = {
        routeFrame: routeFrame,
        revision: revision,
        rootEl: rootEl,
        shellEl: shellEl,
        hostContext: hostContext,
        routeId: routeId,
        routeMeta: checkedRouteMeta
      };

      const pendingEntry = latestWins.getPendingEntry();
      if (pendingEntry && !pendingEntry.settled) {
        pendingEntry.latestSnapshot = snapshot;
        pendingEntry.latestRouteMeta = checkedRouteMeta;
        return pendingEntry.promise;
      }

      if (payloadBuilder.resolveWarmReady(checkedRouteMeta)) {
        return buildPayload(snapshot, checkedRouteMeta);
      }

      return latestWins.activateCold(latestWins.createPendingEntry(routeId, snapshot, checkedRouteMeta), {
        loader: loader,
        themeRuntime: themeRuntime,
        resolveRouteRoots: payloadBuilder.resolveRouteRoots,
        resolveShadowCssUrls: payloadBuilder.resolveShadowCssUrls,
        buildPayload: buildPayload
      });
    }

    function destroy() {
      latestWins.destroy();
      invalidateMemoState();
      toolkitSpec = null;
      Object.keys(routeCacheById).forEach(function (routeId) {
        delete routeCacheById[routeId];
      });
    }

    return {
      activateCommittedRoute: activateCommittedRoute,
      invalidateMemoState: invalidateMemoState,
      destroy: destroy
    };
  }

  /** @type {DyniRuntimeNamespace & Record<string, unknown>} */ (runtime).routeActivation = Object.freeze({
    DISCARDED_ACTIVATION: DISCARDED_ACTIVATION,
    createWidgetController: createWidgetController,
    /** @param {unknown} error */
    reportActivationError: function (error) {
      throw error;
    }
  });
})(this);

/**
 * @file DyniPlugin Init - Runtime initialization and widget registration
 * Documentation: documentation/architecture/component-system.md
 */
(function (/** @type {DyniInitRoot} */ root) {
  "use strict";

  const ns = root.DyniPlugin;
  const runtime = ns.runtime;
  const state = ns.state;

  /** @returns {DyniInitThemeRuntime} */
  function requireThemeRuntimeBoundary() {
    if (
      !runtime.theme ||
      typeof runtime.theme.configure !== "function" ||
      typeof runtime.theme.applyToRoot !== "function"
    ) {
      throw new Error("dyninstruments: runtime.theme boundary is required");
    }
    return runtime.theme;
  }

  /** @returns {DyniClusterShellRendererApi} */
  function requireClusterShellRenderer() {
    if (
      !runtime.clusterShellRenderer ||
      typeof runtime.clusterShellRenderer.normalizeRouteFrame !== "function" ||
      typeof runtime.clusterShellRenderer.renderRouteShell !== "function"
    ) {
      throw new Error("dyninstruments: runtime.clusterShellRenderer boundary is required");
    }
    return runtime.clusterShellRenderer;
  }

  /** @returns {DyniInitGeneration} */
  function getStartupGeneration() {
    return (
      ns.startupGeneration || {
        id: "legacy",
        entrypoint: "legacy",
        baseUrl: ns.baseUrl || "",
        hostApi: ns.avnavApi || null
      }
    );
  }

  /** @param {string} generationId */
  function clearGenerationState(generationId) {
    if (generationId && state.initGenerationId !== generationId) {
      return;
    }
    if (state.hostActionBridge) {
      state.hostActionBridge.destroy();
    }
    state.hostActionBridge = null;
    state.initStarted = false;
    state.initPromise = null;
    state.initGenerationId = null;
    runtime.hostActions = null;
    runtime.componentLoader = null;
  }

  /** @param {string} generationId @returns {() => void} */
  function createShutdown(generationId) {
    let shutdownDone = false;
    return function () {
      if (shutdownDone) {
        return;
      }
      shutdownDone = true;
      clearGenerationState(generationId);
    };
  }

  /** @returns {DyniInitAvnavApi | null} */
  function requireAvnavApi() {
    const avnavApi = runtime.getAvnavApi(root);
    if (!avnavApi) {
      return null;
    }
    if (typeof avnavApi.registerWidget !== "function") {
      throw new Error("dyninstruments: avnav.api.registerWidget missing");
    }
    if (typeof avnavApi.log !== "function") {
      throw new Error("dyninstruments: avnav.api.log missing");
    }
    return avnavApi;
  }

  /** @returns {Promise<(() => void) | undefined>} */
  function runInit() {
    const generation = getStartupGeneration();
    if (state.initStarted && state.initGenerationId === generation.id) {
      return /** @type {Promise<(() => void) | undefined>} */ (state.initPromise);
    }

    if (state.initStarted && state.initGenerationId) {
      clearGenerationState(state.initGenerationId);
    }

    if (state.initStarted) {
      return /** @type {Promise<(() => void) | undefined>} */ (state.initPromise);
    }

    const avnavApi = requireAvnavApi();
    if (!avnavApi) {
      return Promise.resolve(undefined);
    }

    const hostActionBridge = runtime.createTemporaryHostActionBridge();
    state.hostActionBridge = hostActionBridge;
    runtime.hostActions = function () {
      return hostActionBridge.getHostActions();
    };

    const config = ns.config;
    const components = config.components;
    const widgetDefinitions = config.widgetDefinitions;
    const themeRuntime = requireThemeRuntimeBoundary();
    requireClusterShellRenderer();

    state.initStarted = true;
    state.initGenerationId = generation.id;

    const loader = runtime.createComponentLoader(components);
    runtime.componentLoader = loader;

    const needed = loader.uniqueComponents(widgetDefinitions).slice();
    const startupPresetName = themeRuntime.resolveStartupPresetName(
      root.document ? root.document.documentElement : null
    );

    state.initPromise = Promise.all(needed.map(loader.loadComponent))
      .then(function () {
        if (state.initGenerationId !== generation.id) {
          return undefined;
        }

        themeRuntime.configure({
          activePresetName: startupPresetName
        });

        widgetDefinitions.forEach(function (widgetDef) {
          const componentSpec = loader.createInstance(widgetDef.widget, widgetDef.def);
          runtime.registerWidget(componentSpec, widgetDef);
        });

        avnavApi.log("dyninstruments component init ok (clustered): " + widgetDefinitions.length + " widgets");
        return createShutdown(generation.id);
      })
      .catch(function (error) {
        clearGenerationState(generation.id);
        avnavApi.log("dyninstruments init failed: " + String(error));
        throw error;
      });

    return state.initPromise;
  }

  runtime.runInit = runInit;
})(/** @type {DyniInitRoot} */ (/** @type {unknown} */ (this)));

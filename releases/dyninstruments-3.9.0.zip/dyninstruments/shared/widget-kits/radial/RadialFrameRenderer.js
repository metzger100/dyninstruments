/**
 * @file RadialFrameRenderer - Shared tick, label and frame drawing helpers for radial dials
 * Documentation: documentation/radial/gauge-shared-api.md
 */
(function (root, factory) {
  if (typeof define === "function" && define.amd) define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
  else {
    (root.DyniComponents = root.DyniComponents || {}).DyniRadialFrameRenderer = factory();
  }
})(this, function () {
  "use strict";
  const hasOwn = Object.prototype.hasOwnProperty;
  /** @type {DyniValueMathApi["isNullish"]} */
  let isNullish;

  /**
   * @param {unknown} def
   * @param {DyniComponentContext} componentContext
   * @returns {DyniRadialFrameRendererApi}
   */
  function create(def, componentContext) {
    const angle = componentContext.components.require("RadialAngleMath");
    isNullish = componentContext.components.require("ValueMath").isNullish;
    const tick = componentContext.components.require("RadialTickMath");
    const primitive = componentContext.components.require("RadialCanvasPrimitives");

    const toCanvas = angle.degToCanvasRad;
    const computeSweep = tick.computeSweep;
    const isBeyondEnd = tick.isBeyondEnd;
    const buildTickAngles = tick.buildTickAngles;
    const withCtx = primitive.withCtx;
    const drawRing = primitive.drawRing;
    /**
     * @param {DyniRadialDrawOptions} opts
     * @param {string} key
     * @param {unknown} defaultValue
     * @returns {number}
     */
    function readOptionNumber(opts, key, defaultValue) {
      return Number(hasOwn.call(opts, key) ? opts[key] : defaultValue);
    }

    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {number} cx
     * @param {number} cy
     * @param {number} rOuter
     * @param {DyniRadialDrawOptions} [opts]
     * @returns {void}
     */
    function drawTicks(ctx, cx, cy, rOuter, opts) {
      opts = opts || {};
      const ticksToDraw = buildTickAngles({
        startDeg: readOptionNumber(opts, "startDeg", 0),
        endDeg: readOptionNumber(opts, "endDeg", 360),
        stepMajor: readOptionNumber(opts, "stepMajor", 30),
        stepMinor: readOptionNumber(opts, "stepMinor", 10),
        includeEnd: !!opts.includeEnd,
        majorMode: hasOwn.call(opts, "majorMode") ? opts.majorMode : "absolute"
      });
      drawTicksFromAngles(ctx, cx, cy, rOuter, ticksToDraw, opts);
    }

    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {number} cx
     * @param {number} cy
     * @param {number} rOuter
     * @param {DyniRadialTickAngles} [angles]
     * @param {DyniRadialDrawOptions} [opts]
     * @returns {void}
     */
    function drawTicksFromAngles(ctx, cx, cy, rOuter, angles, opts) {
      opts = opts || {};
      angles = angles || { majors: [], minors: [] };

      const rot = readOptionNumber(opts, "rotationDeg", 0);
      const cfg = opts.angleCfg;

      const majorSource = hasOwn.call(opts, "major") ? opts.major : null;
      const minorSource = hasOwn.call(opts, "minor") ? opts.minor : null;
      const major = Object.assign({ len: 8, width: 2 }, majorSource || {});
      const minor = Object.assign({ len: 5, width: 1 }, minorSource || {});

      withCtx(
        ctx,
        function () {
          ctx.lineCap = /** @type {CanvasLineCap} */ (hasOwn.call(opts, "lineCap") ? opts.lineCap : "butt");

          if (angles.minors && angles.minors.length) {
            ctx.beginPath();
            ctx.lineWidth = minor.width;
            for (let i = 0; i < angles.minors.length; i++) {
              const deg = angles.minors[i];
              const t = toCanvas(deg, cfg, rot);
              const x1 = cx + Math.cos(t) * (rOuter - minor.len);
              const y1 = cy + Math.sin(t) * (rOuter - minor.len);
              const x2 = cx + Math.cos(t) * rOuter;
              const y2 = cy + Math.sin(t) * rOuter;
              ctx.moveTo(x1, y1);
              ctx.lineTo(x2, y2);
            }
            ctx.stroke();
          }

          if (angles.majors && angles.majors.length) {
            ctx.beginPath();
            ctx.lineWidth = major.width;
            for (let i = 0; i < angles.majors.length; i++) {
              const deg = angles.majors[i];
              const t = toCanvas(deg, cfg, rot);
              const x1 = cx + Math.cos(t) * (rOuter - major.len);
              const y1 = cy + Math.sin(t) * (rOuter - major.len);
              const x2 = cx + Math.cos(t) * rOuter;
              const y2 = cy + Math.sin(t) * rOuter;
              ctx.moveTo(x1, y1);
              ctx.lineTo(x2, y2);
            }
            ctx.stroke();
          }
        },
        {
          strokeStyle: opts.strokeStyle,
          alpha: !isNullish(opts.alpha) ? opts.alpha : 1
        }
      );
    }

    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {number} cx
     * @param {number} cy
     * @param {number} rOuter
     * @param {DyniRadialDrawOptions} [opts]
     * @returns {void}
     */
    function drawLabels(ctx, cx, cy, rOuter, opts) {
      opts = opts || {};
      const rot = readOptionNumber(opts, "rotationDeg", 0);
      const cfg = opts.angleCfg;

      const fontPx = Math.max(6, Math.floor(readOptionNumber(opts, "fontPx", 11)));
      const weight = Math.floor(Number(opts.weight));
      const family = hasOwn.call(opts, "family") ? opts.family : "sans-serif";
      const font = weight + " " + fontPx + "px " + family;

      const radiusOffset = hasOwn.call(opts, "radiusOffset")
        ? Number(opts.radiusOffset)
        : readOptionNumber(opts, "offset", 16);
      const rr = rOuter - radiusOffset;

      let angles = [];
      if (Array.isArray(opts.angles)) {
        angles = opts.angles.slice();
      } else {
        const startDeg = readOptionNumber(opts, "startDeg", 0);
        const endDeg = readOptionNumber(opts, "endDeg", 360);
        const step = Math.abs(readOptionNumber(opts, "step", 30)) || 30;
        const includeEnd = !!opts.includeEnd;
        const sweepInfo = computeSweep(startDeg, endDeg);
        const s = sweepInfo.s;
        const e = sweepInfo.e;
        const dir = sweepInfo.dir;

        const maxSteps = 5000;
        let count = 0;
        let a = s;
        while (!isBeyondEnd(a, e, dir, includeEnd) && count++ < maxSteps) {
          angles.push(a);
          a += dir * step;
        }
        if (includeEnd) angles.push(e);
      }

      const labelsMap = /** @type {Record<string, unknown> | null} */ (
        hasOwn.call(opts, "labelsMap") ? opts.labelsMap : opts.labels || null
      );
      const labelFormatter = /** @type {(deg: unknown) => string} */ (
        typeof opts.labelFormatter === "function"
          ? opts.labelFormatter
          : function (deg) {
              return String(deg);
            }
      );
      const labelFilter = /** @type {(deg: unknown) => unknown} */ (
        typeof opts.labelFilter === "function"
          ? opts.labelFilter
          : function () {
              return true;
            }
      );
      const textRotation = hasOwn.call(opts, "textRotation") ? opts.textRotation : "upright";

      withCtx(
        ctx,
        function () {
          ctx.font = font;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";

          for (let i = 0; i < angles.length; i++) {
            const deg = angles[i];
            if (!labelFilter(deg)) {
              continue;
            }

            let text;
            if (labelsMap && !isNullish(labelsMap[deg])) text = String(labelsMap[deg]);
            else text = labelFormatter(deg);

            if (!text) {
              continue;
            }

            const t = toCanvas(deg, cfg, rot);
            const x = cx + Math.cos(t) * rr;
            const y = cy + Math.sin(t) * rr;

            if (textRotation === "upright") {
              ctx.fillText(text, x, y);
            } else {
              ctx.save();
              ctx.translate(x, y);
              if (textRotation === "tangent") ctx.rotate(t + Math.PI / 2);
              else if (textRotation === "radial") ctx.rotate(t);
              ctx.fillText(text, 0, 0);
              ctx.restore();
            }
          }
        },
        {
          fillStyle: opts.fillStyle,
          alpha: !isNullish(opts.alpha) ? opts.alpha : 1
        }
      );
    }

    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {number} cx
     * @param {number} cy
     * @param {number} rOuter
     * @param {DyniRadialDrawOptions} [opts]
     * @returns {void}
     */
    function drawDialFrame(ctx, cx, cy, rOuter, opts) {
      opts = opts || {};
      const rot = readOptionNumber(opts, "rotationDeg", 0);

      if (opts.ring !== false) {
        const ringSource = hasOwn.call(opts, "ring") ? opts.ring : null;
        const ringOpts = /** @type {DyniRadialDrawOptions} */ (Object.assign({}, ringSource || {}));
        drawRing(ctx, cx, cy, rOuter, ringOpts);
      }

      if (opts.ticks) {
        const tOpts = /** @type {DyniRadialDrawOptions} */ (Object.assign({}, opts.ticks));
        tOpts.rotationDeg = !isNullish(tOpts.rotationDeg) ? tOpts.rotationDeg : rot;
        drawTicks(ctx, cx, cy, rOuter, tOpts);
      }

      if (opts.labels) {
        const lOpts = /** @type {DyniRadialDrawOptions} */ (Object.assign({}, opts.labels));
        lOpts.rotationDeg = !isNullish(lOpts.rotationDeg) ? lOpts.rotationDeg : rot;
        drawLabels(ctx, cx, cy, rOuter, lOpts);
      }
    }

    return {
      id: "RadialFrameRenderer",
      drawTicksFromAngles,
      drawTicks,
      drawLabels,
      drawDialFrame
    };
  }

  return { id: "RadialFrameRenderer", create };
});

/**
 * @file LinearGaugeEngineDrawing - Shared drawing helpers for linear gauge static layers and markers
 * Documentation: documentation/linear/linear-shared-api.md
 */
(function (root, factory) {
  if (typeof define === "function" && define.amd) define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
  else {
    (root.DyniComponents = root.DyniComponents || {}).DyniLinearGaugeEngineDrawing = factory();
  }
})(this, function () {
  "use strict";
  const hasOwn = Object.prototype.hasOwnProperty;

  /** @returns {DyniLinearGaugeEngineDrawingApi} */
  function create() {
    /**
     * @param {CanvasRenderingContext2D} layerCtx
     * @param {DyniLinearGaugeDrawingState} state
     * @param {DyniLinearColoredRange[]} sectors
     * @returns {void}
     */
    function drawStaticBack(layerCtx, state, sectors) {
      const layout = state.layout;
      const primitives = state.primitives;
      const mapValueToX = state.mapValueToX;

      primitives.drawTrack(layerCtx, state.layout.scaleX0, state.layout.scaleX1, state.layout.trackY, {
        lineWidth: layout.trackLineWidth,
        strokeStyle: state.color
      });

      for (let i = 0; i < sectors.length; i++) {
        const sector = sectors[i];
        if (!sector) continue;
        const from = Number(sector.from);
        const to = Number(sector.to);
        if (!Number.isFinite(from) || !Number.isFinite(to) || to <= from) continue;
        const x0 = mapValueToX(from, true);
        const x1 = mapValueToX(to, true);
        if (!Number.isFinite(x0) || !Number.isFinite(x1) || Math.abs(x1 - x0) <= 1) continue;
        primitives.drawBand(layerCtx, x0, x1, state.sectorBandY, state.trackThickness, { fillStyle: sector.color });
      }
    }

    /**
     * @param {CanvasRenderingContext2D} layerCtx
     * @param {DyniLinearGaugeDrawingState} state
     * @param {DyniLinearTicks} ticks
     * @param {unknown} showEndLabels
     * @param {DyniLinearTickLabelFormatter | null} labelFormatter
     * @returns {void}
     */
    function drawStaticFront(layerCtx, state, ticks, showEndLabels, labelFormatter) {
      const layout = state.layout;
      const primitives = state.primitives;
      const textLayout = state.textLayout;
      const math = state.math;
      const mapValueToX = state.mapValueToX;
      const majorStyle = { lineWidth: layout.majorTickWidth, strokeStyle: state.color };
      const minorStyle = { lineWidth: layout.minorTickWidth, strokeStyle: state.color };

      for (let i = 0; i < ticks.minor.length; i++) {
        const x = mapValueToX(ticks.minor[i], true);
        if (Number.isFinite(x))
          primitives.drawTick(layerCtx, Math.round(x), state.layout.trackY, layout.minorTickLen, minorStyle);
      }
      for (let i = 0; i < ticks.major.length; i++) {
        const x = mapValueToX(ticks.major[i], true);
        if (Number.isFinite(x))
          primitives.drawTick(layerCtx, Math.round(x), state.layout.trackY, layout.majorTickLen, majorStyle);
      }

      textLayout.drawTickLabels(layerCtx, state, ticks, showEndLabels, math, labelFormatter);
    }

    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {DyniLinearGaugeDrawingState} state
     * @param {DyniLinearGaugeLayout} layout
     * @param {DyniLinearGaugeTheme} theme
     * @param {DyniLinearCanvasPrimitivesApi} primitives
     * @param {DyniLinearMapValueToX} mapValueToX
     * @param {unknown} markerValue
     * @param {number} pointerDepthBase
     * @param {number} markerSizeBase
     * @param {DyniLinearDrawOptions} [opts]
     * @returns {void}
     */
    function drawPointerAtValue(
      ctx,
      state,
      layout,
      theme,
      primitives,
      mapValueToX,
      markerValue,
      pointerDepthBase,
      markerSizeBase,
      opts
    ) {
      const pointerNum = Number(markerValue);
      if (!Number.isFinite(pointerNum)) {
        return;
      }
      const pointerX = mapValueToX(pointerNum, true);
      if (!Number.isFinite(pointerX)) {
        return;
      }
      const markerOpts = opts || {};
      const optDepth = Number(markerOpts.depth);
      const optSide = Number(markerOpts.side);
      const basePointerSize = Number.isFinite(optDepth)
        ? Math.max(1, Math.floor(optDepth))
        : Math.max(1, Math.floor(pointerDepthBase));
      const defaultSide = Number.isFinite(Number(layout.pointerSide))
        ? Math.max(1, Math.floor(layout.pointerSide / 2))
        : Math.max(1, Math.floor(basePointerSize / 2));
      primitives.drawPointer(ctx, Math.round(pointerX), layout.trackY - Math.floor(state.trackThickness / 2) - 1, {
        depth: basePointerSize,
        side: Number.isFinite(optSide) ? Math.max(1, Math.floor(optSide)) : defaultSide,
        fillStyle: hasOwn.call(markerOpts, "fillStyle") ? markerOpts.fillStyle : theme.colors.pointer
      });
    }

    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {DyniLinearGaugeDrawingState} state
     * @param {DyniLinearGaugeLayout} layout
     * @param {DyniLinearGaugeTheme} theme
     * @param {DyniLinearCanvasPrimitivesApi} primitives
     * @param {DyniLinearMapValueToX} mapValueToX
     * @param {unknown} markerValue
     * @param {number} markerSizeBase
     * @param {DyniLinearDrawOptions} [opts]
     * @returns {void}
     */
    function drawMarkerAtValue(ctx, state, layout, theme, primitives, mapValueToX, markerValue, markerSizeBase, opts) {
      const markerNum = Number(markerValue);
      if (!Number.isFinite(markerNum)) {
        return;
      }
      const markerX = mapValueToX(markerNum, true);
      if (!Number.isFinite(markerX)) {
        return;
      }
      const markerOpts = opts || {};
      const optLen = Number(markerOpts.len);
      const optLineWidth = Number(markerOpts.lineWidth);
      const len = Number.isFinite(optLen) ? Math.max(1, optLen) : Math.max(1, Math.floor(markerSizeBase * 0.45));
      const width = Number.isFinite(optLineWidth)
        ? Math.max(1, optLineWidth)
        : Math.max(1, Math.floor(markerSizeBase * 0.2));
      primitives.drawTick(ctx, Math.round(markerX), layout.trackY + len, len, {
        lineWidth: width,
        lineCap: "butt",
        strokeStyle: hasOwn.call(markerOpts, "strokeStyle") ? markerOpts.strokeStyle : theme.colors.pointer
      });
    }

    return {
      id: "LinearGaugeEngineDrawing",
      drawStaticBack: drawStaticBack,
      drawStaticFront: drawStaticFront,
      drawPointerAtValue: drawPointerAtValue,
      drawMarkerAtValue: drawMarkerAtValue
    };
  }

  return { id: "LinearGaugeEngineDrawing", create: create };
});

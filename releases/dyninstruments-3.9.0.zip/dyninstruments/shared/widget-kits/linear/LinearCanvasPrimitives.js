/**
 * @file LinearCanvasPrimitives - Shared low-level canvas drawing primitives for linear gauges
 * Documentation: documentation/linear/linear-shared-api.md
 */
(function (root, factory) {
  if (typeof define === "function" && define.amd) define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
  else {
    (root.DyniComponents = root.DyniComponents || {}).DyniLinearCanvasPrimitives = factory();
  }
})(this, function () {
  "use strict";
  const hasOwn = Object.prototype.hasOwnProperty;

  /**
   * @param {CanvasRenderingContext2D} ctx
   * @param {DyniLinearDrawOptions | undefined} style
   * @returns {void}
   */
  function applyStyle(ctx, style) {
    const s = style || {};
    if (typeof s.alpha !== "undefined") {
      ctx.globalAlpha = Number(s.alpha);
    }
    if (typeof s.strokeStyle !== "undefined") {
      ctx.strokeStyle = /** @type {string} */ (s.strokeStyle);
    }
    if (typeof s.fillStyle !== "undefined") {
      ctx.fillStyle = /** @type {string} */ (s.fillStyle);
    }
    if (typeof s.lineWidth !== "undefined") {
      ctx.lineWidth = /** @type {number} */ (s.lineWidth);
    }
    if (typeof s.lineCap !== "undefined") {
      ctx.lineCap = /** @type {CanvasLineCap} */ (s.lineCap);
    }
    if (typeof s.lineJoin !== "undefined") {
      ctx.lineJoin = /** @type {CanvasLineJoin} */ (s.lineJoin);
    }
    if (Array.isArray(s.dash)) {
      ctx.setLineDash(s.dash);
    }
  }

  /**
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x0
   * @param {number} x1
   * @param {number} y
   * @param {DyniLinearDrawOptions} [opts]
   * @returns {void}
   */
  function drawTrack(ctx, x0, x1, y, opts) {
    const p = opts || {};
    ctx.save();
    applyStyle(ctx, {
      strokeStyle: p.strokeStyle,
      lineWidth: p.lineWidth !== null && p.lineWidth !== undefined ? p.lineWidth : 1,
      lineCap: hasOwn.call(p, "lineCap") ? p.lineCap : "round",
      alpha: p.alpha !== null && p.alpha !== undefined ? p.alpha : 1,
      dash: p.dash
    });
    ctx.beginPath();
    ctx.moveTo(x0, y);
    ctx.lineTo(x1, y);
    ctx.stroke();
    ctx.restore();
  }

  /**
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x0
   * @param {number} x1
   * @param {number} y
   * @param {unknown} thickness
   * @param {DyniLinearDrawOptions} [opts]
   * @returns {void}
   */
  function drawBand(ctx, x0, x1, y, thickness, opts) {
    const p = opts || {};
    const left = Math.min(x0, x1);
    const width = Math.max(0, Math.abs(x1 - x0));
    if (!Number.isFinite(left) || !Number.isFinite(width) || width <= 0) {
      return;
    }
    const t = Math.max(1, Math.floor(Number(thickness) || 1));
    const top = Math.floor(y - t / 2);

    ctx.save();
    applyStyle(ctx, {
      fillStyle: p.fillStyle,
      strokeStyle: p.strokeStyle,
      alpha: p.alpha !== null && p.alpha !== undefined ? p.alpha : 1
    });
    ctx.fillRect(left, top, width, t);
    const lineWidth = hasOwn.call(p, "lineWidth") ? Number(p.lineWidth) : 0;
    if (lineWidth > 0) {
      ctx.lineWidth = lineWidth;
      ctx.strokeRect(left, top, width, t);
    }
    ctx.restore();
  }

  /**
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x
   * @param {number} y
   * @param {unknown} len
   * @param {DyniLinearDrawOptions} [opts]
   * @returns {void}
   */
  function drawTick(ctx, x, y, len, opts) {
    const p = opts || {};
    const length = Math.max(1, Number(len) || 1);
    ctx.save();
    applyStyle(ctx, {
      strokeStyle: p.strokeStyle,
      lineWidth: p.lineWidth !== null && p.lineWidth !== undefined ? p.lineWidth : 1,
      lineCap: hasOwn.call(p, "lineCap") ? p.lineCap : "butt",
      alpha: p.alpha !== null && p.alpha !== undefined ? p.alpha : 1
    });
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x, y - length);
    ctx.stroke();
    ctx.restore();
  }

  /**
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x
   * @param {number} y
   * @param {DyniLinearDrawOptions} [opts]
   * @returns {void}
   */
  function drawPointer(ctx, x, y, opts) {
    const p = opts || {};
    const depth = Math.max(1, Math.floor(Number(p.depth) || 8));
    const side = Math.max(1, Math.floor(Number(p.side) || 5));
    ctx.save();
    applyStyle(ctx, {
      fillStyle: p.fillStyle || p.color,
      alpha: p.alpha !== null && p.alpha !== undefined ? p.alpha : 1
    });
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x - side, y - depth);
    ctx.lineTo(x + side, y - depth);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  /** @returns {DyniLinearCanvasPrimitivesApi} */
  function create() {
    return {
      id: "LinearCanvasPrimitives",
      drawTrack: drawTrack,
      drawBand: drawBand,
      drawTick: drawTick,
      drawPointer: drawPointer
    };
  }

  return { id: "LinearCanvasPrimitives", create: create };
});

/**
 * Module: WindMapper - Cluster translation for numeric, radial dial, and linear wind kinds
 * Documentation: documentation/architecture/cluster-widget-system.md
 * Depends: routeContext.toolkit
 */

(function (root, factory) {
  if (typeof define === "function" && define.amd) define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
  else { (root.DyniComponents = root.DyniComponents || {}).DyniWindMapper = factory(); }
}(this, function () {
  "use strict";

  function create() {
    function translate(props, routeContext) {
      const p = props || {};
      const toolkit = routeContext.toolkit;
      const cap = toolkit.cap;
      const unit = toolkit.unit;
      const out = toolkit.out;
      const num = toolkit.num;
      const makeAngleFormatter = toolkit.makeAngleFormatter;

      const req = p.kind;

      if (req === "angleTrueRadial" || req === "angleApparentRadial") {
        const isTrue = (req === "angleTrueRadial");
        const angleKind = isTrue ? "angleTrueRadialAngle" : "angleApparentRadialAngle";
        const speedKind = isTrue ? "angleTrueRadialSpeed" : "angleApparentRadialSpeed";
        const speedToken = toolkit.formatUnit(speedKind, "speed");
        const speedUnit = toolkit.unitText(speedKind, "speed", speedToken);
        return {
          angle: isTrue ? p.twa : p.awa,
          speed: isTrue ? p.tws : p.aws,
          rendererProps: {
            angleCaption: cap(angleKind),
            speedCaption: cap(speedKind),
            angleUnit: unit(angleKind),
            speedUnit: speedUnit,
            formatter: "formatSpeed",
            formatterParameters: [speedToken],
            layEnabled: !!p.windRadialLayEnabled,
            windRadialLayMin: num(p.windRadialLayMin),
            windRadialLayMax: num(p.windRadialLayMax),
            windRadialRatioThresholdNormal: num(p.windRadialRatioThresholdNormal),
            windRadialRatioThresholdFlat: num(p.windRadialRatioThresholdFlat),
            captionUnitScale: num(p.captionUnitScale),
            leadingZero: !!p.leadingZero,
            windRadialHideTextualMetrics: !!p.windRadialHideTextualMetrics
          }
        };
      }

      if (req === "angleTrueLinear" || req === "angleApparentLinear") {
        const isTrue = (req === "angleTrueLinear");
        const angleKind = isTrue ? "angleTrueLinearAngle" : "angleApparentLinearAngle";
        const speedKind = isTrue ? "angleTrueLinearSpeed" : "angleApparentLinearSpeed";
        const speedToken = toolkit.formatUnit(speedKind, "speed");
        const speedUnit = toolkit.unitText(speedKind, "speed", speedToken);
        return {
          angle: isTrue ? p.twa : p.awa,
          speed: isTrue ? p.tws : p.aws,
          rendererProps: {
            angleCaption: cap(angleKind),
            speedCaption: cap(speedKind),
            angleUnit: unit(angleKind),
            speedUnit: speedUnit,
            formatter: "formatSpeed",
            formatterParameters: [speedToken],
            windLinearRatioThresholdNormal: num(p.windLinearRatioThresholdNormal),
            windLinearRatioThresholdFlat: num(p.windLinearRatioThresholdFlat),
            windLinearTickMajor: num(p.windLinearTickMajor),
            windLinearTickMinor: num(p.windLinearTickMinor),
            windLinearShowEndLabels: !!p.windLinearShowEndLabels,
            windLinearLayEnabled: p.windLinearLayEnabled !== false,
            windLinearLayMin: num(p.windLinearLayMin),
            windLinearLayMax: num(p.windLinearLayMax),
            captionUnitScale: num(p.captionUnitScale),
            leadingZero: !!p.leadingZero,
            windLinearHideTextualMetrics: !!p.windLinearHideTextualMetrics
          }
        };
      }

      const leadingZero = !!p.leadingZero;

      if (req === "angleTrue") {
        return out(p.twa, cap("angleTrue"), unit("angleTrue"), makeAngleFormatter(false, leadingZero, p.default), []);
      }
      if (req === "angleApparent") {
        return out(p.awa, cap("angleApparent"), unit("angleApparent"), makeAngleFormatter(false, leadingZero, p.default), []);
      }
      if (req === "angleTrueDirection") {
        return out(p.twd, cap("angleTrueDirection"), unit("angleTrueDirection"), makeAngleFormatter(true, leadingZero, p.default), []);
      }
      if (req === "speedTrue") {
        const token = toolkit.formatUnit("speedTrue", "speed");
        return out(p.tws, cap("speedTrue"), toolkit.unitText("speedTrue", "speed", token), "formatSpeed", [token]);
      }
      if (req === "speedApparent") {
        const token = toolkit.formatUnit("speedApparent", "speed");
        return out(p.aws, cap("speedApparent"), toolkit.unitText("speedApparent", "speed", token), "formatSpeed", [token]);
      }
      return {};
    }

    return {
      cluster: "wind",
      translate: translate
    };
  }

  return { id: "WindMapper", create: create };
}));

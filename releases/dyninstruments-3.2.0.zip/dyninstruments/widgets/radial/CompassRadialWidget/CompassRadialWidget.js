/**
 * Module: CompassRadialWidget - Full-circle rotating compass with upright labels
 * Documentation: documentation/widgets/compass-gauge.md
 * Depends: FullCircleRadialEngine, FullCircleRadialTextLayout, SpringEasing, StableDigits
 */
(function (root, factory) {
  if (typeof define === "function" && define.amd) define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
  else { (root.DyniComponents = root.DyniComponents || {}).DyniCompassRadialWidget = factory(); }
}(this, function () {
  "use strict";
  const hasOwn = Object.prototype.hasOwnProperty;
  const COMPASS_LABELS = { 0: "N", 45: "NE", 90: "E", 135: "SE", 180: "S", 225: "SW", 270: "W", 315: "NW" };
  const COMPASS_LABEL_ANGLES = [0, 45, 90, 135, 180, 225, 270, 315];

  function create(def, componentContext) {
    const engine = componentContext.components.require("FullCircleRadialEngine");
    const textLayout = componentContext.components.require("FullCircleRadialTextLayout");
    const stableDigits = componentContext.components.require("StableDigits");
    const springEasing = componentContext.components.require("SpringEasing");
    const headingMotion = springEasing.createMotion({ wrap: 360 });
    const markerMotion = springEasing.createMotion({ wrap: 360 });

    function buildCompassLabelSprites(canvas, state) {
      const sprites = [];
      const labelRadius = state.labels.spriteRadius;
      const font = state.labelWeight + " " + state.labels.fontPx + "px " + state.family;

      for (let i = 0; i < COMPASS_LABEL_ANGLES.length; i++) {
        const angleDeg = COMPASS_LABEL_ANGLES[i];
        const text = COMPASS_LABELS[angleDeg];
        const sprite = canvas.ownerDocument.createElement("canvas");
        const spriteCtx = sprite.getContext("2d");
        if (!spriteCtx) {
          continue;
        }

        spriteCtx.font = font;
        const width = Math.max(1, Math.ceil(spriteCtx.measureText(text).width + 6));
        const height = Math.max(1, Math.ceil(state.labels.fontPx * 1.6));
        sprite.width = width;
        sprite.height = height;

        const drawCtx = sprite.getContext("2d");
        if (!drawCtx) {
          continue;
        }
        drawCtx.setTransform(1, 0, 0, 1, 0, 0);
        drawCtx.clearRect(0, 0, width, height);
        drawCtx.fillStyle = state.color;
        drawCtx.strokeStyle = state.color;
        drawCtx.font = font;
        drawCtx.textAlign = "center";
        drawCtx.textBaseline = "middle";
        drawCtx.fillText(text, width / 2, height / 2);
        sprites.push({ angleDeg: angleDeg, canvas: sprite, width: width, height: height });
      }

      return { sprites: sprites, labelRadius: labelRadius };
    }

    function drawCompassCachedLabels(state, rotationDeg, api) {
      const entry = api.getCacheMeta("labels:" + state.staticKey);
      if (!entry || !entry.sprites || !entry.sprites.length) {
        return;
      }
      for (let i = 0; i < entry.sprites.length; i++) {
        const sprite = entry.sprites[i];
        const t = state.angle.degToCanvasRad(sprite.angleDeg, null, rotationDeg);
        const x = state.geom.cx + Math.cos(t) * entry.labelRadius;
        const y = state.geom.cy + Math.sin(t) * entry.labelRadius;
        state.ctx.drawImage(sprite.canvas, x - (sprite.width / 2), y - (sprite.height / 2));
      }
    }

    function compassDisplay(state, props) {
      const p = props || {};
      const heading = p.heading;
      const headingText = state.value.isFiniteNumber(heading)
        ? state.value.formatDirection360(heading, !!p.leadingZero)
        : p.default;
      const valueText = p.stableDigits === true
        ? stableDigits.normalize(headingText, {
          integerWidth: 3,
          reserveSignSlot: false
        }).padded
        : headingText;
      return {
        heading: heading,
        marker: p.markerCourse,
        caption: p.caption,
        unit: p.unit,
        value: valueText,
        secScale: state.value.clamp(p.captionUnitScale, 0.3, 3.0)
      };
    }

    const renderCanvas = engine.createRenderer({
      ratioProps: {
        normal: "compassRadialRatioThresholdNormal",
        flat: "compassRadialRatioThresholdFlat"
      },
      hideTextualMetricsProp: "compassRadialHideTextualMetrics",
      cacheLayers: ["face"],
      layout: { highTopFactor: 0.9, highBottomFactor: 0.9 },
      buildStaticKey: function (state) {
        return {
          labelPx: state.labels.fontPx,
          labelRadius: state.labels.spriteRadius,
          labelsSig: "N|NE|E|SE|S|SW|W|NW"
        };
      },
      rebuildLayer: function (layerCtx, layerName, state, props, api) {
        if (layerName !== "face") {
          return;
        }
        api.drawFullCircleRing(layerCtx);
        api.drawFullCircleTicks(layerCtx, {
          startDeg: 0,
          endDeg: 360,
          stepMajor: 30,
          stepMinor: 10
        });
        api.setCacheMeta("labels:" + state.staticKey, buildCompassLabelSprites(state.canvas, state));
      },
      drawFrame: function (state, props, api) {
        const display = compassDisplay(state, props);
        const easingEnabled = props.easing !== false;
        const nowMs = Date.now();
        const easedHeading = headingMotion.resolve(state.canvas, display.heading, easingEnabled, nowMs);
        const markerFinite = state.value.isFiniteNumber(display.marker);
        const easedMarker = markerFinite
          ? markerMotion.resolve(state.canvas, display.marker, easingEnabled, nowMs)
          : NaN;
        let rotationDeg = 0;
        if (Number.isFinite(easedHeading)) {
          rotationDeg = -easedHeading;
        }

        api.drawCachedLayer("face", { rotationDeg: rotationDeg });
        api.drawFixedPointer(state.ctx, 0);

        if (Number.isFinite(easedHeading) && Number.isFinite(easedMarker)) {
          state.draw.drawRimMarker(state.ctx, state.geom.cx, state.geom.cy, state.geom.rOuter, easedMarker - easedHeading, {
            len: state.geom.markerLen,
            width: state.geom.markerWidth,
            strokeStyle: state.theme.colors.pointer
          });
        }
        drawCompassCachedLabels(state, rotationDeg, api);
        if (headingMotion.isActive(state.canvas) || (markerFinite && markerMotion.isActive(state.canvas))) {
          return { wantsFollowUpFrame: true };
        }
      },
      drawMode: {
        flat: function (state, props) {
          textLayout.drawSingleModeText(state, "flat", compassDisplay(state, props), { side: "left", align: "left" });
        },
        high: function (state, props) {
          textLayout.drawSingleModeText(state, "high", compassDisplay(state, props), { slot: "top" });
        },
        normal: function (state, props) {
          textLayout.drawSingleModeText(state, "normal", compassDisplay(state, props));
        }
      }
    });

    function translateFunction() {
      return {};
    }

    return {
      id: "CompassRadialWidget",
      wantsHideNativeHead: true,
      renderCanvas: renderCanvas,
      translateFunction: translateFunction
    };
  }

  return { id: "CompassRadialWidget", create };
}));
